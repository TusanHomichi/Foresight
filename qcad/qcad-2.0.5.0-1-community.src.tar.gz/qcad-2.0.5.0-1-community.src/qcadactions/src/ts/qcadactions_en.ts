<!DOCTYPE TS><TS>
<context>
    <name>RS_ActionBlocksAdd</name>
    <message>
        <source>Add Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksAttributes</name>
    <message>
        <source>Rename Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksCreate</name>
    <message>
        <source>Create Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksEdit</name>
    <message>
        <source>Edit Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksExplode</name>
    <message>
        <source>Explode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksFreezeAll</name>
    <message>
        <source>Freeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksInsert</name>
    <message>
        <source>Insert Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter rows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter column spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter row spacing:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksRemove</name>
    <message>
        <source>Remove Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksToggleView</name>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDefault</name>
    <message>
        <source>Choose second edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimAligned</name>
    <message>
        <source>Aligned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first extension line origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second extension line origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimAngular</name>
    <message>
        <source>Angular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify dimension arc line location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimDiametric</name>
    <message>
        <source>Diametric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a circle or arc entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select arc or circle entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimLeader</name>
    <message>
        <source>Leader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimLinear</name>
    <message>
        <source>Linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first extension line origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second extension line origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension line angle:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDimRadial</name>
    <message>
        <source>Radial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a circle or arc entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select arc or circle entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify dimension line position or enter angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArc</name>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid chord length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify start angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify end angle or [Angle/chord Length]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify included angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify chord length:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArc3P</name>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid arc data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify startpoint or [Center]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify endpoint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArcTangential</name>
    <message>
        <source>Arc: Tangential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tangential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw arcs tangential to base entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify base entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify end angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle</name>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle2P</name>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Circle data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle3P</name>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid circle data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify third point</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircleCR</name>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify circle center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify circle radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawEllipseAxis</name>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify ellipse center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify endpoint of major axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify endpoint or length of minor axis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify start angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify end angle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawHatch</name>
    <message>
        <source>Hatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid hatch area. Please check that the entities chosen form one or more closed contours.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hatch created successfully.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawImage</name>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLine</name>
    <message>
        <source>Line: 2 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next point or [%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot close sequence of lines: Not enough entities defined yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineAngle</name>
    <message>
        <source>Line: Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineBisector</name>
    <message>
        <source>Bisector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter bisector length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter number of bisectors:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineFree</name>
    <message>
        <source>Line: Freehand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click and drag to draw a line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineHorVert</name>
    <message>
        <source>hor./vert. line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineParallel</name>
    <message>
        <source>Parallel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify Distance &lt;%1&gt; or select entity or [%2]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineParallelThrough</name>
    <message>
        <source>Parallel through point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify through point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLinePolygon</name>
    <message>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify a corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLinePolygon2</name>
    <message>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polygo&amp;n (Cor,Cor)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..9999</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineRectangle</name>
    <message>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineRelAngle</name>
    <message>
        <source>Relative angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select base entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineTangent1</name>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select circle, arc or ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineTangent2</name>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first circle or arc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second circle or arc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawPoint</name>
    <message>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawSpline</name>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first control point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next control point or [%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next control point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawText</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify insertion point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionEditCopy</name>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionEditPaste</name>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionEditUndo</name>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionFileNew</name>
    <message>
        <source>New Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionFileOpen</name>
    <message>
        <source>Open Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionFileSave</name>
    <message>
        <source>Save Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionFileSaveAs</name>
    <message>
        <source>Save Drawing As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoAngle</name>
    <message>
        <source>Angle between two lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle: %1%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lines are parallel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoArea</name>
    <message>
        <source>Polygonal Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polygonal Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measures the area of a polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Area: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circumference: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point of polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify next point of polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoDist</name>
    <message>
        <source>Distance Point to Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point of distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point of distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoDist2</name>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoInside</name>
    <message>
        <source>Point inside contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point is inside selected contour.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point is outside selected contour.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoTotalLength</name>
    <message>
        <source>Total length of selected entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Length of selected entities: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At least one of the selected entities cannot be measured.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersAdd</name>
    <message>
        <source>Add Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersEdit</name>
    <message>
        <source>Edit Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersFreezeAll</name>
    <message>
        <source>Freeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersRemove</name>
    <message>
        <source>Remove Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersToggleLock</name>
    <message>
        <source>Toggle Layer Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toggle Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Lock</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersToggleView</name>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLibraryInsert</name>
    <message>
        <source>Insert Library Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Insert Library Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserts an Object from the part library.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot open file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionLockRelativeZero</name>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyAttributes</name>
    <message>
        <source>Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyBevel</name>
    <message>
        <source>Bevel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter length 1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter length 2:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyCut</name>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Entity found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entity must be a line, arc or circle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutting point is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutting point is not on entity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify entity to cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify cutting point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDelete</name>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDeleteFree</name>
    <message>
        <source>Delete Freehand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first break point on a polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second break point on the same polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entities not in the same polyline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent of second entity is not a polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent of second entity is NULL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One of the chosen entities is NULL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent of first entity is not a polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent of first entity is NULL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First entity is NULL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Second entity is NULL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDeleteQuick</name>
    <message>
        <source>Delete selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick entity to delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyEntity</name>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyExplodeText</name>
    <message>
        <source>Explode Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Explode Text into Letters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explodes Text Entities into single Letters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMirror</name>
    <message>
        <source>Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first point of mirror line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second point of mirror line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMove</name>
    <message>
        <source>Move / Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Move / Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move or copy entities one or multiple times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMoveRotate</name>
    <message>
        <source>Move and Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter rotation angle:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRotate</name>
    <message>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRotate2</name>
    <message>
        <source>Rotate Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify absolute reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify relative reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRound</name>
    <message>
        <source>Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyScale</name>
    <message>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyStretch</name>
    <message>
        <source>Stretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyTrim</name>
    <message>
        <source>Trim</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first trim entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select limiting entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second trim entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select entity to trim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyTrimAmount</name>
    <message>
        <source>Lengthen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No entity found. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The chosen Entity is in a block. Please edit the block.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The chosen Entity is not an atomic entity or cannot be trimmed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select entity to trim or enter distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionOptionsDrawing</name>
    <message>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionPrintPreview</name>
    <message>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectAll</name>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectContour</name>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entity must be an Atomic Entity.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectIntersected</name>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose first point of intersection line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose second point of intersection line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectInvert</name>
    <message>
        <source>Invert Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectLayer</name>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectSingle</name>
    <message>
        <source>Select Entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectWindow</name>
    <message>
        <source>Select Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose first edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose second edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSetRelativeZero</name>
    <message>
        <source>Set Relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set relative Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionSnapIntersectionManual</name>
    <message>
        <source>Intersection Manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first entity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select second entity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionToolRegenerateDimensions</name>
    <message>
        <source>Regenerate Dimension Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Regenerate Dimension Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerates all Dimension Entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regenerated %1 dimension entities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No dimension entities found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomAuto</name>
    <message>
        <source>Auto Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomIn</name>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomPan</name>
    <message>
        <source>Pan Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomPrevious</name>
    <message>
        <source>Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Previous View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shows previous view</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomRedraw</name>
    <message>
        <source>Redraw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomWindow</name>
    <message>
        <source>Window Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify first edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify second edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
