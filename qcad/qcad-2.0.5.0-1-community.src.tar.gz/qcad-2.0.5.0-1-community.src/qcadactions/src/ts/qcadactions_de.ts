<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>New File</source>
        <translation type="obsolete">Neue Datei</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Neu</translation>
    </message>
    <message>
        <source>Creates a new document</source>
        <translation type="obsolete">Erstellt eine neue Zeichung</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="obsolete">Öffnen</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="obsolete">Ö&amp;ffnen...</translation>
    </message>
    <message>
        <source>Opens an existing document</source>
        <translation type="obsolete">Öffnet eine bestehende Zeichung</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="obsolete">Datei Speichern</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="obsolete">&amp;Speichern</translation>
    </message>
    <message>
        <source>Saves the current document</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Save File As</source>
        <translation type="obsolete">Speichern unter</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="obsolete">Speichern &amp;unter...</translation>
    </message>
    <message>
        <source>Close File</source>
        <translation type="obsolete">Datei schliessen</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="obsolete">Sc&amp;hliessen</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Drucken</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Beenden</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">B&amp;eenden</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation type="obsolete">Beendet die Applikation</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation type="obsolete">Statuszeile</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation type="obsolete">&amp;Statuszeile</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation type="obsolete">(De-)aktiviert die Statuszeile</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation type="obsolete">Layer Liste</translation>
    </message>
    <message>
        <source>&amp;Layer List</source>
        <translation type="obsolete">&amp;Layer Liste</translation>
    </message>
    <message>
        <source>Enables/disables the layerlist</source>
        <translation type="obsolete">(De-)aktiviert die Layer Liste</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation type="obsolete">Block Liste</translation>
    </message>
    <message>
        <source>&amp;Block List</source>
        <translation type="obsolete">&amp;Block Liste</translation>
    </message>
    <message>
        <source>Enables/disables the blocklist</source>
        <translation type="obsolete">(De-)aktiviert die Block Liste</translation>
    </message>
    <message>
        <source>Command Widget</source>
        <translation type="obsolete">Eingabezeile</translation>
    </message>
    <message>
        <source>&amp;Command Widget</source>
        <translation type="obsolete">&amp;Eingabezeile</translation>
    </message>
    <message>
        <source>Enables/disables the command widget</source>
        <translation type="obsolete">(De-)aktiviert die Eingabezeile</translation>
    </message>
    <message>
        <source>Option Toolbar</source>
        <translation type="obsolete">Optionen Symbolleiste</translation>
    </message>
    <message>
        <source>&amp;Option Toolbar</source>
        <translation type="obsolete">&amp;Optionen Symbolleiste</translation>
    </message>
    <message>
        <source>Enables/disables the option toolbar</source>
        <translation type="obsolete">(De-)aktiviert die Symbolleiste</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="obsolete">Ansicht vergrössern</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="obsolete">Ansicht ver&amp;grössern</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="obsolete">Vergrössert die Ansicht</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="obsolete">Ansicht verkleinern</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="obsolete">Ansicht ver&amp;kleinern</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="obsolete">Verkleinert die Ansicht</translation>
    </message>
    <message>
        <source>Auto Zoom</source>
        <translation type="obsolete">Auto Ansicht</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="obsolete">&amp;Auto Ansicht</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="obsolete">Zeigt die ganze Zeichnung</translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation type="obsolete">Fenster Zoom</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="obsolete">&amp;Fenster Zoom</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="obsolete">Vergrössert einen Ausschnitt</translation>
    </message>
    <message>
        <source>Pan Zoom</source>
        <translation type="obsolete">Ansicht verschieben</translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="obsolete">Ansicht &amp;verschieben</translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="obsolete">Echtzeit verschieben</translation>
    </message>
    <message>
        <source>Redraw</source>
        <translation type="obsolete">Neu aufbauen</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="obsolete">&amp;Neu aufbauen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Rückgängig</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">&amp;Rückgängig</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="obsolete">Macht die letzte Änderung rückgängig</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Wieder herstellen</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Wieder herstellen</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="obsolete">Stellt die zuletzt zurückgenommene Änderung wieder her</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Ausschneiden</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">Aus&amp;schneiden</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">&amp;Kopieren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Einfügen</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">Ein&amp;fügen</translation>
    </message>
    <message>
        <source>Select Entity</source>
        <translation type="obsolete">Objekt selektieren</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="obsolete">Einzelne Objekte selektieren</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation type="obsolete">Bereich selektieren</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="obsolete">&amp;Bereich selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="obsolete">Selektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="obsolete">Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="obsolete">&amp;Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="obsolete">Deselektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">Kontur (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">(De-)selektiert verbundene Objekte (Konturen)</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="obsolete">Alles selektieren</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="obsolete">&amp;Alles selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="obsolete">Selektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Deselektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="obsolete">&amp;Alles Deselktieren</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="obsolete">Deselektiert alle sichtbaren Objekte</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="obsolete">Selektion invertieren</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="obsolete">Selektion &amp;invertieren</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="obsolete">Invertiert die aktuelle Selektion</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="obsolete">Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="obsolete">&amp;Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="obsolete">Selektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="obsolete">Geschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="obsolete">G&amp;eschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="obsolete">Deselektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="obsolete">Layer (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="obsolete">(De-)selektiert alle Objekte auf einem Layer</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Punkte</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="obsolete">&amp;Punkte</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="obsolete">Punkte zeichnen</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation type="obsolete">Linie: 2 Punkte</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="obsolete">&amp;2 Punkte</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="obsolete">Linien zeichnen</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Linie: Winkel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Winkel</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Zeichnen von Linien mit gegebenem Winkel</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Linie: Horizontal</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Horizontal</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Zeichnen von horizontalen Linien</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="obsolete">hor./vert. Linie</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="obsolete">H&amp;orizontal / Vertikal</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="obsolete">Zeichnen von horizontalen oder vertikalen Linien</translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Linie: vertikal</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Vertikal</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Zeichnen von vertikalen Linien</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation type="obsolete">Linie: Freihand</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="obsolete">&amp;Freihand-Linie</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="obsolete">Freihand-Linien zeichnen</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Parallele</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="obsolete">Para&amp;llele</translation>
    </message>
    <message>
        <source>Draw parallels</source>
        <translation type="obsolete">Zeichnen von Parallelen Linien</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rechteck</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="obsolete">&amp;Rechteck</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="obsolete">Zeichnen von Rechtecken</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation type="obsolete">Winkelhalbierende</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="obsolete">&amp;Winkelhalbierende</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="obsolete">Winkelhalbierende zeichnen</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="obsolete">Tangente (P,K)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="obsolete">&amp;Tangente (P,K)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="obsolete">Tangente von einemPunkt an einen Kreis zeichnen</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="obsolete">Tangente (K,K)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="obsolete">Tan&amp;gente (K,K)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="obsolete">Tangente von Kreis zu Kreis zeichnen</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Orthogonal</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">&amp;Orthogonal</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Orthogonale Linien zeichnen</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation type="obsolete">Relativer Winkel</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="obsolete">R&amp;elativer Winkel</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="obsolete">Linien mit relativem Winkel zu einem Objekt zeichnen</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="obsolete">Polygon</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="obsolete">Pol&amp;ygon (Zentrum,Ecke)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="obsolete">Polygon mit Zentrum und Ecke zeichnen</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cor,Cor)</source>
        <translation type="obsolete">Pol&amp;ygon (zwei Ecken)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="obsolete">Polygon mit zwei gegebenen Ecken zeichnen</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="obsolete">Kreis: Zentrum, Kreispunkt</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="obsolete">Zentrum, &amp;Kreispunkt</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="obsolete">Kreis mit Zentrum und Kreispunkt zeichnen</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="obsolete">Kreis: Zentrum, Radius</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="obsolete">Zentrum, &amp;Radius</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="obsolete">Kreis mit Zentrum und Radius zeichnen</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="obsolete">Kreis: 2 Punkte</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="obsolete">2 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="obsolete">Kreis mit 2 Kreispunkten  zeichnen</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Kreis: 3 Punkte</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Kreis mit 3 Kreispunkten zeichnen</translation>
    </message>
    <message>
        <source>Circle: Parallel</source>
        <translation type="obsolete">Kreis: Parallel</translation>
    </message>
    <message>
        <source>&amp;Parallel</source>
        <translation type="obsolete">&amp;Parallel</translation>
    </message>
    <message>
        <source>Draw arcs parallel to existing arcs</source>
        <translation type="obsolete">Kreisbogen parallel zu einem existierenden Kreisbogen</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="obsolete">Kreisbogen: Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="obsolete">&amp;Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="obsolete">Kresibogen zeichnen</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="obsolete">Kreisbogen: 3 Punkte</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="obsolete">&amp;3 Punkte</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="obsolete">Kreisbogen mit 3 Punkten</translation>
    </message>
    <message>
        <source>Arc: Parallel</source>
        <translation type="obsolete">Kreisbogen: Parallel</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="obsolete">Elllipse mit Achsen</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="obsolete">&amp;Ellipse (Achsen)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="obsolete">Ellipse zeichnen</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="obsolete">Ellipsenbogen mit Achse</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="obsolete">Ellipsen&amp;bogen (Achse)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="obsolete">Ellipsenbogen zeichnen</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Text</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="obsolete">&amp;Text</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="obsolete">Text Objekt erstellen</translation>
    </message>
    <message>
        <source>Hatches</source>
        <translation type="obsolete">Schraffur</translation>
    </message>
    <message>
        <source>&amp;Hatches</source>
        <translation type="obsolete">&amp;Schraffuren</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="obsolete">Erstellen von Schraffuren und Füllungen</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation type="obsolete">Ausgerichtet</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="obsolete">&amp;Ausgerichtet</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Anliegende Bemassung</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="obsolete">Linear</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="obsolete">&amp;Linear</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="obsolete">Lineare Bemassung</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="obsolete">Horizontal</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="obsolete">Horizontale Bemassung</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="obsolete">Vertikal</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="obsolete">Vertikale Bemassung</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation type="obsolete">Radial</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="obsolete">&amp;Radial</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="obsolete">Radiale Bemassung</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation type="obsolete">Durchmesser</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="obsolete">&amp;Durchmesser</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="obsolete">Durchmesser Bemassung</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="obsolete">&amp;Winkel</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="obsolete">Winkel Bemassung</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation type="obsolete">Führung</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="obsolete">&amp;Führung</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="obsolete">Führung</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Löschen</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;Löschen</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="obsolete">Objekte löschen</translation>
    </message>
    <message>
        <source>Quick Delete</source>
        <translation type="obsolete">Schnell Löschen</translation>
    </message>
    <message>
        <source>&amp;Quick Delete</source>
        <translation type="obsolete">&amp;Schnell Löschen</translation>
    </message>
    <message>
        <source>Delete Entities directly</source>
        <translation type="obsolete">Löscht Objekte direkt</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation type="obsolete">Freihand löschen</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="obsolete">&amp;Freihand Löschen</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Verschieben</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Verschieben</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Objekte verschieben / kopieren</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation type="obsolete">Rotieren</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="obsolete">&amp;Rotieren</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="obsolete">Objekte rotieren</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="obsolete">Skalieren</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="obsolete">&amp;Skalieren</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="obsolete">Objekte skalieren</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Spiegeln</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">S&amp;piegeln</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Objekte spiegeln</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation type="obsolete">Verschieben und Rotieren</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="obsolete">V&amp;erschieben und Rotieren</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="obsolete">Verschiebt und Rotiert Objekte</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation type="obsolete">Rotieren Zwei</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="obsolete">Rotieren &amp;Zwei</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="obsolete">Objekte um zwei Zentren rotieren</translation>
    </message>
    <message>
        <source>Entity</source>
        <translation type="obsolete">Objekt</translation>
    </message>
    <message>
        <source>&amp;Entity</source>
        <translation type="obsolete">&amp;Objekt</translation>
    </message>
    <message>
        <source>Modify Entities</source>
        <translation type="obsolete">Objekte modifizieren</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Trimmen</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">&amp;Trimmen</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Objekte trimmen</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Trimmen Zwei</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">&amp;Trimmen Zwei</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Zwei Objekte trimmen</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Verlängern</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">&amp;Verlängern</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Um einen gegebenen Betrag verlängern</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">T&amp;rennen</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Objekte trennen</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation type="obsolete">Strecken</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="obsolete">&amp;Strecken</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="obsolete">Objektgruppen strecken</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation type="obsolete">Abschrägen</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="obsolete">&amp;Abschrägen</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="obsolete">Ecken abschrägen</translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="obsolete">Runden</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="obsolete">&amp;Runden</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="obsolete">Ecken runden</translation>
    </message>
    <message>
        <source>Free</source>
        <translation type="obsolete">Frei</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation type="obsolete">&amp;Frei</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation type="obsolete">Freie positionierung</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Raster</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation type="obsolete">&amp;Raster</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation type="obsolete">Raster Positionierung</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation type="obsolete">Endpunkte</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation type="obsolete">&amp;Endpunkte</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation type="obsolete">Endpunkte fangen</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation type="obsolete">Auf Objekt</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation type="obsolete">&amp;Auf Objekt</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation type="obsolete">Nächsten Punkt auf einem Objekt fangen</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="obsolete">Zentrum</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation type="obsolete">&amp;Zentrum</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation type="obsolete">Zentern fangen</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation type="obsolete">Mittelpunkt</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation type="obsolete">&amp;Mittelpunkt</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation type="obsolete">Mittelpunkte fangen</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation type="obsolete">Distanz zum Endpunkt</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation type="obsolete">&amp;Distanz zum Endpunkt</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation type="obsolete">Punkt mit gegebenem Abstand zu einem Endpunkt fangen</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation type="obsolete">Schnittpunkt</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation type="obsolete">&amp;Schnittpunkt</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation type="obsolete">Schnittpunkte fangen</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation type="obsolete">Schnittpunkt manuell</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="obsolete">Sch&amp;nittpunkt manuell</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="obsolete">Schnittpunkte manuell fangen</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation type="obsolete">Keine Einschränkung</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation type="obsolete">&amp;Keine Einschränkung</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation type="obsolete">Alle Fang-Einschränkungen aufheben</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation type="obsolete">Orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation type="obsolete">&amp;Orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation type="obsolete">Fangen orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation type="obsolete">Horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation type="obsolete">&amp;Horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation type="obsolete">Fangen horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation type="obsolete">Vertikal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation type="obsolete">&amp;Vertikal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation type="obsolete">Fangen vertikal einschränken</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation type="obsolete">Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="obsolete">&amp;Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="obsolete">Position des relativen Nullpunktes neu setzten</translation>
    </message>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt &amp;festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation type="obsolete">Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="obsolete">&amp;Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="obsolete">Testet, ob ein gegebener Punkt innerhalb der selektierten Kontur liegt</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Alle auftauen</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">Alle auf&amp;tauen</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Alle Layer auftauen</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Alle einfrieren</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">Alle ein&amp;frieren</translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation type="obsolete">Alle Layer einfrieren</translation>
    </message>
    <message>
        <source>Add Layer</source>
        <translation type="obsolete">Layer hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="obsolete">Layer &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation type="obsolete">Layer löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="obsolete">Layer &amp;löschen</translation>
    </message>
    <message>
        <source>Edit Layer</source>
        <translation type="obsolete">Layerattribute ändern</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="obsolete">Layer&amp;attribute ändern</translation>
    </message>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="obsolete">Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="obsolete">&amp;Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="obsolete">Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Alle Blöcke auftauen</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Alle Blöcke einfrieren</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Block hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">Block &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Block löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">Block &amp;löschen</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Block umbenennen</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">Block um&amp;benennen</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Block und alle Instanzen umbennenen</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Block editieren</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">Block &amp;editieren</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Block einfügen</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">Block ein&amp;fügen</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Sichtbareit umschalten</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">Sichtbarkeit &amp;umschalten</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Sichtbarkeit umschalten</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation type="obsolete">Block erstellen</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">&amp;Block erstellen</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Aufbrechen</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">&amp;Aufbrechen</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Blöcke und andere Objekt-Gruppen aufbrechen</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allgemein</translation>
    </message>
    <message>
        <source>&amp;General Preferences</source>
        <translation type="obsolete">&amp;Allgemeine Einstellungen</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation type="obsolete">Allgemeine Applikations-Einstellungen</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="obsolete">Zeichnung</translation>
    </message>
    <message>
        <source>&amp;Drawing Preferences</source>
        <translation type="obsolete">&amp;Zeichnungs-Einstellungen</translation>
    </message>
    <message>
        <source>Drawing Settings</source>
        <translation type="obsolete">Zeichnungs-Einstellungen</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="obsolete">Erstellt eine neue Zeichnung</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="obsolete">Öffnet eine bestehende Zeichnung</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung unter einem neuen Dateinamen</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation type="obsolete">Schliesst die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation type="obsolete">Druckt die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>New Drawing</source>
        <translation type="obsolete">Neue Zeichnung</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation type="obsolete">Zeichnung öffnen</translation>
    </message>
    <message>
        <source>Save Drawing</source>
        <translation type="obsolete">Zeichnung speichern</translation>
    </message>
    <message>
        <source>Save Drawing As</source>
        <translation type="obsolete">Zeichnung speichern als</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation type="obsolete">Zeichnung schliessen</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation type="obsolete">Zeichnung drucken</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="obsolete">Schneidet Objekte aus auf die Zwischenablage</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="obsolete">Kopiert Objekte auf die Zwischenablage</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="obsolete">Fügt den Inhalt der Zwischenablage ein</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="obsolete">Objekte (de-)&amp;selektieren</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">&amp;Konturen (de-)selektieren</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="obsolete">Parallelen zu existierenden Linien, Bögen und Kreisen</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation type="obsolete">Parallele durch Punkt</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="obsolete">Par&amp;allele durch Punkt</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="obsolete">Parallele durch einen gegebenen Punkt konstruieren</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="obsolete">Attribute</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="obsolete">&amp;Attribute</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="obsolete">Objekt Attribute editieren</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="obsolete">Selektierte Objekte löschen</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="obsolete">Selektierte &amp;löschen</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="obsolete">Selektierte Objekte löschen</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="obsolete">Bilder</translation>
    </message>
    <message>
        <source>&amp;Images</source>
        <translation type="obsolete">&amp;Bilder</translation>
    </message>
    <message>
        <source>Insert Images (Bitmaps)</source>
        <translation type="obsolete">Bilder (Bitmaps) einfügen</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">Druckvorschau</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="obsolete">Druck&amp;vorschau</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="obsolete">Zeigt Druckvorschau an</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation type="obsolete">Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="obsolete">&amp;Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="obsolete">Misst die Distanz zwischen zwei Punkten</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="obsolete">Abstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="obsolete">A&amp;bstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="obsolete">Misst die Distanz zwischen einem Objekt und einem Punkt</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation type="obsolete">Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="obsolete">&amp;Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="obsolete">Misst den Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation type="obsolete">Zeichnung Exportieren</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Export..</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation type="obsolete">Exportiert die aktuelle Zeichnung als Bitmap</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Eigenschaften</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="obsolete">Objekt Eigenschaften bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="obsolete">&amp;Eigenschaften</translation>
    </message>
    <message>
        <source>Application</source>
        <translation type="obsolete">Applikation</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation type="obsolete">&amp;Applikations Einstellungen</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="obsolete">&amp;Zeichnungseinstellungen</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="obsolete">Einstellungen für die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation type="obsolete">Raster ein- / ausschalten</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Kreis: Konzentrisch</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Konzentrisch</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Kreis konzentrisch zu existierendem Kreis</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Kreisbogen: Konzentrisch</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Kreisbogen konzentrisch zu existierendem Kreisbogen</translation>
    </message>
    <message>
        <source>Hatch</source>
        <translation type="obsolete">Schraffur</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="obsolete">&amp;Schraffur</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="obsolete">Bild</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="obsolete">&amp;Bild</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="obsolete">Bild (Bitmap) einfügen</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation type="obsolete">Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="obsolete">&amp;Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="obsolete">Misst die totale Länge aller ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Polygo&amp;n (Cor,Cor)</source>
        <translation type="obsolete">Polygo&amp;n (2 Ecken)</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksAdd</name>
    <message>
        <source>Add Block</source>
        <translation>Block hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>Block &amp;hinzufügen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksAttributes</name>
    <message>
        <source>Rename Block</source>
        <translation>Block umbenennen</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>Block um&amp;benennen</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation>Block und alle Instanzen umbennenen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksCreate</name>
    <message>
        <source>Set Reference Point:</source>
        <translation type="obsolete">Referenzpunkt setzen:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Block erstellen</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation>&amp;Block erstellen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksEdit</name>
    <message>
        <source>Edit Block</source>
        <translation>Block editieren</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>Block &amp;editieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksExplode</name>
    <message>
        <source>Explode</source>
        <translation>Aufbrechen</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation>&amp;Aufbrechen</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation>Blöcke und andere Objekt-Gruppen aufbrechen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksFreezeAll</name>
    <message>
        <source>Freeze all</source>
        <translation>Alle einfrieren</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation>Alle ein&amp;frieren</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation>Alle Blöcke einfrieren</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation>Alle auftauen</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation>Alle auf&amp;tauen</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation>Alle Blöcke auftauen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksInsert</name>
    <message>
        <source>Angle</source>
        <comment>command: set angle for insert</comment>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>Not a valid expression.</source>
        <translation type="obsolete">Kein gültiger Befehl.</translation>
    </message>
    <message>
        <source>Set Reference Point:</source>
        <translation type="obsolete">Referenzpunkt setzen:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Set Angle:</source>
        <translation type="obsolete">Winkel eingeben:</translation>
    </message>
    <message>
        <source>Set Factor:</source>
        <translation type="obsolete">Faktor eingeben:</translation>
    </message>
    <message>
        <source>Set Columns:</source>
        <translation type="obsolete">Spalten eingeben:</translation>
    </message>
    <message>
        <source>Enter Angle:</source>
        <translation type="obsolete">Winkel eingeben:</translation>
    </message>
    <message>
        <source>Enter Factor:</source>
        <translation type="obsolete">Faktor eingeben:</translation>
    </message>
    <message>
        <source>Enter Columns:</source>
        <translation type="obsolete">Spaltenanzahl eingeben:</translation>
    </message>
    <message>
        <source>Enter Rows:</source>
        <translation type="obsolete">Zeilenanzahl eingeben:</translation>
    </message>
    <message>
        <source>Enter Column Spacing:</source>
        <translation type="obsolete">Spaltenabstand eingeben:</translation>
    </message>
    <message>
        <source>Enter Row Spacing:</source>
        <translation type="obsolete">Zeilenabstand eingeben:</translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation>Winkel eingeben:</translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation>Faktor eingeben:</translation>
    </message>
    <message>
        <source>Enter columns:</source>
        <translation>Spalten eingeben:</translation>
    </message>
    <message>
        <source>Enter rows:</source>
        <translation>Reihen eingeben:</translation>
    </message>
    <message>
        <source>Enter column spacing:</source>
        <translation>Spaltenabstand eingeben:</translation>
    </message>
    <message>
        <source>Enter row spacing:</source>
        <translation>Reihenabstand eingeben:</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt eingeben</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation>Block einfügen</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>Block ein&amp;fügen</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksRemove</name>
    <message>
        <source>Remove Block</source>
        <translation>Block löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>Block &amp;löschen</translation>
    </message>
</context>
<context>
    <name>RS_ActionBlocksToggleView</name>
    <message>
        <source>Toggle Block Visibility</source>
        <translation>Sichtbareit umschalten</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation>Sichtbarkeit &amp;umschalten</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation>Sichtbarkeit umschalten</translation>
    </message>
</context>
<context>
    <name>RS_ActionDefault</name>
    <message>
        <source>Choose second edge</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimAligned</name>
    <message>
        <source>First extension point:</source>
        <translation type="obsolete">Erster Punkt:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Second extension point:</source>
        <translation type="obsolete">Zweiter Punkt:</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Definition point:</source>
        <translation type="obsolete">Definitions Punkt:</translation>
    </message>
    <message>
        <source>Text Label:</source>
        <translation type="obsolete">Beschriftung:</translation>
    </message>
    <message>
        <source>Specify first extension line origin:</source>
        <translation type="obsolete">Anfangspunkt der ersten Hilfslinie angeben:</translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation>Masstext eingeben:</translation>
    </message>
    <message>
        <source>Specify first extension line origin</source>
        <translation>Anfangspunkt der ersten Hilfslinie angeben</translation>
    </message>
    <message>
        <source>Specify second extension line origin</source>
        <translation>Anfangspunkt der zweiten Hilfslinie angeben</translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation>Position der Bemassungslinie angeben</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation>Ausgerichtet</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation>&amp;Ausgerichtet</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Anliegende Bemassung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimAngular</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select line</source>
        <translation type="obsolete">Linie wählen</translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation>Masstext eingeben:</translation>
    </message>
    <message>
        <source>Select first line</source>
        <translation>Erste Linie wählen</translation>
    </message>
    <message>
        <source>Select second line</source>
        <translation>Zweite Linie wählen</translation>
    </message>
    <message>
        <source>Specify dimension arc line location</source>
        <translation>Position der Bemassungslinie angeben</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation>&amp;Winkel</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Winkel Bemassung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimDiametric</name>
    <message>
        <source>Not a circle or arc entity</source>
        <translation>Kein Kreis oder Kreisbogen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select arc or circle entity</source>
        <translation>Kreisbogen oder Kreis wählen</translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation>Position der Bemassungslinie angeben</translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation>Masstext eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation>Durchmesser</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation>&amp;Durchmesser</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Durchmesser Bemassung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimLeader</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Finish</source>
        <translation>Abschliessen</translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation>Zielpunkt angeben</translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation>Nächsten Punkt angeben</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Führung</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation>&amp;Führung</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation>Führung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimLinear</name>
    <message>
        <source>Angle</source>
        <comment>command: set angle for linear dimension</comment>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first extension line origin</source>
        <translation>Anfangspunkt der ersten Hilfslinie angeben</translation>
    </message>
    <message>
        <source>Specify second extension line origin</source>
        <translation>Anfangspunkt der zweiten Hilfslinie angeben</translation>
    </message>
    <message>
        <source>Specify dimension line location</source>
        <translation>Position der Bemassungslinie angeben</translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation>Masstext eingeben:</translation>
    </message>
    <message>
        <source>Enter dimension line angle:</source>
        <translation>Winkel der Bemassungslinie eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation>Linear</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation>&amp;Linear</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Lineare Bemassung</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation>&amp;Horizontal</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Horizontale Bemassung</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation>Vertikal</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation>&amp;Vertikal</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Vertikale Bemassung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDimRadial</name>
    <message>
        <source>Not a circle or arc entity</source>
        <translation>Kein Kreis oder Kreisbogen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select arc or circle entity</source>
        <translation>Kreisbogen oder Kreis wählen</translation>
    </message>
    <message>
        <source>Specify dimension line position or enter angle:</source>
        <translation>Position der Bemassungslinie angeben oder Winkel eingeben:</translation>
    </message>
    <message>
        <source>Enter dimension text:</source>
        <translation>Masstext eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation>Radial</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation>&amp;Radial</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Radiale Bemassung</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArc</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Not a valid chord length</source>
        <translation>Ungültige Sehnenlänge</translation>
    </message>
    <message>
        <source>Specify included angle:</source>
        <translation>Eingeschlossenen Winkel angeben:</translation>
    </message>
    <message>
        <source>Specify chord length:</source>
        <translation>Sehnenlänge eingeben:</translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation>Zentrum angeben</translation>
    </message>
    <message>
        <source>Specify radius</source>
        <translation>Radius angeben</translation>
    </message>
    <message>
        <source>Specify start angle:</source>
        <translation>Startwinkel eingeben:</translation>
    </message>
    <message>
        <source>Specify end angle or [Angle/chord Length]</source>
        <translation>Endwinkel eingeben oder [Winkel/Sehnenlänge]</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation>Kreisbogen: Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation>&amp;Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation>Kreisbogen zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArc3P</name>
    <message>
        <source>Invalid arc data.</source>
        <translation>Ungültige Kreisbogen Daten.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify startpoint or [Center]:</source>
        <translation type="obsolete">Startpunkt angeben oder [Zentrum]:</translation>
    </message>
    <message>
        <source>Specify second point:</source>
        <translation type="obsolete">Zweiter Punkt angeben:</translation>
    </message>
    <message>
        <source>Specify startpoint or [Center]</source>
        <translation>Startpunkt angeben oder [Zentrum]</translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation>Zweiten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify endpoint</source>
        <translation>Endpunkt angeben</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation>Kreisbogen: 3 Punkte</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation>&amp;3 Punkte</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation>Kreisbogen mit 3 Punkten</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawArcTangential</name>
    <message>
        <source>Arc: Tangential</source>
        <translation>Bogen: Tangential</translation>
    </message>
    <message>
        <source>&amp;Tangential</source>
        <translation>&amp;Tangential</translation>
    </message>
    <message>
        <source>Draw arcs tangential to base entity</source>
        <translation>Konstruiert Bögen tangential zu einem Basiselement</translation>
    </message>
    <message>
        <source>Specify base entity</source>
        <translation>Basiselement angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify end angle</source>
        <translation>Endwinkel angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Basiselement angeben</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation>Zentrum angeben</translation>
    </message>
    <message>
        <source>Specify radius</source>
        <translation>Radius angeben</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation>Kreis: Zentrum, Kreispunkt</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation>Zentrum, &amp;Kreispunkt</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation>Kreise mit Zentrum und Kreispunkt zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle2P</name>
    <message>
        <source>Invalid Circle data.</source>
        <translation>Ungültige Kreisdaten.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation>Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation>Zweiten Punkt angeben</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation>Kreis: 2 Punkte</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation>2 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation>Kreis mit 2 Kreispunkten  zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircle3P</name>
    <message>
        <source>Invalid circle data.</source>
        <translation>Ungültige Kreisdaten.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation>Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation>Zweiten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify third point</source>
        <translation>Dritten Punkt angeben</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation>Kreis: 3 Punkte</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation>3 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation>Kreis mit 3 Kreispunkten zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawCircleCR</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify circle center</source>
        <translation>Kreiszentrum angeben</translation>
    </message>
    <message>
        <source>Specify circle radius</source>
        <translation>Kreisradius angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation>Kreis: Zentrum, Radius</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation>Zentrum, &amp;Radius</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation>Kreis mit Zentrum und Radius zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawEllipseAxis</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify start angle</source>
        <translation>Startwinkel angeben</translation>
    </message>
    <message>
        <source>Specify ellipse center</source>
        <translation>Ellipsenzentrum angeben</translation>
    </message>
    <message>
        <source>Specify end angle</source>
        <translation>Endwinkel angeben</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Specify endpoint of major axis</source>
        <translation>Endpunkt der Hauptachse angeben</translation>
    </message>
    <message>
        <source>Specify endpoint or length of minor axis:</source>
        <translation>Endpunkt der zweiten Achse angeben oder Minor eingeben:</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation>Ellipsenbogen mit Achse</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation>Ellipsen&amp;bogen (Achse)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation>Ellipsenbogen zeichnen</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation>Elllipse mit Achsen</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation>&amp;Ellipse (Achsen)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation>Ellipse zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawHatch</name>
    <message>
        <source>Hatch</source>
        <translation>Schraffur</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation>&amp;Schraffur</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation>Erstellen von Schraffuren und Füllungen</translation>
    </message>
    <message>
        <source>Invalid hatch area. Please check that the entities chosen form one or more closed contours.</source>
        <translation>Ungültige Schraffurfläche. Bitte prüfen Sie, dass die Objekte ein oder mehrere geschlossene Konturen formen.</translation>
    </message>
    <message>
        <source>Hatch created successfully.</source>
        <translation>Schraffur erfolgreich erstellt.</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawImage</name>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation>Winkel eingeben:</translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation>Faktor eingeben:</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation>&amp;Bild</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation>Bild (Bitmap) einfügen</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLine</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Cannot close sequence of lines: Not enough entities defined yet.</source>
        <translation>Kann Liniensequenz nicht schliessen: Noch nicht genug Segmente definiert.</translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation>Kann nicht zurück: Noch nicht genug Segmente definiert.</translation>
    </message>
    <message>
        <source>Specify first point:</source>
        <translation type="obsolete">Ersten Punkt angeben:</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation>Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify next point or [%1]</source>
        <translation>Nächsten Punkt angeben oder [%1]</translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation>Nächsten Punkt angeben</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation>Linie: 2 Punkte</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation>&amp;2 Punkte</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation>Linien zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineAngle</name>
    <message>
        <source>Angle</source>
        <comment>command: set angle for angle line</comment>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation>Winkel angeben:</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Enter length:</source>
        <translation>Länge eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Specify position</source>
        <translation>Position angeben</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation>Linie: Winkel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation>&amp;Winkel</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation>Zeichnen von Linien mit gegebenem Winkel</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation>Linie: Horizontal</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation>&amp;Horizontal</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation>Zeichnen von horizontalen Linien</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation>hor./vert. Linie</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation>H&amp;orizontal / Vertikal</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation>Zeichnen von horizontalen oder vertikalen Linien</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineBisector</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select first line</source>
        <translation>Erste Linie wählen</translation>
    </message>
    <message>
        <source>Select second line</source>
        <translation>Zweite Linie wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Enter bisector length:</source>
        <translation>Länge der Winkelhalbierenden eingeben:</translation>
    </message>
    <message>
        <source>Enter number of bisectors:</source>
        <translation>Anzahl Winkelhalbierende eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation>Winkelhalbierende</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation>&amp;Winkelhalbierende</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation>Winkelhalbierende zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineFree</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Click and drag to draw a line</source>
        <translation>Klicken und ziehn um Freihandlinien zu zeichnen</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation>Linie: Freihand</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation>&amp;Freihand-Linie</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation>Freihand-Linien zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineHorVert</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation>Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Specify second point</source>
        <translation>Zweiten Punkt angeben</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation>hor./vert. Linie</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation>H&amp;orizontal / Vertikal</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation>Zeichnen von horizontalen oder vertikalen Linien</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineParallel</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..99</source>
        <translation>Keine gültige Anzahl. Versuchen Sie 1..99</translation>
    </message>
    <message>
        <source>Specify Distance &lt;%1&gt; or select entity or [Through]</source>
        <translation type="obsolete">Abstand &lt;%1&gt; angeben oder [Durch Punkt]</translation>
    </message>
    <message>
        <source>Enter number:</source>
        <translation>Anzahl eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Specify Distance &lt;%1&gt; or select entity or [%2]</source>
        <translation>Abstand &lt;%1&gt; angeben oder [%2]</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation>Parallele</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation>Para&amp;llele</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation>Parallelen zu existierenden Linien, Bögen und Kreisen</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Konzentrisch</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation>&amp;Konzentrisch</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineParallelThrough</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..99</source>
        <translation>Keine gültige Anzahl. Versuchen Sie 1..99</translation>
    </message>
    <message>
        <source>Select entity</source>
        <translation>Objekt selektieren</translation>
    </message>
    <message>
        <source>Specify through point</source>
        <translation>Durch Punkt angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation>Parallele durch Punkt</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation>Par&amp;allele durch Punkt</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation>Parallele durch einen gegebenen Punkt konstruieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLinePolygon</name>
    <message>
        <source>Not a valid number. Try 1..9999</source>
        <translation>Keine gültige Anzahl. Versuchen Sie 1..9999</translation>
    </message>
    <message>
        <source>Specify center</source>
        <translation>Zentrum angeben</translation>
    </message>
    <message>
        <source>Specify a corner</source>
        <translation>Eine Ecke angeben</translation>
    </message>
    <message>
        <source>Enter number:</source>
        <translation>Anzahl Ecken eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polygon</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation>Pol&amp;ygon (Zentrum,Ecke)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation>Polygon mit Zentrum und Ecke zeichnen</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLinePolygon2</name>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Not a valid number. Try 1..9999</source>
        <translation>Keine gültige Anzahl. Versuchen Sie 1..9999</translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Not a valid expression.</source>
        <translation>Kein gültiger Befehl.</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation>Polygon</translation>
    </message>
    <message>
        <source>Polygo&amp;n (Cor,Cor)</source>
        <translation>Polygo&amp;n (2 Ecken)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation>Polygon mit zwei gegebenen Ecken zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLinePolyline</name>
    <message>
        <source>Polyline</source>
        <translation type="obsolete">Polylinie</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="obsolete">&amp;Polylinie</translation>
    </message>
    <message>
        <source>Draw polylines</source>
        <translation type="obsolete">Polylinien zeichnen</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="obsolete">Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify next point or [%1]</source>
        <translation type="obsolete">Nächsten Punkt angeben oder [%1]</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation type="obsolete">Nächsten Punkt angeben</translation>
    </message>
    <message>
        <source>Cannot close sequence of lines: Not enough entities defined yet.</source>
        <translation type="obsolete">Kann Liniensequenz nicht schliessen: Noch nicht genug Segmente definiert.</translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation type="obsolete">Kann nicht zurück: Noch nicht genug Segmente definiert.</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineRectangle</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rechteck</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation>&amp;Rechteck</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation>Zeichnen von Rechtecken</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineRelAngle</name>
    <message>
        <source>Angle</source>
        <comment>command: set angle for angle line</comment>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select base entity</source>
        <translation>Basis Objekt wählen</translation>
    </message>
    <message>
        <source>Specify position</source>
        <translation>Position angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation>Relativer Winkel</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation>R&amp;elativer Winkel</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation>Linien mit relativem Winkel zu einem Objekt zeichnen</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation>Orthogonal</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation>&amp;Orthogonal</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation>Orthogonale Linien zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineTangent1</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation>Punkt angeben</translation>
    </message>
    <message>
        <source>Select circle or arc</source>
        <translation type="obsolete">Kreisbogen oder Kreis wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select circle, arc or ellipse</source>
        <translation>Kreisbogen, Kreis oder Ellipse wählen</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation>Tangente (P,K)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation>&amp;Tangente (P,K)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation>Tangente von einemPunkt an einen Kreis zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawLineTangent2</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select first circle or arc</source>
        <translation>Ersten Kreisbogen oder Kreis wählen</translation>
    </message>
    <message>
        <source>Select second circle or arc</source>
        <translation>Zweiten Kreisbogen oder Kreis wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation>Tangente (K,K)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation>Tan&amp;gente (K,K)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation>Tangente von Kreis zu Kreis zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawPoint</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify location</source>
        <translation>Position angeben</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Punkte</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation>&amp;Punkte</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation>Punkte zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawPolyline</name>
    <message>
        <source>Polyline</source>
        <translation type="obsolete">Polylinie</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="obsolete">&amp;Polylinie</translation>
    </message>
    <message>
        <source>Draw polylines</source>
        <translation type="obsolete">Polylinien zeichnen</translation>
    </message>
    <message>
        <source>Specify first point</source>
        <translation type="obsolete">Ersten Punkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify next point or [%1]</source>
        <translation type="obsolete">Nächsten Punkt angeben oder [%1]</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Specify next point</source>
        <translation type="obsolete">Nächsten Punkt angeben</translation>
    </message>
    <message>
        <source>Cannot close sequence of lines: Not enough entities defined yet.</source>
        <translation type="obsolete">Kann Liniensequenz nicht schliessen: Noch nicht genug Segmente definiert.</translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation type="obsolete">Kann nicht zurück: Noch nicht genug Segmente definiert.</translation>
    </message>
    <message>
        <source>Draw</source>
        <translation type="obsolete">Erstellen</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation type="obsolete">&amp;Zeichnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawSpline</name>
    <message>
        <source>Spline</source>
        <translation>Spline Kurve</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>&amp;Spline Kurve</translation>
    </message>
    <message>
        <source>Draw splines</source>
        <translation>Splines zeichnen</translation>
    </message>
    <message>
        <source>Specify first control point</source>
        <translation>Ersten Kontrollpunkt bestimmen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify next control point or [%1]</source>
        <translation>Nächsten Kontrollpunkt bestimmen oder [%1]</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify next control point</source>
        <translation>Nächsten Kontrollpunkt bestimmen</translation>
    </message>
    <message>
        <source>Cannot undo: Not enough entities defined yet.</source>
        <translation>Kann nicht zurück: Noch nicht genug Segmente definiert.</translation>
    </message>
</context>
<context>
    <name>RS_ActionDrawText</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Enter text:</source>
        <translation>Text eingeben:</translation>
    </message>
    <message>
        <source>Specify insertion point</source>
        <translation>Einfügepunkt angeben</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation>&amp;Text</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation>Text Objekt erstellen</translation>
    </message>
</context>
<context>
    <name>RS_ActionEditCopy</name>
    <message>
        <source>Set Reference Point:</source>
        <translation type="obsolete">Referenzpunkt setzen:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation>Kopiert Objekte auf die Zwischenablage</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Aus&amp;schneiden</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation>Schneidet Objekte aus auf die Zwischenablage</translation>
    </message>
</context>
<context>
    <name>RS_ActionEditPaste</name>
    <message>
        <source>Set Reference Point:</source>
        <translation type="obsolete">Referenzpunkt setzen:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Set reference point</source>
        <translation>Einfügepunkt angeben</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Ein&amp;fügen</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation>Fügt den Inhalt der Zwischenablage ein</translation>
    </message>
</context>
<context>
    <name>RS_ActionEditUndo</name>
    <message>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Rückgängig</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation>Macht die letzte Änderung rückgängig</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Wieder herstellen</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Wieder herstellen</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation>Stellt die zuletzt zurückgenommene Änderung wieder her</translation>
    </message>
</context>
<context>
    <name>RS_ActionFileNew</name>
    <message>
        <source>New Drawing</source>
        <translation>Neue Zeichnung</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Neu</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation>Erstellt eine neue Zeichnung</translation>
    </message>
</context>
<context>
    <name>RS_ActionFileOpen</name>
    <message>
        <source>Open Drawing</source>
        <translation>Zeichnung öffnen</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation>Ö&amp;ffnen...</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation>Öffnet eine bestehende Zeichnung</translation>
    </message>
</context>
<context>
    <name>RS_ActionFileSave</name>
    <message>
        <source>Save Drawing</source>
        <translation>Zeichnung speichern</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Speichern</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation>Speichert die aktuelle Zeichnung</translation>
    </message>
</context>
<context>
    <name>RS_ActionFileSaveAs</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Zeichnung speichern als</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation>Speichern &amp;unter...</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation>Speichert die aktuelle Zeichnung unter einem neuen Dateinamen</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoAngle</name>
    <message>
        <source>Angle: %1%2</source>
        <translation>Winkel: %1%2</translation>
    </message>
    <message>
        <source>Lines are parallel</source>
        <translation>Linien sind parallel</translation>
    </message>
    <message>
        <source>Specify first line</source>
        <translation>Erste Linie wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify second line</source>
        <translation>Zweite Linie wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation>Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation>&amp;Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation>Misst den Winkel zwischen zwei Linien</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoArea</name>
    <message>
        <source>Polygonal Area</source>
        <translation>Polygon Fläche</translation>
    </message>
    <message>
        <source>&amp;Polygonal Area</source>
        <translation>&amp;Polygon Fläche</translation>
    </message>
    <message>
        <source>Measures the area of a polygon</source>
        <translation>Misst die Fläche eines Polygons</translation>
    </message>
    <message>
        <source>Area: %1</source>
        <translation>Fläche: %1</translation>
    </message>
    <message>
        <source>Circumference: %1</source>
        <translation>Umfang: %1</translation>
    </message>
    <message>
        <source>Point: %1/%2</source>
        <translation>Punkt: %1/%2</translation>
    </message>
    <message>
        <source>Specify first point of polygon</source>
        <translation>Ersten Punkt des Polygons bestimmen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify next point of polygon</source>
        <translation>Nächsten Punkt des Polygons bestimmen</translation>
    </message>
    <message>
        <source>Terminate</source>
        <translation>Beenden</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoDist</name>
    <message>
        <source>Distance: %1</source>
        <translation>Abstand: %1</translation>
    </message>
    <message>
        <source>Specify first point of distance</source>
        <translation>Ersten Punkt für Distanz angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify second point of distance</source>
        <translation>Zweiten Punkt für Distanz angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation>Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation>&amp;Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation>Misst die Distanz zwischen zwei Punkten</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoDist2</name>
    <message>
        <source>Distance: %1</source>
        <translation>Abstand: %1</translation>
    </message>
    <message>
        <source>Specify entity</source>
        <translation>Objekt wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation>Punkt angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation>Abstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation>A&amp;bstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation>Misst die Distanz zwischen einem Objekt und einem Punkt</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoInside</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Point is inside selected contour.</source>
        <translation>Punkt ist innerhalb der selektierten Kontur.</translation>
    </message>
    <message>
        <source>Point is outside selected contour.</source>
        <translation>Punkt ist ausserhalb der selektierten Kontur.</translation>
    </message>
    <message>
        <source>Specify point</source>
        <translation>Punkt angeben</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation>Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation>&amp;Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation>Testet, ob ein gegebener Punkt innerhalb der selektierten Kontur liegt</translation>
    </message>
</context>
<context>
    <name>RS_ActionInfoTotalLength</name>
    <message>
        <source>Total Length of selected entities: %1</source>
        <translation>Totale Länge der selektierten Objekte: %1</translation>
    </message>
    <message>
        <source>At least one of the selected entities cannot be measured.</source>
        <translation>Mindestens eines der selektierten Objekte kann nicht gemessen werden.</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation>&amp;Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation>Misst die totale Länge aller ausgewählen Elemente</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersAdd</name>
    <message>
        <source>Add Layer</source>
        <translation>Layer hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>Layer &amp;hinzufügen</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersEdit</name>
    <message>
        <source>Edit Layer</source>
        <translation>Layer editieren</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>Layer &amp;editieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersFreezeAll</name>
    <message>
        <source>Freeze all</source>
        <translation>Alle einfrieren</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation>Alle ein&amp;frieren</translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation>Alle Layer einfrieren</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation>Alle auftauen</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation>Alle auf&amp;tauen</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation>Alle Layer auftauen</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersRemove</name>
    <message>
        <source>Remove Layer</source>
        <translation>Layer löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>Layer &amp;löschen</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersToggleLock</name>
    <message>
        <source>Toggle Layer Lock</source>
        <translation>Layer Sperre umschalten</translation>
    </message>
    <message>
        <source>&amp;Toggle Lock</source>
        <translation>&amp;Sperre umschalten</translation>
    </message>
    <message>
        <source>Toggle Lock</source>
        <translation>Sperre umschalten</translation>
    </message>
</context>
<context>
    <name>RS_ActionLayersToggleView</name>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation>Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation>&amp;Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation>Sichtbarkeit des Layers ändern</translation>
    </message>
</context>
<context>
    <name>RS_ActionLibraryInsert</name>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Enter angle:</source>
        <translation>Winkel eingeben:</translation>
    </message>
    <message>
        <source>Enter factor:</source>
        <translation>Faktor eingeben:</translation>
    </message>
    <message>
        <source>Insert Library Object</source>
        <translation>Objekt aus Bibliothek einfügen</translation>
    </message>
    <message>
        <source>&amp;Insert Library Object</source>
        <translation>Objekt aus Bibliothek &amp;einfügen</translation>
    </message>
    <message>
        <source>Inserts an Object from the part library.</source>
        <translation>Fügt ein Objekt aus der Teile Bibliothek ein.</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot open file &apos;%1&apos;</source>
        <translation>Kann Datei &apos;%1&apos; nicht öffnen</translation>
    </message>
</context>
<context>
    <name>RS_ActionLockRelativeZero</name>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation>Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation>Relativen Nullpunkt &amp;festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation>Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Attribute</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation>&amp;Attribute</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation>Objekt Attribute editieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyBevel</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select first entity</source>
        <translation>Erstes Objekt wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select second entity</source>
        <translation>Zweites Objekt wählen</translation>
    </message>
    <message>
        <source>Enter length 1:</source>
        <translation>Länge 1 eingeben:</translation>
    </message>
    <message>
        <source>Enter length 2:</source>
        <translation>Länge 2 eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Abschrägen</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation>&amp;Abschrägen</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation>Ecken abschrägen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyCut</name>
    <message>
        <source>No Entity found.</source>
        <translation>Kein Objekt gefunden.</translation>
    </message>
    <message>
        <source>Cut point is invalid.</source>
        <translation type="obsolete">Schnittpunkt ist ungültig.</translation>
    </message>
    <message>
        <source>Cut point is not on entity.</source>
        <translation type="obsolete">Schnittpunkt ist nicht auf Objekt.</translation>
    </message>
    <message>
        <source>Specify entity to cut</source>
        <translation>Zu schneidendes Objekt wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify cutting point</source>
        <translation>Schnittpunkt angeben</translation>
    </message>
    <message>
        <source>Entity must be a line, arc or circle.</source>
        <translation>Objekt muss eine Linie, ein Kreis oder ein Kreisbogen sein.</translation>
    </message>
    <message>
        <source>Cutting point is invalid.</source>
        <translation>Schnittpunkt ist ungültig.</translation>
    </message>
    <message>
        <source>Cutting point is not on entity.</source>
        <translation>Schnittpunkt liegt nicht auf Objekt.</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation>T&amp;rennen</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation>Objekte trennen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDelete</name>
    <message>
        <source>Acknowledge</source>
        <translation type="obsolete">Bestätigen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation>Objekte löschen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDeleteFree</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first break point on a polyline</source>
        <translation>Erste Bruchstelle auf Polylinie angeben</translation>
    </message>
    <message>
        <source>Specify second break point on the same polyline</source>
        <translation>Zweite Bruchstelle auf Polylinie angeben</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation>Freihand löschen</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation>&amp;Freihand Löschen</translation>
    </message>
    <message>
        <source>Entities not in the same polyline.</source>
        <translation>Elemente nicht in der gleichen Polylinie.</translation>
    </message>
    <message>
        <source>Parent of second entity is not a polyline</source>
        <translation>Zweites Element nicht in Polylinie</translation>
    </message>
    <message>
        <source>Parent of second entity is NULL</source>
        <translation>Zweites Element ist NULL</translation>
    </message>
    <message>
        <source>One of the chosen entities is NULL</source>
        <translation>Eines der Elemente ist NULL</translation>
    </message>
    <message>
        <source>Parent of first entity is not a polyline</source>
        <translation>Erstes Element nicht in Polylinie</translation>
    </message>
    <message>
        <source>Parent of first entity is NULL</source>
        <translation>Erstes Element ist NULL</translation>
    </message>
    <message>
        <source>First entity is NULL</source>
        <translation>Erstes Element ist NULL</translation>
    </message>
    <message>
        <source>Second entity is NULL</source>
        <translation>Zweites Element ist NULL</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyDeleteQuick</name>
    <message>
        <source>Pick entity to delete</source>
        <translation>Objekt zum Löschen wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation>Selektierte Objekte löschen</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation>Selektierte &amp;löschen</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation>Selektierte Objekte löschen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyEntity</name>
    <message>
        <source>Properties</source>
        <translation>Eigenschaften</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation>&amp;Eigenschaften</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation>Objekt Eigenschaften bearbeiten</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyExplodeText</name>
    <message>
        <source>Explode Text</source>
        <translation>Text aufbrechen</translation>
    </message>
    <message>
        <source>&amp;Explode Text into Letters</source>
        <translation>&amp;Text in Buchstaben aufbrechen</translation>
    </message>
    <message>
        <source>Explodes Text Entities into single Letters</source>
        <translation>Bricht Texte in einzelne Buchstaben auf</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMirror</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify first point of mirror line</source>
        <translation>Ersten Punkt der Spiegelachse angeben</translation>
    </message>
    <message>
        <source>Specify second point of mirror line</source>
        <translation>Zweiten Punkt der Spiegelachse angeben</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Spiegeln</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation>S&amp;piegeln</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation>Objekte spiegeln</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMove</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation>Zielpunkt angeben</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Verschieben</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Verschieben</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Objekte verschieben / kopieren</translation>
    </message>
    <message>
        <source>Move / Copy</source>
        <translation>Verschieben / Kopieren</translation>
    </message>
    <message>
        <source>&amp;Move / Copy</source>
        <translation>&amp;Verschieben / Kopieren</translation>
    </message>
    <message>
        <source>Move or copy entities one or multiple times</source>
        <translation>Verschiebt oder kopiert Objekte einmal oder mehrere Male</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyMoveRotate</name>
    <message>
        <source>Angle</source>
        <comment>command: set angle for move / rotate</comment>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Set Angle:</source>
        <translation type="obsolete">Winkel eingeben:</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation>Zielpunkt angeben</translation>
    </message>
    <message>
        <source>Enter rotation angle:</source>
        <translation>Rotationswinkel eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Verschieben und Rotieren</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation>V&amp;erschieben und Rotieren</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation>Verschiebt und Rotiert Objekte</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRotate</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Rotieren</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation>&amp;Rotieren</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation>Objekte rotieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRotate2</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify absolute reference point</source>
        <translation>Absoluten Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify relative reference point</source>
        <translation>Relativen Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation>Rotieren Zwei</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation>Rotieren &amp;Zwei</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation>Objekte um zwei Zentren rotieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyRound</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first entity</source>
        <translation>Erstes Objekt wählen</translation>
    </message>
    <message>
        <source>Specify second entity</source>
        <translation>Zweites Objekt wählen</translation>
    </message>
    <message>
        <source>Enter radius:</source>
        <translation>Radius eingeben:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Runden</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation>&amp;Runden</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation>Ecken runden</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyScale</name>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Skalieren</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation>&amp;Skalieren</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation>Objekte skalieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyStretch</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first corner</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Specify second corner</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Specify reference point</source>
        <translation>Referenzpunkt angeben</translation>
    </message>
    <message>
        <source>Specify target point</source>
        <translation>Zielpunkt angeben</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Strecken</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation>&amp;Strecken</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation>Objektgruppen strecken</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyTrim</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select first trim entity</source>
        <translation>Erstes zu trimmendes Objekt wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Select limiting entity</source>
        <translation>Limitierendes Objekt wählen</translation>
    </message>
    <message>
        <source>Select second trim entity</source>
        <translation>Zweites zu trimmendes Objekt wählen</translation>
    </message>
    <message>
        <source>Select entity to trim</source>
        <translation>Zu trimmendes Objekt wählen</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Trimmen</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation>&amp;Trimmen</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation>Objekte trimmen</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation>Trimmen Zwei</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation>&amp;Trimmen Zwei</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation>Zwei Objekte trimmen</translation>
    </message>
</context>
<context>
    <name>RS_ActionModifyTrimAmount</name>
    <message>
        <source>No entity found. </source>
        <translation>Kein Objekt gefunden.</translation>
    </message>
    <message>
        <source>The chosen Entity is in a block. Please edit the block.</source>
        <translation>Das gewählte Objekt ist Teil eines Blocks. Bitte editieren Sie den Block.</translation>
    </message>
    <message>
        <source>The chosen Entity is not an atomic entity or cannot be trimmed.</source>
        <translation>Das gewählte Objekt ist kein atomares Objekt oder kann nicht getrimmt werden.</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select entity to trim or enter distance:</source>
        <translation>Zu trimmendes Objekt wählen oder Trimlänge eingeben:</translation>
    </message>
    <message>
        <source>Not a valid expression</source>
        <translation>Ungültiger Ausdruck</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation>Verlängern</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation>&amp;Verlängern</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation>Um einen gegebenen Betrag verlängern</translation>
    </message>
</context>
<context>
    <name>RS_ActionOptionsDrawing</name>
    <message>
        <source>Drawing</source>
        <translation>Zeichnung</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation>&amp;Zeichnungseinstellungen</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation>Einstellungen für die aktuelle Zeichnung</translation>
    </message>
</context>
<context>
    <name>RS_ActionPolylineAdd</name>
    <message>
        <source>Add node to Polyline</source>
        <translation type="obsolete">Knoten zu Polylinie hinzufügen</translation>
    </message>
    <message>
        <source>Add &amp;node to Polyline</source>
        <translation type="obsolete">K&amp;noten zu Polylinie hinzufügen</translation>
    </message>
    <message>
        <source>Adds nodes to existing polylines</source>
        <translation type="obsolete">Fügt Knoten zu existierenden Polylinien hinzu</translation>
    </message>
    <message>
        <source>Polyline was not modified</source>
        <translation type="obsolete">Polylinie wurde nicht verändert</translation>
    </message>
    <message>
        <source>Specify polyline segment</source>
        <translation type="obsolete">Polylinien-Segment angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify new node</source>
        <translation type="obsolete">Neuen Knoten angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Polylinien-Segment angeben</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation type="obsolete">Knoten hinzufügen</translation>
    </message>
    <message>
        <source>Add &amp;node</source>
        <translation type="obsolete">Knoten &amp;hinzufügen</translation>
    </message>
</context>
<context>
    <name>RS_ActionPolylineAppend</name>
    <message>
        <source>Append node to Polyline</source>
        <translation type="obsolete">Knoten an Polylinie anfügen</translation>
    </message>
    <message>
        <source>Append &amp;node to Polyline</source>
        <translation type="obsolete">Knoten an Polylinie &amp;anfügen</translation>
    </message>
    <message>
        <source>Appends nodes to existing polylines</source>
        <translation type="obsolete">Hängt Knoten an existierende Polylinien an</translation>
    </message>
    <message>
        <source>Cannot append to closed polyline.</source>
        <translation type="obsolete">Kann nicht an geschlossene Polylinie anfügen.</translation>
    </message>
    <message>
        <source>No polyline entity found.</source>
        <translation type="obsolete">Keine Polylinie gefunden.</translation>
    </message>
    <message>
        <source>Specify polyline segment</source>
        <translation type="obsolete">Polylinien-Segment angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Append node</source>
        <translation type="obsolete">Knoten anhängen</translation>
    </message>
    <message>
        <source>Append &amp;node</source>
        <translation type="obsolete">Knoten &amp;anhängen</translation>
    </message>
</context>
<context>
    <name>RS_ActionPolylineDel</name>
    <message>
        <source>Delete Polyline node</source>
        <translation type="obsolete">Polylinien Knoten löschen</translation>
    </message>
    <message>
        <source>&amp;Delete Polyline node</source>
        <translation type="obsolete">Polylinien Knoten &amp;löschen</translation>
    </message>
    <message>
        <source>Deletes nodes in existing polylines</source>
        <translation type="obsolete">Löscht Knoten aus existierenden Polylinien</translation>
    </message>
    <message>
        <source>No polyline found</source>
        <translation type="obsolete">Keine Polylinie gefunden</translation>
    </message>
    <message>
        <source>Specify polyline</source>
        <translation type="obsolete">Polylinie angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify node to delete</source>
        <translation type="obsolete">Zu löschender Knoten angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation type="obsolete">Knoten löschen</translation>
    </message>
    <message>
        <source>&amp;Delete node</source>
        <translation type="obsolete">Knoten &amp;löschen</translation>
    </message>
</context>
<context>
    <name>RS_ActionPolylineDelBetween</name>
    <message>
        <source>Delete Polyline nodes between two points</source>
        <translation type="obsolete">Knoten zwischen zwei Knoten löschen</translation>
    </message>
    <message>
        <source>&amp;Delete Polyline nodes between two points</source>
        <translation type="obsolete">Knoten zwischen zwei Knoten &amp;löschen</translation>
    </message>
    <message>
        <source>Deletes all nodes between two points in existing polylines</source>
        <translation type="obsolete">Löscht alle Knoten zwischen zwei Punkten in existierenden Polylinien</translation>
    </message>
    <message>
        <source>No polyline found</source>
        <translation type="obsolete">Keine Polylinie gefunden</translation>
    </message>
    <message>
        <source>Specify polyline</source>
        <translation type="obsolete">Polylinie angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify first limiting node</source>
        <translation type="obsolete">Ersten begrenzenden Knoten angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Specify second limiting node</source>
        <translation type="obsolete">Zweiten begrenzenden Knoten angeben</translation>
    </message>
    <message>
        <source>Delete segments between two nodes</source>
        <translation type="obsolete">Segmente zwischen zwei Knoten löschen</translation>
    </message>
    <message>
        <source>&amp;Delete segments between two nodes</source>
        <translation type="obsolete">Segmente &amp;zwischen zwei Knoten löschen</translation>
    </message>
    <message>
        <source>Deletes all segments between two nodes in existing polylines</source>
        <translation type="obsolete">Löscht alle Segmente zwischen zwei Knoten in existierenden Polylinien</translation>
    </message>
</context>
<context>
    <name>RS_ActionPolylineTrim</name>
    <message>
        <source>Trim polyline segments</source>
        <translation type="obsolete">Polylinien Segmente trimmen</translation>
    </message>
    <message>
        <source>&amp;Trim polyline segments</source>
        <translation type="obsolete">Polylinien Segmente &amp;trimmen</translation>
    </message>
    <message>
        <source>Trims two polyline segments and deletes all nodes in between</source>
        <translation type="obsolete">Trimmt zwei Polylinien Segmente und löscht alle Knoten dazwischen</translation>
    </message>
    <message>
        <source>No polyline segment found</source>
        <translation type="obsolete">Keine Polylinie gefunden</translation>
    </message>
    <message>
        <source>Specify first segment</source>
        <translation type="obsolete">Erstes Segment wählen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Specify second segment</source>
        <translation type="obsolete">Zweites Segment wählen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation type="obsolete">Segmente trimmen</translation>
    </message>
    <message>
        <source>&amp;Trim segments</source>
        <translation type="obsolete">Segmente &amp;trimmen</translation>
    </message>
</context>
<context>
    <name>RS_ActionPrintPreview</name>
    <message>
        <source>Print Preview</source>
        <translation>Druckvorschau</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation>Druck&amp;vorschau</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation>Zeigt Druckvorschau an</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectAll</name>
    <message>
        <source>Select All</source>
        <translation>Alles selektieren</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation>&amp;Alles selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation>Selektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Deselektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation>&amp;Alles Deselktieren</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation>Deselektiert alle sichtbaren Objekte</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectContour</name>
    <message>
        <source>Entity must be an Atomic Entity.</source>
        <translation>Objekt muss atomar sein.</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation>Kontur (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation>&amp;Konturen (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation>(De-)selektiert verbundene Objekte (Konturen)</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectIntersected</name>
    <message>
        <source>Choose first edge</source>
        <translation type="obsolete">Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Choose second edge</source>
        <translation type="obsolete">Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Choose first point of intersection line</source>
        <translation>Anfangspunkt der Schnittlinie angeben</translation>
    </message>
    <message>
        <source>Choose second point of intersection line</source>
        <translation>Endpunkt der Schnittlinie angeben</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation>Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation>&amp;Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation>Selektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation>Geschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation>G&amp;eschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation>Deselektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectInvert</name>
    <message>
        <source>Invert Selection</source>
        <translation>Selektion invertieren</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation>Selektion &amp;invertieren</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation>Invertiert die aktuelle Selektion</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectLayer</name>
    <message>
        <source>(De-)Select Layer</source>
        <translation>Layer (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation>(De-)selektiert alle Objekte auf einem Layer</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectSingle</name>
    <message>
        <source>Select Entity</source>
        <translation>Objekt selektieren</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation>Objekte (de-)&amp;selektieren</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation>Einzelne Objekte selektieren</translation>
    </message>
</context>
<context>
    <name>RS_ActionSelectWindow</name>
    <message>
        <source>Choose first edge</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Choose second edge</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Bereich selektieren</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation>&amp;Bereich selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation>Selektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation>&amp;Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation>Deselektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
</context>
<context>
    <name>RS_ActionSetRelativeZero</name>
    <message>
        <source>Set relative Zero</source>
        <translation>Relativen Nullpunkt setzen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation>Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation>&amp;Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation>Position des relativen Nullpunktes neu setzten</translation>
    </message>
</context>
<context>
    <name>RS_ActionSnapIntersectionManual</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Select first entity</source>
        <translation>Erstes Objekt wählen</translation>
    </message>
    <message>
        <source>Select second entity</source>
        <translation>Zweites Objekt wählen</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation>Schnittpunkt manuell</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation>Sch&amp;nittpunkt manuell</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation>Schnittpunkte manuell fangen</translation>
    </message>
</context>
<context>
    <name>RS_ActionToolRegenerateDimensions</name>
    <message>
        <source>Regenerate Dimension Entities</source>
        <translation>Bemassungen regenerieren</translation>
    </message>
    <message>
        <source>&amp;Regenerate Dimension Entities</source>
        <translation>Bemassungen &amp;regenerieren</translation>
    </message>
    <message>
        <source>Regenerates all Dimension Entities</source>
        <translation>Regeneriert alle Bemassungen</translation>
    </message>
    <message>
        <source>Regenerated %1 dimension entities</source>
        <translation>%1 Bemassungen regeneriert</translation>
    </message>
    <message>
        <source>No dimension entities found</source>
        <translation>Keine Bemassungen gefunden</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomAuto</name>
    <message>
        <source>Auto Zoom</source>
        <translation>Auto Ansicht</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation>&amp;Auto Ansicht</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation>Zeigt die ganze Zeichnung</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomIn</name>
    <message>
        <source>Zoom in</source>
        <translation>Ansicht vergrössern</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Ansicht ver&amp;grössern</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation>Vergrössert die Ansicht</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Ansicht verkleinern</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation>Ansicht ver&amp;kleinern</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation>Verkleinert die Ansicht</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomPan</name>
    <message>
        <source>Pan Zoom</source>
        <translation>Ansicht verschieben</translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation>Ansicht &amp;verschieben</translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation>Echtzeit verschieben</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomPrevious</name>
    <message>
        <source>Previous View</source>
        <translation>Vorherige Ansicht</translation>
    </message>
    <message>
        <source>&amp;Previous View</source>
        <translation>&amp;Vorherige Ansicht</translation>
    </message>
    <message>
        <source>Shows previous view</source>
        <translation>Zeigt die letzte Ansicht</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomRedraw</name>
    <message>
        <source>Redraw</source>
        <translation>Neu aufbauen</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation>&amp;Neu aufbauen</translation>
    </message>
</context>
<context>
    <name>RS_ActionZoomWindow</name>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Specify first edge</source>
        <translation>Erste Ecke angeben</translation>
    </message>
    <message>
        <source>Specify second edge</source>
        <translation>Zweite Ecke angeben</translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation>Fenster Zoom</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation>&amp;Fenster Zoom</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation>Vergrössert einen Ausschnitt</translation>
    </message>
</context>
</TS>
