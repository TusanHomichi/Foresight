./configure
MinGW32-make
