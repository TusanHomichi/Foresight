class MyDxfFilter : public DL_CreationAdapter {
    virtual void addLine(const DL_LineData& d);
    ...
}
