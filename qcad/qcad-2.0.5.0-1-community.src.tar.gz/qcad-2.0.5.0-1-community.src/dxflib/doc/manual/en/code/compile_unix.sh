./configure
make
