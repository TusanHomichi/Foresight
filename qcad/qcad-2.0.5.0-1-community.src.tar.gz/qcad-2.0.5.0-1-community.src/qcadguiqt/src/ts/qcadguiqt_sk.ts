<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Tlačiť</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Koniec</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">&amp;Koniec</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>Ukončí aplikáciu</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Vystrihnúť</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">Označ/Odznač obrysy</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">Označí/Odznačí obrysy objektu</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Čiara: Polpriamka</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Polpriamka</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Nakreslí polpriamku z daného bodu</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Čiara: Vodorovná</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Vodorovná</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Kresli vodorovné čiari</translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Čiara: Zvislá</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Zvislá</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Kresli zvislé čiary</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Kolmica</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">Ko&amp;lmica</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Kresli kolmú čiaru</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Kružnica: 3 body</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 body</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Kresli kružnicu zadaním 3 bodov</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Zrkadli</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">&amp;Zrkadli</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Zrkadli objekty</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Orež</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">&amp;Orež</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Orež objekty</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Orež dva</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">Orež &amp;dva</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Orež dva objekty</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Predĺženie</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">&amp;Predĺženie</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Predĺženie podľa zadanej hodnoty</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">&amp;Vystrihnúť</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Vystrihni objekty</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>Voľné</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>&amp;Voľné</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Voľné prichitávanie</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Mriežka</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Mriežka</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>Prichitávanie podľa mriežky</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>Koncové body</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>&amp;Koncové body</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>Prichitávanie ku koncovým bodom</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>K objektu</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>K &amp;objektu</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>Prichitávanie k najbližšiemu bodu objektu</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Stred</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>&amp;Stred</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>Prichitávanie ku stredu</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Polovica</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>&amp;Polovica</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Prichitávanie k polovici objektov</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>Vzdialenosť od koncových bodov</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>&amp;Vzdialenosť od konc. bodov</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>Prichitávanie v zadanej vzdialenosti od koncových bodov</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>Priesečník</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>&amp;Priesečník</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>Prichitávanie k priesečníkom</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>Žiadne ohraničenie</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>Žiadne &amp;ohraničenie</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>Žiadne ohraničenie pri prichitávaní</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>Pravouhlé ohraničenie</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>&amp;Pravouhlé ohraničenie</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>Pravouhlé ohraničenie pri prichitávaní</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>Horizontálne ohraničenie</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>&amp;Horizontálne ohraničenie</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>Horizontálne ohraničenie pri prichitávaní</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>Vertikálne ohraničenie</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>&amp;Vertikálne ohraničenie</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>Vertikálne ohraničenie pri prichitávaní</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Odomkni všetky</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">&amp;Odomkni všetky</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Odomkne všetky hladiny</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Zamkni všetky</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">&amp;Zamkni všetky</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Odomkni všetky bloky</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Zamkni všetky bloky</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Pridaj blok</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">&amp;Pridaj blok</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Vymaž blok</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">&amp;Vymaž blok</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Premenuj blok</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">P&amp;remenuj blok</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Premenuje blok a všetky vložené</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Uprav blok</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">&amp;Uprav blok</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Vlož blok</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">&amp;Vlož blok</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Prepni viditeľnosť bloku</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">&amp;Prepni blok</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Prepni blok</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Rozbi</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">&amp;Rozbi</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Rozbi blok a ostatné skupiny objektov</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>Hlavné nastavenia aplikácie</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>Zatvorí aktuálny výkres</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>Vytlačí aktuálny výkres</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>Zatvor výkres</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>Vytlač výkres</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">O&amp;znač/Odznač obrysy</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>Exportuj výkres</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Exportuj..</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>Exportuje aktuálny výkres ako bitovú mapu</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>Aplikácia</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>&amp;Nastavenia</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>Zapne/Vypne mriežku</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Kružnica: sústredná</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Sústredná</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Kresli sústredné kružnice do existujúcej kružnice</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Oblúk: sústredný</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Kresli sústredný oblúk do existujúceho oblúku</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Stavový riadok</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>&amp;Stavový riadok</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>Zapne/vypne stavový riadok</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Náčrt</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>&amp;Náčrt</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>Zapne/Vypne režim náčrtu</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>Otvor IDE</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>&amp;Otvor IDE</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>Otvorí integtované vývojové prostredie pre tvorbu skriptov</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>Spusť skript..</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>&amp;Spusť skript..</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>Spustí skript</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>&amp;Nastavenia</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Tlač...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Koniec</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Koniec</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>Vlastnosti oblúku</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>Pravotočivý</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>Ľavotočivý</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="unfinished">Polomer:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>Vlastnosti skosenia</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Orezanie</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>Pokús sa orezať obidva objekty</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>Vzdialenosť 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>Vzdialenosť 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>Nastavenia bloku</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>Názov bloku:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>Premenovanie bloku</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>Nemôžem pomenovať blok. Blok s menom &quot;%1&quot; už existuje.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Add a block</source>
        <translation>Pridaj blok</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>Vymaž aktívny blok</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>Premenuj aktívny blok</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>Uprav aktívny blok
v inom okne</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>Vlož aktívny blok</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>Menu bloku</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>&amp;Odomkni všetky bloky</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>&amp;Zamkni všeky bloky</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>&amp;Pridaj blok</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>&amp;Vymaž blok</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>&amp;Uprav blok</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>P&amp;repni viditeľnosť</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>Zobraz všetky bloky</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>Skry všetky bloky</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>P&amp;remenuj blok</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>&amp;Vlož blok</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>&amp;Vytvor nový blok</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>CAD nástroje</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>Oblúky</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>Oblúk pomocou troch bodov</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>Oblúk pomocou Stredu, Bodu, Uhla</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Sústredný</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation>Kružnice</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>Kružnica pomocou dvoch protiľahlých bodov</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>Kružnica pomocou stredu a polomeru</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>Kružnica pomocou stredu a bodu</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>Kružnica pomocou troch bodov</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Sústredný</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>Kóty</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Kótovanie priemeru</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Kótovanie polomeru</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Vertikálna kóta</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Horizontálna kóta</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Lineárna kóta</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Zarovnaná kóta podľa objektu</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Kótovanie uhla</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Šípka</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>Elipsy</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>Elipsa pomocou stredu, dvoch bodov a uhla</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>Elipsa pomocou stredu a dvoch bodov</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>Informácie</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>Vzdialenosť (bod, bod)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>Vzdialenosť (objekt, bod)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Uhol</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Celková dĺžka zvolených objektov</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>Čiary</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>Voľné čiary</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>Kolmé čiary</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>Osi</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>Dotyčnica z kružnice na kružnicu</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>Dotyčnica z bodu na kružnicu</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>Čiara pomocou dvoch bodov</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>Čiary pod relatívnym uhlom</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>Čiara pod zadaným uhlom</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>Vodorovné čiary</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>Zvislé čiary</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>Obdĺžniky</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>Mnohouholníky zadaním stredu a počtu strán</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>Mnohouholníky zadaním dvoch strán</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>Rovnobežky so vzdialenosťou</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>Rovnobežky cez bod</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>Hlavné</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>Zobraz menu &quot;Čiary&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>Zobraz menu &quot;Oblúky&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>Zobraz menu &quot;Kružnice&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Points&quot;</source>
        <translation type="obsolete">Zobraz menu &quot;Body&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>Zobraz menu &quot;Rozmery&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>Zobraz menu &quot;Elipsy&quot;</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>Šráfy/Výplne</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>Zobraz menu &quot;Úpravy&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>Zobraz menu &quot;Kóty&quot;</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>Texty</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>Zobraz menu &quot;Označenie&quot;</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Vytvor blok</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>Rastrový obrázok</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="unfinished">Body</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>Uprav</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Otočenie</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Mierka</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Posunutie</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Posunutie a otočenie</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation>Rozbi</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Vymaž</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Roztiahnúť</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Zaoblenie</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Skosiť</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>Orež o hodnotu</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>Orež / Predĺž č. 2</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>Orež / Predĺž</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>Otočenie okolo dvoch stredov</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>Uprav atribúty objektu</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>Uprav rozmery objektu</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Zrkadli</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Rozdeľ</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>Rozbije text na znaky</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Uprav text</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>Body</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>Samostatné body</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished">Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append node</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>Označ</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Označ všetko</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>Označ preseknuté objekty</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>Odznač preseknuté objekty</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznač všetko</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>Invertuj výber</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>Označ haldinu</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>Označ/Odznač obrysy</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>Označ/Odznač objekt</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Odznač okno</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Označ okno</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>Pokračuj v akcii</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>Prichitávanie</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>Prichitávanie k mriežke</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Voľné prichitávanie</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>Prichitávanie ku koncovým bodom</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>Prichitávanie k najbližšiemu bodu objektu</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>Prichitávanie k stredovým bodom</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Prichitávanie k polovici objektov</translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>Prichitávanie v zadanej vzdialenosti od koncových bodov</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>Manuálne prichitávanie k priesečníkom</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>Žiadne ohraničenie</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>Pravouhlé ohraničenie</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>Horizontálne ohraničenie</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>Vertikálne ohraničenie</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>Presunutie relatívnej nuly</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>Zamkni relatívnu nulu</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>Manuálne prichitávanie k priesečníkom</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished">Späť do hlavného menu</translation>
    </message>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>Nastavenia kružníc</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Polomer:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>Podľa hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Podľa bloku</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Žltá</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Zelenomodrá</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Purpurová</translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>Čierna / Biela</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Sivá</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Svetlosivá</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>Iná..</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Nezmenená</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>Príkazový riadok</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Príkaz:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>Koordináty</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>Nastavenia lineárnych rozmerov</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>Nastavenia rozmerov</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Menovka:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation>ø</translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation>°</translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation>±</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation>¶</translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation>×</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation>÷</translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>Editor menoviek kót</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>Menovka kóty:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Menovka:</translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>Vložiť:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation>ø (Polomer)</translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (Stupeň)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation>± (Plus / Mínus)</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation>¶ (Pí)</translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>× (Krát)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (Delenie)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>Oblúk</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Polomer:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Stred (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Stred (x):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Začiatočný uhol:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Koncový uhol:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Otočiť</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Atribúty</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>Kružnica</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Polomer:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Stred (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Stred (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>Lineárna kóta</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Zarovnaná kóta podľa objektu</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>Elipsa</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Stred (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Stred (x):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Koncový uhol:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Začiatočný uhol:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>Otočenie:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>Vedľajšia:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>Hlavná:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Otočiť</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>Voľba štýlu šráfov</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>Vzor</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Mierka:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>Výplň</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhľad</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>Zapni náhľad</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>Vitajte</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Vitajte v programe QCad&lt;/b&gt;(new line)
&lt;/font&gt;
&lt;br&gt;
Prosím zvoľte jednotky, ktoré chcete používať pri kreslení a preferovaný jazyk.&lt;br&gt;
Tieto nastavenia môžete neskôr zmeniť v dialógovom okne Nastavenia.</translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>Preferovaná jednotka:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>GUI jazyk:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>Jazyk pre príkazy:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Zvoľ</translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>Vložiť</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>Bod vloženia (x):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>Bod vloženia (y):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Mierka:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Riadky:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Stĺpce:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>Vzdialenosť riadkov:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>Vzdialenosť stĺpcov:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>Čiara</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>Koncový bod (x):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>Koncový bod (y):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>Začiatočný bod (y):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>Začiatočný bod (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>Nastavenie zrkadlenaia</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>Nastavenie posunu</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Viacnásobné kópie</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>Nastavenie Posunutia/Otočenia</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Uhol (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Viacnásobné kópie</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Main Unit</source>
        <translation>Hlavné jednotky</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Dĺžka</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Desatinný</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>Exponenciálny</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>Inžinierský</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>Stavebný</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>Zlomokový</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Uhol</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>Desatinné stupne</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>Radiány</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhľad</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>lineárne</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>uhlové</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>Formát papiera</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>Výška textu:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>jednotky</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>Stupne/Minúty/Sekundy</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation>Gradiány</translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation>Zememeračské</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>Pre formáty &quot;Inžinierský&quot; a &quot;Stavebný&quot; musí byť formát jednotiek nastavený na palce.</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>Presahovanie vynášacej čiary:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>Veľkosť šípky:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>Odstup vynášacej čiary:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>Medzera medzi vynášacou čiarou:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>Nastavenie kreslenia</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>&amp;Papier</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>Na ší&amp;rku</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>Na výšk&amp;u</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>&amp;Výška papiera:</translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>Ší&amp;rka papiera:</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>&amp;Jednotky</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>&amp;Hlavná kresliaca jednotka:</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>&amp;Formát:</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>Pre&amp;snosť:</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>F&amp;ormát:</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>Pres&amp;nosť:</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>&amp;Kóty</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Mriežka</translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>Nastavenie mriežky</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>Zobraz mriežku</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>X-ový rozostup:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Y-ový rozostup:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>automaticky</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Mriežka</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished">8</translation>
    </message>
    <message>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <source>32</source>
        <translation type="unfinished">32</translation>
    </message>
    <message>
        <source>64</source>
        <translation type="unfinished">64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation type="unfinished">0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation type="unfinished">0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished">10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Preklady:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>Šráfovacie vzory:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>Písma:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>Skripty:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>Knižnice:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>Grafické zobrazenie</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <source>Please restart QCad to apply all changes.</source>
        <translation type="obsolete">Prosím reštartujte QCad pre aplikáciu všetkých zmien.</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>Nastavenia aplikácie</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>Predvolené pre nové výkresy</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>&amp;Vzhľad</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>&amp;Jazyk GUI:</translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>&amp;Jazyk pre príkazy:</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>&amp;Zobrazuj veľké náhľady</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>Počet ná&amp;hľadov objektov:</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>&amp;Cesty</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>&amp;Predvolené</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>&amp;Jednotka:</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Farby</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>Po&amp;zadie:</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>Body &amp;mriežky:</translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>Či&amp;ary mriežky:</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation>#404040</translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>Veľkosť písma</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>Stavový riadok:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation>#000000</translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation>#ffffff</translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation>#c0c0c0</translation>
    </message>
    <message>
        <source>#808080</source>
        <translation>#808080</translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>A&amp;utomatická mierka mriežky</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>Z&amp;volená farba:</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation>#a54747</translation>
    </message>
    <message>
        <source>#739373</source>
        <translation>#739373</translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>&amp;Zvýraznená farba:</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing:</source>
        <translation type="obsolete">Minimálny rozostup mriežky:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>Prosím reštartujte aplikáciu pre prejavenie všetkých zmien.</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>Bod</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Rozmery</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>Pozícia (y):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>Pozícia (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>Nastavenie rotácie</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>&amp;Viacnásobné kópie:</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Uhol (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>Nastavenie rotácie č.2</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Viacnásobné kópie</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>Uhol (&amp;a):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>&amp;Uhol (&amp;b):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>Nastavenie mierky</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet kópií</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>&amp;Faktor (f):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použi aktuálne &amp;atribúty</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použi aktuálnu &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymaž orginál</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechaj orginál</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Viacnásobné kópie</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation type="unfinished">Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="unfinished">Rozmery</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished">Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>Vymaž text</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>Nahraj text zo súboru</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>Ulož text do súboru</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Vystrihnúť</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovať</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Vložiť</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Písmo</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Zarovnanie</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>Vpravo hore</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>Vľavo hore</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>Vľavo v strede</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>V polovici v strede</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>Vpravo v strede</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>Vľavo dole</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>Vpravo dole</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>V strede dole</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>V strede hore</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Uhol</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>Vlož symbol</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation>Priemer (ø)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>Stupne (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation>Plus / Mínus (±)</translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation>Zavináč (@)</translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>Mriežka (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dolár ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation>Copyright (©)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (®)</source>
        <translation>Registered (®)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>Paragraf (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation>Pí (¶)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation>Libra (£)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>Krát (×)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation>Delenie (÷)</translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>Vlož unicode</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>Kódovanie:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>Znak:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation>[0000-007F] Základná Latin</translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation>[0080-00FF] Latin-1 Doplnková</translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation>[0100-017F] Latin Rozšírenie-A</translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation>[0180-024F] Latin Rozšírenie-B</translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation>[0250-02AF] IPA Rozšírenie</translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation>[0250-02AF] Znaky nahrádzajúce medzery</translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation>[0300-036F] Kombinované diakritické znaky</translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation>[0370-03FF] Gréčtina a Kopčina</translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation>[0400-04FF] Cyrilika</translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation>[0500-052F] Cyrilika Dodatok</translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation>[0530-058F] Arménčina</translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation>[0590-05FF] Hebrejčina</translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation>[0600-06FF] Arabčina</translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation>[0700-074F] Sírčina</translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation>[0780-07BF] Thaana</translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation>[0900-097F] Devanagari</translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation>[0980-09FF] Bengálčina</translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation>[0A00-0A7F] Gurménčina</translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation>[0A80-0AFF] Gujarati</translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation>[0B00-0B7F] Oriya</translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation>[0B80-0BFF] Tamilčina</translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation>[0C00-0C7F] Telugu</translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation>[0C80-0CFF] Kannada</translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation>[0D00-0D7F] Malayalam</translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation>[0D80-0DFF] Sinhala</translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation>[0E00-0E7F] Thaičina</translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation>[0E80-0EFF] Lao</translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation>[0F00-0FFF] Tibetčina</translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation>[1000-109F] Myanmar</translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation>[10A0-10FF] Georgian</translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation>[1100-11FF] Hangul Jamo</translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation>[1200-137F] Etiópčina</translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation>[13A0-13FF] Cherokee</translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation>[1400-167F] Unified Canadian Aboriginal Syllabic</translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation>[1680-169F] Oghamčina</translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation>[16A0-16FF] Runic</translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation>[1700-171F] Tagalog</translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation>[1720-173F] Hanunoo</translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation>[1740-175F] Buhid</translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation>[1760-177F] Tagbanwa</translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation>[1780-17FF] Khmer</translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation>[1800-18AF] Mongolčina</translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation>[1E00-1EFF] Latin ďalšia doplnková</translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation>[1F00-1FFF] Rozšírená gréčtina</translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation>[2000-206F] Základná interpunkcia</translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation>[2070-209F] Superskripty a Subskripty</translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation>[20A0-20CF] Symboly mien</translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation>[20D0-20FF] Kombinované znaky pre symboly</translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation>[2100-214F] Symboly písmen</translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation>[2150-218F] Tvary čísel</translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation>[2190-21FF] Šípky</translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation>[2200-22FF] Matematické operátory</translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation>[2300-23FF] Rôzne technické</translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation>[2400-243F] Kontrolné obrazce</translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation>[2440-245F] Optické rozoznávanie znakov</translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation>[2460-24FF] Uzavreté alfanumerické</translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation>[2500-257F] Obdĺžniková kresba</translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation>[2580-259F] Blokové elementy</translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation>[25A0-25FF] Geometrické tvary</translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation>[2600-26FF] Rôzne symboly</translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation>[2700-27BF] Dingbats</translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation>[27C0-27EF] Rôzne matematické znaky-A</translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation>[27F0-27FF] Podporované šípky-A</translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation>[2800-28FF] Braillové vzory</translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation>[2900-297F] Podporované šípky-B</translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation>[2980-29FF] Rôzne matematické znaky-B</translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation>[2A00-2AFF] Podporované matematické operátory</translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation>[2E80-2EFF] CJK Radicals Supplement</translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation>[2F00-2FDF] Kangxi Radicals</translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation>[2FF0-2FFF] Popisy ideografickéch znakov</translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation>[3000-303F] CJK symboly a interpunkcia</translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation>[3040-309F] Hiragana</translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation>[30A0-30FF] Katakana</translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation>[3100-312F] Bopomofo</translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation>[3130-318F] Hangul Compatibility Jamo</translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation>[3190-319F] Kanbun</translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation>[31A0-31BF] Bopomofo Extended</translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation>[3200-32FF] Enclosed CJK Letters and Months</translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation>[3300-33FF] CJK kompatibilné</translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation>[3400-4DBF] CJK unifikované ideografické rozšírenie A</translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation>[4E00-9FAF] CJK unifikované ideografy</translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation>[A000-A48F] Yi slabiky</translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation>[A490-A4CF] Yi základné</translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation>[AC00-D7AF] Hangul Syllables</translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation>[D800-DBFF] High Surrogates</translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation>[DC00-DFFF] Low Surrogate Area</translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation>[E000-F8FF] Používateľská oblasť</translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation>[F900-FAFF] CJK kompatibilé ideografy</translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation>[FB00-FB4F] Abecedný podací formulár</translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation>[FB50-FDFF] Arabský podací formulár A</translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation>[FE00-FE0F] Prepínače volieb</translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation>[FE20-FE2F] Kombinované polovičné znaky</translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation>[FE30-FE4F] CJK podací formulár</translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation>[FE50-FE6F] Small Form Variants</translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation>[FE70-FEFF] Arabský podací formulár A</translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation>[FF00-FFEF] Halfwidth and Fullwidth Forms</translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation>[FFF0-FFFF] Špeciálne</translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation>[10300-1032F] Staré kurzíva</translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation>[10330-1034F] Gotické</translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation>[10400-1044F] Deseret</translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation>[1D000-1D0FF] Byzanské hudobné symboly</translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation>[1D100-1D1FF] Hudobné symboly</translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation>[1D400-1D7FF] Matematické alfanumerické znaky</translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation>[20000-2A6DF] CJK unifikované ideografické rozšírenie B</translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation>[2F800-2FA1F] Dodatok k CJK kompatibilným ideografom</translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation>[E0000-E007F] Značky</translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation>[F0000-FFFFD] Dodatočná užívateľská oblasť A</translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation>[100000-10FFFD] Dodatočná užívateľská oblasť B</translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>&amp;Výška:</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>Oddel&amp;enie čiar:</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>&amp;Predvolené oddelenie čiar</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="obsolete">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Uložiť</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>Uložiť &amp;ako..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušiť</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>Nedodaný žiadny text.</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation>QCad</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="obsolete">Esc</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <source>Alt+L</source>
        <translation type="obsolete">Alt+L</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Nastavenie vloženia</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Uhol rotácie</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Faktor mierky</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>Nastavenie exportu obrázku</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>Veľkosť bitovej mapy</translation>
    </message>
    <message>
        <source>640</source>
        <translation>640</translation>
    </message>
    <message>
        <source>480</source>
        <translation>480</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Šírka:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Výška:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Pozadie</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Biela</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Čierna</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Rozlíšenie:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>25</source>
        <translation>25</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>75</source>
        <translation>75</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Nastavenie vloženia</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Uhol rotácie</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Faktor mierky</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>Pole:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>Počet stĺpcov</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>Počet riadkov</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>Vzdialenosť:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>Vzdialenosť stĺpcov</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>Vzdialenosť riadkov</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>-Bez zmeny-</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>Nastavenie hladín</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>Meno hladiny:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>Predvolené pero</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Show all layers</source>
        <translation>Zobraz všetky hladiny</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>Skry všetky hladiny</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>Pridaj hladinu</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>Vymaž aktuálnu hladinu</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>Uprav atribúty hladiny / premenuj</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>Menu hladín</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>&amp;Odomkni všetky hladiny</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>&amp;Zamkni všetky hladiny</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>&amp;Pridaj hladinu</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>&amp;Vymaž hladinu</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>&amp;Uprav hladinu</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>P&amp;repni viditeľnosť</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>Nastavenie vkladania knižníc</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Uhol rotácie</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Faktor mierky</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>Prezerač knižníc</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Adresáre</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Vlož</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>Nastavenie šikmej čiary</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Šikmá čiara</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Dĺžka:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Dĺžka čiary</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>Bod prichitenia:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Začiatočný</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Stredný</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Koncový</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>Nastavenie osových čiar</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Dĺžka:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>Dĺžka osi</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>Počet vytvorených osí</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>Nastavenie čiar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Späť</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>Nastavenie rovnobežiek</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Vzdialenosť:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>Vzdialenosť od pôvodného objektu</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Počet vytvorených rovnobežiek</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>Nastavenie rovnobežiek cez bod</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Počet vytvorených rovnobežiek</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>Nastavenie mnohouholníku</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Počet hrán</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>Nastavenie mnohouholníku</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Počet hrán</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>Nastavenie čiar pod relatívnym uhlom</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Šikmá čiara</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Dĺžka:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Dĺžka čiary</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>Podľa hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Podľa bloku</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>Žiadna</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>Plná</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>Bodkovaná</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>Bodkovaná (malá)</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>Bodkovaná (veľká)</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>Čiarkovaná</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>Čiarkovaná (malá)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>Čiarkovaná (veľká)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>Bodkočiarkovaná</translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>Bodkočiarkovaná (malá)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>Bodkočiarkovaná (veľká)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Deliaca</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>Deliaca (malá)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>Deliaca (veľká)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Stredová</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>Stredová (malá)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>Stredová (veľká)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Okrajová</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>Okrajová (malá)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>Okrajová (veľká)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Bez zmeny-</translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>Myš</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Pravé</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Ľavé</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>Nastavenia rotácie/posunu</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
</context>
<context>
    <name>QG_PolylineOptions</name>
    <message>
        <source>Polyline Options</source>
        <translation type="obsolete">Nastavenie lomených čiar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Zatvoriť</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Nastavenie lomených čiar</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation type="obsolete">Oblúk</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="obsolete">Polomer:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation>Nastavenie náhľadu pred tlačou</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>Nastavenie zaoblenia</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Orezanie</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>Pokús sa orezať obidva objekty</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Polomer:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>Označenie</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>Označené objekty:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>Nastavenie vzdialenosti prichitávania</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Vzdialenosť:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>Nastavenie textu</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Uhol:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>Nastavenie orezania o hodnotu</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>Vzdialenosť. Záporné hodnoty pre orezanie, kladné hodnoty pre predĺženie.</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Hodnota:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>Pero</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>Typ čiary:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Hrúbka:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Farba:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>Podľa hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Podľa bloku</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predvolená</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation>0.00mm</translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation>0.05mm</translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation>0.09mm</translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation>0.13mm (ISO)</translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation>0.15mm</translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation>0.18mm (ISO)</translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation>0.20mm</translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation>0.25mm (ISO)</translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation>0.30mm</translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation>0.35mm (ISO)</translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation>0.40mm</translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation>0.50mm (ISO)</translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation>0.53mm</translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation>0.60mm</translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation>0.70mm (ISO)</translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation>0.80mm</translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation>0.90mm</translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation>1.00mm (ISO)</translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation>1.06mm</translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation>1.20mm</translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation>1.40mm (ISO)</translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation>1.58mm</translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation>2.00mm (ISO)</translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation>2.11mm</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Bez zmeny-</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Varovanie</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>Vymazanie hladiny</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>Hladina &quot;%1&quot; a všetky objekty na nej budú vymazané.</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>Hladina &quot;%1&quot; nemôže byť nikdy vymazaná.</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>Dialóg hladín</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>Vymazanie bloku</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>Blok &quot;%1&quot; a všetky jeho objekty budú vymazané.</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>Nastavenie hladín</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>Hladina menom &quot;%1&quot; už existuje. Prosím zvoľte iné meno.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Uloženie výkresu ako</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>Súbor &quot;%1&quot; už existuje.
Chcete ho nahradiť?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Áno</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>Otvorenie výkresu</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Otvorenie obrázku</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation>Bitová mapa Windows</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation>Multiple-image Network Graphics</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation>Portable Grey Map</translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation>Portable Network Graphic</translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation>Portable Pixel Map</translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation>X Bitmap Format</translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation>X Pixel Map</translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>Všetky typy obrázkov (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation>Drawing Exchange %1</translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation>QCad 1.x súbor %1</translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>Písmo (%1)</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Všetky súbory (*.*)</translation>
    </message>
</context>
</TS>
