<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Nuevo</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="obsolete">&amp;Abrir...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="obsolete">&amp;Guardar</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="obsolete">Gua&amp;rdar como...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Imprimir</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Salir</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">S&amp;alir</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="obsolete">A&amp;cercar</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="obsolete">Al&amp;ejar</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>Auto Zoom</source>
        <translation type="obsolete">Extensión</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="obsolete">&amp;Extensión</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="obsolete">Automático</translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation type="obsolete">Ventana del visor</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="obsolete">&amp;Ventana del visor</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="obsolete">Ventana de acercamiento</translation>
    </message>
    <message>
        <source>Pan Zoom</source>
        <translation type="obsolete">Mover el visor</translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="obsolete">&amp;Mover el visor</translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="obsolete">Visor en tiempo real</translation>
    </message>
    <message>
        <source>Redraw</source>
        <translation type="obsolete">Redubujar</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="obsolete">&amp;Redibujar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Deshacer</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">&amp;Deshacer</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="obsolete">Deshace última orden</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Rehacer</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Rehacer</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="obsolete">Rehace última orden</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Cortar</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">C&amp;ortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">C&amp;opiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Pegar</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">&amp;Pegar</translation>
    </message>
    <message>
        <source>Select Entity</source>
        <translation type="obsolete">Seleccionar entidad</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="obsolete">Selecciona entidades solas</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation type="obsolete">Ventana de selección</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="obsolete">Ventana de &amp;selección</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="obsolete">Selecciona entidades de la ventana</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="obsolete">Ventana de deselección</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="obsolete">Ventana de &amp;deselección</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="obsolete">Deselecciona entidades de la ventana</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">Contorno de (De)selección</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">(De)selecciona entidades conectadas</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="obsolete">Seleccionar todo</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="obsolete">Seleccionar &amp;todo</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="obsolete">Seleccionar todas las entidades</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Deseleccionar todo</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="obsolete">Deseleccionar &amp;todo</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="obsolete">Deselecciona todas las entidades</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="obsolete">Invertir selección</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="obsolete">&amp;Invertir selección</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="obsolete">Invierte selección actual</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="obsolete">Seleccionar entidades atravesadas</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="obsolete">Entidades c&amp;ruzadas</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="obsolete">Selecciona entidades cruzadas por una línea </translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="obsolete">Deseleccionar entidades cruzadas</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="obsolete">Deseleccionar en&amp;tidades cruzadas</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="obsolete">Deselecciona entidades cruzadas por una línea</translation>
    </message>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="obsolete">(De)seleccionar capa</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="obsolete">(De)selecciona capas</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Puntos</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="obsolete">&amp;Puntos</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="obsolete">Dibujar puntos</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation type="obsolete">Línea: 2 puntos</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="obsolete">&amp;2 puntos</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="obsolete">Dibujar líneas</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Línea: ángulo</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Ángulo</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Dibujar líneas con un ángulo dado</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Línea: horizontal</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Horizontal</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Dibujar líneas horizontales</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="obsolete">Línea hor./vert.</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="obsolete">H&amp;orizontal / Vertical</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="obsolete">Dibujar líneas horiz./verticales</translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Línea: vertical</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Vertical</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Dibujar líneas verticales</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation type="obsolete">Línea a mano alzada</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="obsolete">Línea a &amp;mano alzada</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="obsolete">Dibujar líneas a mano alzada</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Paralelas</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="obsolete">Para&amp;lelas</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rectángulo</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="obsolete">&amp;Rectángulo</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="obsolete">Dibujar rectángulos</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation type="obsolete">Bisector</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="obsolete">&amp;Bisector</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="obsolete">Dibujar bisectores</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="obsolete">Tangente (P,C)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="obsolete">&amp;Tangente (P,C)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="obsolete">Dibujar tangente (punto, círculo)</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="obsolete">Tangente (C,C)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="obsolete">Tan&amp;gente (C,C)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="obsolete">Dibujar tangente (círculo, círculo)</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Ortogonal</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">&amp;Ortogonal</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Dibujar línea ortogonal</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation type="obsolete">Ángulo relativo</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="obsolete">Á&amp;ngulo relativo</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="obsolete">Dibujar línea con ángulo relativo</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="obsolete">Polígono</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="obsolete">Polí&amp;gono (Cen,Ver)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="obsolete">Dibujar polígono con centro y vértice</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cor,Cor)</source>
        <translation type="obsolete">Polígo&amp;no (Ver,Ver)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="obsolete">Dibujar polígono con 2 vértices</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="obsolete">Círculo: centro, punto</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="obsolete">centro, &amp;punto</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="obsolete">Dibujar círculos con centro y punto</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="obsolete">Círculo: centro, radio</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="obsolete">centro, &amp;radio</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="obsolete">Dibujar círculos con centro y radio</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="obsolete">Círculo: 2 puntos</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="obsolete">2 puntos</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="obsolete">Dibujar círculos con 2 puntos</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Círculo: 3 puntos</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 puntos</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Dibujar círculos con 3 puntos</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="obsolete">Arco: centro, punto, ángulos</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="obsolete">&amp;centro, punto, ángulos</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="obsolete">Dibujar arcos</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="obsolete">Arco: 3 puntos</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="obsolete">&amp;3 puntos</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="obsolete">Dibujar arcos con 3 puntos</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="obsolete">Elipse con ejes</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="obsolete">&amp;Elipse (ejes)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="obsolete">Dibujar elipses</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="obsolete">&amp;Tramo de elipse con ejes</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="obsolete">&amp;Tramo de elipse (ejes)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="obsolete">Dibujar tramos de elipse </translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texto</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="obsolete">&amp;Texto</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="obsolete">Dibujar entidades de texto</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="obsolete">Dibujar sombreados y rellenos</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation type="obsolete">Alineado</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="obsolete">&amp;Alineado</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Cota alineada</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="obsolete">Lineal</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="obsolete">&amp;Lineal</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="obsolete">Cota lineal</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="obsolete">Horizontal</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="obsolete">Cota horizontal</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="obsolete">Vertical</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="obsolete">Cota vertical</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation type="obsolete">Radial</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="obsolete">&amp;Radial</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="obsolete">Cota radial</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation type="obsolete">Diámetro</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="obsolete">&amp;Diámetro</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="obsolete">Cota del diámetro</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation type="obsolete">Ángulo</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="obsolete">&amp;Ángulo</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="obsolete">Cota Angular</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation type="obsolete">Directriz</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="obsolete">&amp;Directriz</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="obsolete">Cota con directriz</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Borrar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;Borrar</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="obsolete">Borrar entidades</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation type="obsolete">Borrar mano alzada</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="obsolete">&amp;Borrar mano alzada</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Desplazar</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Desplazar</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Desplazar entidades</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation type="obsolete">Girar</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="obsolete">&amp;Girar</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="obsolete">Girar entidades</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="obsolete">Escalar</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="obsolete">&amp;Escalar</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="obsolete">Escalar entidades</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Simetría</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">&amp;Simetría</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Entidades simétricas</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation type="obsolete">Girar y desplazar</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="obsolete">G&amp;irar y desplazar</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="obsolete">Girar y desplazar entidades</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation type="obsolete">Girar 2 centros de giro</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="obsolete">Girar 2 &amp;centros de giro</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="obsolete">Girar entidades alrededor de 2 centros </translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Recortar</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">&amp;Recortar</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Recortar entidades
</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Recortar 2 entidades</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">&amp;Recortar 2 entidades</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Recortar 2 entidades</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Alargar</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">&amp;Alargar</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Alargar una cuantía</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">&amp;Cortar</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Cortar entidades</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation type="obsolete">Estirar</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="obsolete">&amp;Estirar</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="obsolete">Estirar entidades</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation type="obsolete">Chaflán</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="obsolete">&amp;Chaflán</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="obsolete">Achaflanar entidades</translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="obsolete">Redondear</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="obsolete">&amp;Redondear</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="obsolete">Redondear entidades</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>No Forzar</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>&amp;No Forzar</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Posición libre</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Rejilla</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Rejilla</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>Forzado a rejilla</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>Extremos</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>&amp;Extremos</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>Forzar a extremos</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>En entidad</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>&amp;En entidad</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>Forzar al punto más cercano</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>&amp;Centro</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>Forzar a centro</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Punto medio</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>&amp;Punto medio</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Forzar a punto medio</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>Distancia desde el extremo</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>&amp;Distancia desde el extremo</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>Forzar a una distancia desde el extremo</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>Intersección</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>&amp;Intersección</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>Forzar a punto de intersección</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation type="obsolete">Intersección ficticia</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="obsolete">&amp;Intersección ficticia</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="obsolete">Forzar a punto intersección ficticia </translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>Sin restricciones</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>Sin &amp;restricciones</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>No restringir a rejilla</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>Restringir ortogonalmente</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>Restringir &amp;ortogonalmente</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>Restringir ortogonalmente y en rejilla</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>Restringir verticalmente</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>Restringir &amp;horizontalmente</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>Restringir horizontalmente y en rejilla</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>Restringir verticalmente</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>Restringir &amp;verticalmente</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>Restringir verticalmente y en rejilla</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation type="obsolete">Definir Cero relativo</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="obsolete">&amp;Definir el Cero relativo</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="obsolete">Definir la posición del Cero relativo</translation>
    </message>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="obsolete">(Des)bloquear el Cero relativo</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="obsolete">(Des)bloquear el &amp;Cero relativo</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="obsolete">(Des)bloquear el Cero relativo</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation type="obsolete">Punto interior al contorno</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="obsolete">&amp;Punto interior al contorno</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="obsolete">Comprueba si el punto está dentro del contorno</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Desocultar todo</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">&amp;Desocultar todo</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Desocultar todas las capas</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Ocultar todo</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">&amp;Ocultar todo</translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation type="obsolete">Ocultar todas las capas</translation>
    </message>
    <message>
        <source>Add Layer</source>
        <translation type="obsolete">Añadir capa</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="obsolete">&amp;Añadir capa</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation type="obsolete">Eliminar capa</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="obsolete">&amp;Eliminar capa</translation>
    </message>
    <message>
        <source>Edit Layer</source>
        <translation type="obsolete">Editar capa</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="obsolete">&amp;Editar capa</translation>
    </message>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="obsolete">Bloquear capa</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="obsolete">&amp;Bloquear capa</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="obsolete">Bloquear capa</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Desocultar los bloques</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Ocultar bloques</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Añadir bloque</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">&amp;Añadir bloque</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Eliminar bloque</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">&amp;Eliminar bloque</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Renombrar bloque</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">&amp;Renombrar bloque</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Renombrar bloque y sus inserciones</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Editar bloque</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">&amp;Editar bloque</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Insertar bloque</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">&amp;Insertar bloque</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Bloquear bloque</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">&amp;Bloquear bloque</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Bloquear bloque</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation type="obsolete">Crear bloque</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">&amp;Crear bloque</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Descomponer</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">&amp;Descomponer</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Descomponer bloques y otros grupos</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>Preferencias Generales de la Aplicación</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="obsolete">Dibujo</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="obsolete">Crea un nuevo dibujo</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="obsolete">Abre un dibujo existente</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="obsolete">Guarda el dibujo actual</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="obsolete">Guarda el dibujo actual con un nombre nuevo</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>Cierra el dibujo actual</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>Imprime el dibujo actual</translation>
    </message>
    <message>
        <source>New Drawing</source>
        <translation type="obsolete">Dibujo nuevo</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation type="obsolete">Abrir Dibujo</translation>
    </message>
    <message>
        <source>Save Drawing</source>
        <translation type="obsolete">Guardar Dibujo</translation>
    </message>
    <message>
        <source>Save Drawing As</source>
        <translation type="obsolete">Guardar Dibujo como...</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>Cerrar Dibujo</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>Imprimir Dibujo</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="obsolete">Elimina entidades del portapapeles</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="obsolete">Copia entidades al portapapeles</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="obsolete">Pega el contenido del portapapeles</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="obsolete">(De)&amp;seleccionar entidad</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">(De)&amp;seleccionar contorno</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="obsolete">Dibujar líneas, arcos ó círculos paralelos a otros</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation type="obsolete">Paralela por un punto</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="obsolete">Par&amp;alela por un punto</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="obsolete">Dibuja una paralela por un punto dado</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="obsolete">Atributos</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="obsolete">&amp;Atributos</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="obsolete">Modifica atributos de entidades</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="obsolete">Elimina seleccionado</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="obsolete">&amp;Elimina seleccionado</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="obsolete">Elimina entidades seleccionadas</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">Previsualizar impresión</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="obsolete">Previsualizar Im&amp;presión</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="obsolete">Previsualiza una impresión</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation type="obsolete">Distancia de punto a punto</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="obsolete">&amp;Distancia de punto a punto</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="obsolete">Mide la distancia entre dos puntos</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="obsolete">Distancia de entidad a punto</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="obsolete">&amp;Distancia de entidad a punto</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="obsolete">Mide la distancia entre una entidad y un punto</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation type="obsolete">Ángulo entre dos líneas</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="obsolete">&amp;Ángulo entre dos líneas</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="obsolete">Mide el ángulo entre dos líneas</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>Exportar Dibujo</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Exportar...</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>Exportar el dibujo actual como bitmap</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Propiedades</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="obsolete">Modificar las propiedades de la entidad</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="obsolete">&amp;Propiedades</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>&amp;Preferencias de la Aplicación</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="obsolete">Preferencias del Dibujo actual</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="obsolete">Parámetros del Dibujo actual</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>Activa/Desactiva la rejilla</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Círculo: Concéntrico</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Concéntrico</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Dibujar círculos concéntricos con el existente</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Arco: Concéntrico</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Dibujar arcos concéntricos con el existente </translation>
    </message>
    <message>
        <source>Hatch</source>
        <translation type="obsolete">Sombreado</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="obsolete">&amp;Sombreado</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="obsolete">Imagen</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="obsolete">&amp;Imagen</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="obsolete">Insertar imagen (Bitmap)</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Barra de estado</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>&amp;Barra de estado</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>Activa/Desactiva la barra de estado</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation type="obsolete">Longitud total de las entidades seleccionadas</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="obsolete">&amp;Longitud total entidades seleccionadas</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="obsolete">Mide la longitud total de las entidades seleccionadas</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Imprimir...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Borrador</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>&amp;Borrador</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>Habilita/deshabilita el modo borrador</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>&amp;Preferencias</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>Abrir IDE</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>&amp;Abrir IDE</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>Abre el entorno de desarrollo integrado para programación</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>Ejecutar Guión..</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>&amp;Ejecutar Guión..</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>Ejecuta un guión</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>Opciones de Arco</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>Dirección del reloj</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>Contador Dirección Reloj</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="unfinished">Radio:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>Opciones de Chaflán</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>Pulsar para recortar ambas entidades del chaflán</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>Medida 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>Medida 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>Atributos del Bloque</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>Nombre del Bloque:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>Renombrando Bloque</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>No se pudo nombrar el bloque. El bloque &quot;%1&quot; ya existe.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Add a block</source>
        <translation>Añadir un bloque</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>Eliminar el bloque activo</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>Renombrar el bloque activo</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>Editar bloque activo
en otra ventana</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>Insertar el bloque  activo</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>Menú del Bloque</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>&amp;Desocultar todos los Bloques</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>&amp;Ocultar todos los Bloques</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>&amp;Añadir Bloque</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>&amp;Eliminar Bloque</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>&amp;Editar Bloque</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Bloquear visibilidad</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>Mostrar los bloques</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>Ocultar los bloques</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>&amp;Renombrar Bloque</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>&amp;Insertar Bloque</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>&amp;Crear Bloque Nuevo</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>Herramientas CAD</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>Arcos</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>Arcos con tres puntos</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>Arco con centro, punto, ángulos</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Concéntrico</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation>Círculos</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>Círculo con dos puntos opuestos</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>Círculo con centro y radio</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>Círculo con centro y punto</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>Círculo con tres puntos</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Concéntrico</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>Cotas</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Cota diámetro</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Cota radio</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Cota vertical</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Cota horizontal</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Cota lineal</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Cota alineada</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Cota angular</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Directriz</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>Elipses</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>Elipse con arco con centro, dos puntos y ángulos</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>Elipse con centro y dos puntos</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>Distancia (punto a punto)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>Distancia (entidad, punto)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Ángulo</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Longitud total de las entidades seleccionadas</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>Líneas</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>Líneas a mano alzada</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>Líneas ortogonales</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>Bisectores</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>Tangentes a dos círculos</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>Tangentes a círculo desde punto</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>Línea con dos puntos</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>Líneas con ángulo relativo</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>Línea con ángulo dado</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>Líneas horizontales</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>Líneas verticales</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>Rectángulos</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>Polígonos con centro y vértice</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>Polígonos con dos vértices</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>Paralelas a una distancia</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>Paralela por un punto</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>Mostrar menú &quot;Líneas&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>Mostrar menú &quot;Arcos&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>Mostrar menú &quot;Círculos&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Points&quot;</source>
        <translation type="obsolete">Mostrar menú &quot;Puntos&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>Mostrar menú &quot;Magnitudes&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>Mostrar menú &quot;Elipses&quot;</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>Sombreado/Relleno</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>Mostrar menú &quot;Edición&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>Mostrar menú &quot;Acotar&quot;</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>Textos</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>Mostrar menú &quot;Selección&quot;</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Crear Bloque</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>Abrir imagen bitmap</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="unfinished">Puntos</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>Modificar</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Escalar</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Desplazar</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Desplazar y Girar</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation>Descomponer</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Estirar</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Redondear</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Achaflanar</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>Recortar una cuantía</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>Recortar/Alargar dos</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>Recortar/Alargar</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>Girar alrededor de dos centros</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>Editar atributos entidad</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>Editar geometría entidad</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Simetría</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Partir</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>Desagrega Texto en Letras</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Editar Texto</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>Puntos</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver a menú principal</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>Puntos solos</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append node</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>Seleccionar entidades que se atraviesen</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>Deseleccionar entidades que se atraviesen</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Deseleccionar todo</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>Invertir selección</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>Seleccionar capa</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>(De)seleccionar contorno</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>(De)seleccionar entidad</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Deseleccionar por ventana</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Seleccionar por ventana</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>Continuar</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>Forzar cursor</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Volver al menú principal</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>Forzar a rejilla</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Posición libre</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>Forzar a extremos</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>Forzar a punto más cercano</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>Forzar al centro</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Forzar a punto medio </translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>Forzar a una distancia desde el extremo</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>Forzar a punto de intersección ficticia</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>Sin restricción</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>Restricción ortogonal</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>Restricción horizontal</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>Restricción vertical</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>Desplazar el Cero relativo</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>Bloquear el Cero relativo</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>Forzar a punto de intersección ficticia</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>Opciones de círculo</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radio:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>Por Capa</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Por Bloque</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Amarillo</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Azul Claro</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Violeta</translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>Blanco / Negro</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Gris</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Gris Claro</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>Otros..</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Sin alterar</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>Línea de Comandos</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>Coordenadas</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>Opciones de cota alineada</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>Opciones de acotar</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiqueta: </translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation>ø</translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation>°</translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation>±</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation>¶</translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation>×</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation>÷</translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>Editor de Etiquetas de Cotas</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>Etiqueta de Cota:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiqueta: </translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>Insertar:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation>ø (Diámetro)</translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (Grados)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation>± (Mas / Menos)</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation>¶ (Pi)</translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>× (Multiplicación)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (División)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>Arco</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radio:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Centro (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Centro (x):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Ángulo inicial:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Ángulo final:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Invertido</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radio:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Centro (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Centro (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>Cota lineal</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Cota alineada</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Centro (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Centro (x):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Ángulo final:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Ángulo inicial:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>Giro:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>Menor:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>Mayor:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Inverso</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>Escoger Atributos de Sombreado</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>Patrón</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>Relleno sólido</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Previsualización</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>Activar previsualización</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>Bienvenidos</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Bienvenidos a QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Por favor seleccione idioma y unidad a emplear en sus nuevos dibujos.&lt;br&gt;(new line)
Puede cambiar estos parámetros posteriormente en Edición/Preferencias Aplicación.</translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>Unidad por defecto:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>Lenguaje de los menús:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>Lenguaje de los comandos:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Vale</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Entrar</translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>Punto de inserción (x):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>Punto de inserción (y):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Escala:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Filas:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Columnas:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>Espacio entre filas:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>Espacio entre columnas:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>Punto final (x):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>Punto final (y):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>Punto inicial (y):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>Punto inicial (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>Opciones de Simetría</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Conservar Original</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar &amp;capa actual</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>Opciones de Desplazamiento</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Conservar Original</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Copias &amp;Múltiples</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar &amp;capa actual</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>Opciones Desplazar/Girar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Ángulo (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar &amp;capa actual</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Conservar Original</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Copias &amp;Múltiples</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Main Unit</source>
        <translation>Unidad Principal</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Longitud</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Decimal</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>Científico</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>Ingenieril</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>Arquitectónico</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>Fraccional</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Ángulo</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>Grados Decimales</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>Radianes</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Previsualización</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>lineal</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>angular</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>Formato del papel</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>Altura del Texto:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>unidades</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>Grad/min/seg</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation>Gradianes</translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation>Unidades de medición</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>Para mediciones &quot;Ingenieriles&quot; y &quot;Arquitectónicas&quot;, la unidad debe ser la Pulgada.</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>Extensión línea de referencia:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>Tamaño flecha:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>Desfase línea de referencia:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>Espacio línea de cota:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>Preferencias del Dibujo</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>&amp;Papel</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>&amp;Apaisado</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>&amp;Retrato</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>A&amp;ltura papel: </translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>A&amp;nchura papel:</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>&amp;Unidades</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>&amp;Unidad de dibujo:</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>&amp;Formato:</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>P&amp;recisión:</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>F&amp;ormato:</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>
Pre&amp;cisión:</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>&amp;Cotas</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Rejilla</translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>Configuración de la Rejilla</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>Mostrar Rejilla</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>Espaciado X:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Espaciado Y:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished">8</translation>
    </message>
    <message>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <source>32</source>
        <translation type="unfinished">32</translation>
    </message>
    <message>
        <source>64</source>
        <translation type="unfinished">64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation type="unfinished">0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation type="unfinished">0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished">10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Traducciones:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>Patrones Sombreado:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>Fuentes:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>Guiones:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>Bibliotecas:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Lenguaje</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>Vista Gráfica</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <source>Please restart QCad to apply all changes.</source>
        <translation type="obsolete">Para aplicar los cambios reinicie QCad.</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>Preferencias de la Aplicación</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>Unidad en dibujos nuevos</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>&amp;Apariencia</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>Parte &amp;Gráfica: </translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>Parte &amp;Comandos:</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>&amp;Mostrar cursor grande</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>Número de entidades p&amp;revistas:</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>&amp;Localizaciones</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>&amp;Valores por defecto</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>&amp;Unidades:</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Colores</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>&amp;Fondo:</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>&amp;Color puntos rejilla:</translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>&amp;Color líneas rejilla:</translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="obsolete">Negro</translation>
    </message>
    <message>
        <source>White</source>
        <translation type="obsolete">Blanco</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation type="obsolete">Gris claro</translation>
    </message>
    <message>
        <source>Darkgray</source>
        <translation type="obsolete">Gris oscuro</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation>#404040</translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>Tamaño fuente</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>Barra de estado:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation>#000000</translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation>#ffffff</translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation>#c0c0c0</translation>
    </message>
    <message>
        <source>#808080</source>
        <translation>#808080</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>Color S&amp;eleccionado:</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation>#a54747</translation>
    </message>
    <message>
        <source>#739373</source>
        <translation>#739373</translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>Color &amp;Resaltado:</translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>Escala la rejilla a&amp;utomáticamente</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing:</source>
        <translation type="obsolete">Espaciado mínimo de la Rejilla:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>Por favor, reinicie la aplicación para aplicar todos los cambios.</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>Punto</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometría</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>Posición (y):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>Posición (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>Opciones de Giro</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Conservar &amp;Original</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>Copias &amp;Múltiples:</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Ángulo (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar ca&amp;pa actual</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>Opciones de Girar con dos centros</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Conservar Original</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Copias &amp;Múltiples</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>Ángulo (&amp;a):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>Ángulo (&amp;b):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar ca&amp;pa actual</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>Opciones de Escalado</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de copias</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>&amp;Factor (f):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Usar &amp;atributos actuales</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Usar ca&amp;pa actual</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Eliminar Original</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Conservar Original</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Copias &amp;Múltiples</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation type="unfinished">Capa:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="unfinished">Geometría</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished">Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Texto:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>Limpiar Texto</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>Cargar texto de fichero</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>Guardar texto a fichero</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Alineamiento</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>Arriba derecha</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>Arriba izquierda</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>Medio izquierda</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>Medio centro</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>Medio derecha</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>Abajo izquierda</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>Abajo derecha</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>Abajo centro</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>Arriba centro</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Ángulo</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>Insertar símbolo</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation>Diámetro (ø)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>Grados (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation>Más / Menos (±)</translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation>Arroba (@)</translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>Almohadilla (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dólar ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation>Copyright (©)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (®)</source>
        <translation>Registrado (®)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>Parágrafo (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation>Pi (¶)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation>Libra (£)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>Multiplicar (×)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation>Dividir (÷)</translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>Insertar Unicode</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>Página:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>Char:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation>[0000-007F] Basic Latin</translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation>[0080-00FF] Latin-1 Supplementary</translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation>[0100-017F] Latin Extended-A</translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation>[0180-024F] Latin Extended-B</translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation>[0250-02AF] IPA Extensions</translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation>[02B0-02FF] Spacing Modifier Letters</translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation>[0300-036F] Combining Diacritical Marks</translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation>[0370-03FF] Greek and Coptic</translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation>[0400-04FF] Cyrillic</translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation>[0500-052F] Cyrillic Supplementary</translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation>[0530-058F] Armenian</translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation>[0590-05FF] Hebrew</translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation>[0600-06FF] Arabic</translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation>[0700-074F] Syriac</translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation>[0780-07BF] Thaana</translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation>[0900-097F] Devanagari</translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation>[0980-09FF] Bengali</translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation>[0A00-0A7F] Gurmukhi</translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation>[0A80-0AFF] Gujarati</translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation>[0B00-0B7F] Oriya</translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation>[0B80-0BFF] Tamil</translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation>[0C00-0C7F] Telugu</translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation>[0C80-0CFF] Kannada</translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation>[0D00-0D7F] Malayalam</translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation>[0D80-0DFF] Sinhala</translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation>[0E00-0E7F] Thai</translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation>[0E80-0EFF] Lao</translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation>[0F00-0FFF] Tibetan</translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation>[1000-109F] Myanmar</translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation>[10A0-10FF] Georgian</translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation>[1100-11FF] Hangul Jamo</translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation>[1200-137F] Ethiopic</translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation>[13A0-13FF] Cherokee</translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation>[1400-167F] Unified Canadian Aboriginal Syllabic</translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation>[1680-169F] Ogham</translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation>[16A0-16FF] Runic</translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation>[1700-171F] Tagalog</translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation>[1720-173F] Hanunoo</translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation>[1740-175F] Buhid</translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation>[1760-177F] Tagbanwa</translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation>[1780-17FF] Khmer</translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation>[1800-18AF] Mongolian</translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation>[1E00-1EFF] Latin Extended Additional</translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation>[1F00-1FFF] Greek Extended</translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation>[2000-206F] General Punctuation</translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation>[2070-209F] Superscripts and Subscripts</translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation>[20A0-20CF] Currency Symbols</translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation>[20D0-20FF] Combining Marks for Symbols</translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation>[2100-214F] Letterlike Symbols</translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation>[2150-218F] Number Forms</translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation>[2190-21FF] Arrows</translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation>[2200-22FF] Mathematical Operators</translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation>[2300-23FF] Miscellaneous Technical</translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation>[2400-243F] Control Pictures</translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation>[2440-245F] Optical Character Recognition</translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation>[2460-24FF] Enclosed Alphanumerics</translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation>[2500-257F] Box Drawing</translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation>[2580-259F] Block Elements</translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation>[25A0-25FF] Geometric Shapes</translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation>[2600-26FF] Miscellaneous Symbols</translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation>[2700-27BF] Dingbats</translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation>[27C0-27EF] Miscellaneous Mathematical Symbols-A</translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation>[27F0-27FF] Supplemental Arrows-A</translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation>[2800-28FF] Braille Patterns</translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation>[2900-297F] Supplemental Arrows-B</translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation>[2980-29FF] Miscellaneous Mathematical Symbols-B</translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation>[2A00-2AFF] Supplemental Mathematical Operators</translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation>[2E80-2EFF] CJK Radicals Supplement</translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation>[2F00-2FDF] Kangxi Radicals</translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation>[2FF0-2FFF] Ideographic Description Characters</translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation>[3000-303F] CJK Symbols and Punctuation</translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation>[3040-309F] Hiragana</translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation>[30A0-30FF] Katakana</translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation>[3100-312F] Bopomofo</translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation>[3130-318F] Hangul Compatibility Jamo</translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation>[3190-319F] Kanbun</translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation>[31A0-31BF] Bopomofo Extended</translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation>[3200-32FF] Enclosed CJK Letters and Months</translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation>[3300-33FF] CJK Compatibility</translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation>[3400-4DBF] CJK Unified Ideographs Extension A</translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation>[4E00-9FAF] CJK Unified Ideographs</translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation>[A000-A48F] Yi Syllables</translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation>[A490-A4CF] Yi Radicals</translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation>[AC00-D7AF] Hangul Syllables</translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation>[D800-DBFF] High Surrogates</translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation>[DC00-DFFF] Low Surrogate Area</translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation>[E000-F8FF] Private Use Area</translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation>[F900-FAFF] CJK Compatibility Ideographs</translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation>[FB00-FB4F] Alphabetic Presentation Forms</translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation>[FB50-FDFF] Arabic Presentation Forms-A</translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation>[FE00-FE0F] Variation Selectors</translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation>[FE20-FE2F] Combining Half Marks</translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation>[FE30-FE4F] CJK Compatibility Forms</translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation>[FE50-FE6F] Small Form Variants</translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation>[FE70-FEFF] Arabic Presentation Forms-B</translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation>[FF00-FFEF] Halfwidth and Fullwidth Forms</translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation>[FFF0-FFFF] Specials</translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation>[10300-1032F] Old Italic</translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation>[10330-1034F] Gothic</translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation>[10400-1044F] Deseret</translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation>[1D000-1D0FF] Byzantine Musical Symbols</translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation>[1D100-1D1FF] Musical Symbols</translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation>[1D400-1D7FF] Mathematical Alphanumeric Symbols</translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation>[20000-2A6DF] CJK Unified Ideographs Extension B</translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation>[E0000-E007F] Tags</translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation>[F0000-FFFFD] Supplementary Private Use Area-A</translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation>[100000-10FFFD] Supplementary Private Use Area-B</translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>&amp;Altura:</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>&amp;Espacio entre líneas:</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>&amp;Espacio entre líneas por defecto</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="obsolete">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>Gu&amp;ardar como..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>No se aportó texto.</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation>QCad</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="obsolete">Esc</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Sa&amp;lir</translation>
    </message>
    <message>
        <source>Alt+L</source>
        <translation type="obsolete">Alt+L</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Opciones de Inserción</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Ángulo de giro</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Factor de escala</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>Opciones de Exportación</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>Tamaño del bitmap</translation>
    </message>
    <message>
        <source>640</source>
        <translation>640</translation>
    </message>
    <message>
        <source>480</source>
        <translation>480</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Anchura:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Blanco</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Negro</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Resolución:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>25</source>
        <translation>25</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>75</source>
        <translation>75</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Opciones de Inserción</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Ángulo de giro</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Factor de escala</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>Matriz:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>Número de columnas</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>Número de filas</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>Espaciado:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>Entre columnas</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>Entre filas</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>- Sin alterar -</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>Parámetros de la Capa</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>Nombre de capa:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>Trazador por defecto</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Vale</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Show all layers</source>
        <translation>Mostrar capas</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>Ocultar capas</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>Añadir una capa</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>Eliminar capa actual</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>Modificar atributos / renombrar capa</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>Menú Capas</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>&amp;Desocultar capas</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>&amp;Ocultar capas</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>&amp;Añadir capa</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>E&amp;liminar capa</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>&amp;Editar capa</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Bloquear visibilidad</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>Opciones de Inserción de Biblioteca</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Ángulo de giro</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Factor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Factor de escala</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>Explorador de la Biblioteca</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Directorios</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>Opciones de ángulo de la línea</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Ángulo de la línea</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Longitud:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Longitud de la línea</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>Forzar al punto:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Medio</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Final</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>Opciones Línea Bisector</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Longitud:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>Longitud de los bisectores</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Número:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>Número de bisectores a crear</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>Opciones de Línea</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>Opciones de Línea paralela</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Distancia:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>Distancia a la entidad original</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Número:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Número de paralelas a crear</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>Opciones de Línea paralela por</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Número:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Número de paralelas a crear</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>Opciones de Polígono</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Número:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Número de lados</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>Opciones de Polígono</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Número:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Número de lados</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>Opciones Ángulo relativo de línea</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Ángulo de línea</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Longitud:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Longitud de línea</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>Por Capa</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Por Bloque</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>Sin trazador</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>Contínua</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>Puntos</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>Puntos juntos</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>Puntos separados</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>Raya</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>Raya (pequeña)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>Raya (grande)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>Punto raya</translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>Punto raya (pequeña)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>Punto raya (grande)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Raya 2 puntos</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>Raya 2 puntos (pequeña)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>Raya 2 puntos (grande)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Rayas larga corta</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>Rayas larga corta (pequeño)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>Rayas larga corta (grande)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>2 rayas 1 punto</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>2 rayas 1 punto (pequeño)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>2 rayas 1 punto (grande)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- Sin alterar - </translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>Ratón</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Derecho</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Izquierdo</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>Opciones de Giro Desplazamiento</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
</context>
<context>
    <name>QG_PolylineOptions</name>
    <message>
        <source>Polyline Options</source>
        <translation type="obsolete">Opciones de Polilínea</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Cerrar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Deshacer</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation type="obsolete">Arco</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="obsolete">Radio:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation type="unfinished">Opciones de Previsualización de Impresión</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>Opciones de Redondeo</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>Pulsar para recortar ambas entidades del redondeo</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radio:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>Entidades seleccionadas:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>Opciones Forzar Distancia</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Distancia:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished">Deshacer</translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>Opciones de Texto</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Texto:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>Opciones Recortar cuantía</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>Distancia. Negativa para recortar, positiva para prolongar.</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Cuantía:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>Trazador</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>Tipo de línea:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Color:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>Por Capa</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Por Bloque</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Por Defecto</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation>0.00mm</translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation>0.05mm</translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation>0.09mm</translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation>0.13mm (ISO)</translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation>0.15mm</translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation>0.18mm (ISO)</translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation>0.20mm</translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation>0.25mm (ISO)</translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation>0.30mm</translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation>0.35mm (ISO)</translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation>0.40mm</translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation>0.50mm (ISO)</translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation>0.53mm</translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation>0.60mm</translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation>0.70mm (ISO)</translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation>0.80mm</translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation>0.90mm</translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation>1.00mm (ISO)</translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation>1.06mm</translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation>1.20mm</translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation>1.40mm (ISO)</translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation>1.58mm</translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation>2.00mm (ISO)</translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation>2.11mm</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- Sin alterar -</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>Eliminar Capa</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>La capa &quot;%1&quot; y todas sus entidades será eliminada.</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>La capa &quot;%1&quot; no podrá ser eliminada.</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>Diálogo de la capa</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>Eliminar Bloque</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>El bloque &quot;%1&quot; y todas sus entidades será eliminado.</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>Propiedades de capa</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>Ya existe una capa con nombre &quot;%1&quot;. Por favor especifique otro nombre.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Guardar Dibujo como</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 ya existe;
¿quiere reemplazarlo? </translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>Abrir Dibujo</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Abrir Imagen</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation>Windows Bitmap</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation>Multiple-image Network Graphics</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation>Portable Grey Map</translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation>Portable Network Graphic</translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation>Portable Pixel Map</translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation>X Bitmap Format</translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation>X Pixel Map</translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>Todos los ficheros de imagen (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation>Drawing Exchange %1</translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation>QCad 1.x file %1</translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>Font %1</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Todos los ficheros (*.*)</translation>
    </message>
</context>
</TS>
