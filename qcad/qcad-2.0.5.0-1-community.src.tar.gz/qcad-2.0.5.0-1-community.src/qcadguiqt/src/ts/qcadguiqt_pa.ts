<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>&amp;Close</source>
        <translation>ਬੰਦ ਕਰੋ(&amp;C)</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>ਕਾਰਜ ਨੂੰ ਬੰਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>ਮੁਕਤ</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>ਮੁਕਤ(&amp;F)</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>ਮੁਕਤ ਸਥਿਤੀ</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>ਗਰਿੱਡ</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>ਗਰਿੱਡ(&amp;G)</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>ਗਰਿੱਡ ਟਿਕਾਣਾ</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>ਅੰਤ-ਬਿੰਦੂ</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>ਅੰਤ-ਬਿੰਦੂ(&amp;E)</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>ਅੰਤ-ਬਿੰਦੂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>ਇਕਾਈ &apos;ਤੇ</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>ਇਕਾਈ &apos;ਤੇ(&amp;O)</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>ਇਕਾਈ ਦੇ ਨੇੜਲੇ ਬਿੰਦੂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>ਕੇਂਦਰ</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>ਕੇਂਦਰ(&amp;C)</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>ਕੇਂਦਰਾਂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>ਮੱਧ</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>ਮੱਧ(&amp;M)</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>ਮੱਧ ਬਿੰਦੂਆਂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>ਅੰਤ ਬਿੰਦੂ ਤੋਂ ਦੂਰੀ</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>ਅੰਤ ਬਿੰਦੂ ਤੋਂ ਦੂਰੀ(&amp;D)</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>ਇੱਕ ਅੰਤ-ਬਿੰਦੂ ਤੋਂ ਇੱਕ ਦਿੱਤੀ ਦੂਰੀ ਨਾਲ ਬਿੰਦੂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>ਕਾਟ-ਬਿੰਦੂ</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>ਕਾਟ-ਬਿੰਦੂ(&amp;I)</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>ਕਾਟ ਬਿੰਦੂਆਂ ਲਈ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>ਪਾਬੰਦੀ ਕੁਝ ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>ਪਾਬੰਦੀ ਕੁਝ ਨਹੀਂ(&amp;N)</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>ਕੋਈ ਸਨੈਪ ਪਾਬੰਦੀ ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>ਅਰਥੋਗਨਲੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>ਅਰਥੋਗਨਲੀ ਪਾਬੰਦੀ(&amp;O)</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>ਅਰਥੋਗਨਲੀ ਸਨੈਪਿੰਗ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>ਖਿਤਿਜੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>ਖਿਤਿਜੀ ਪਾਬੰਦੀ(&amp;H)</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>ਖਿਤਿਜੀ ਸਨੈਪਿੰਗ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>ਲੰਬਕਾਰੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>ਲੰਬਕਾਰੀ ਪਾਬੰਦੀ(&amp;V)</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>ਲੰਬਕਾਰੀ ਸਨੈਪਿੰਗ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>ਆਮ ਕਾਰਜ ਪਸੰਦ</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>ਮੌਜੂਦਾ ਡਰਾਇੰਗ ਬੰਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>ਮੌਜੂਦਾ ਡਰਾਇੰਗ ਛਾਪੋ</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>ਡਰਾਇੰਗ ਬੰਦ</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>ਡਰਾਇੰਗ ਛਾਪੋ</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>ਡਰਾਇੰਗ ਨਿਰਯਾਤ</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>ਮੌਜੂਦਾ ਡਰਾਇੰਗ ਨੂੰ ਬਿੱਟਮੈਪ ਦੇ ਤੌਰ ਤੇ ਨਿਰਯਾਤ ਕਰੋ</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>ਕਾਰਜ</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>ਕਾਰਜ ਪਸੰਦ(&amp;A)</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>ਗਰਿੱਡ ਵੇਖਾਓ/ਓਹਲੇ</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>ਸਥਿਤੀ ਪੱਟੀ</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>ਸਥਿਤੀ ਪੱਟੀ(&amp;S)</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>ਸਥਿਤੀ ਪੱਟੀ ਵੇਖਾਓ/ਓਹਲੇ</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>ਡਰਾਫਟ</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>ਡਰਾਫਟ(&amp;D)</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>ਡਰਾਫਟ ਢੰਗ ਯੋਗ/ਆਯੋਗ</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>IDE ਖੋਲੋ</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>IDE ਖੋਲੋ(&amp;O)</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>ਇੰਟੀਗਰੇਟਡ ਡਿਵੈਂਲਪਮਿੰਟ ਇੰਨਵਾਇਰਨਮਿੰਟ ਸਕ੍ਰਿਪਟਿੰਗ ਲਈ ਖੋਲੋ</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>ਸਕ੍ਰਿਪਟ ਖੋਲੋ...</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>ਸਕ੍ਰਿਪਟ ਖੋਲੋ(&amp;R)...</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>ਇੱਕ ਸਕ੍ਰਿਪਟ ਚਲਾਓ</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>ਮੇਰੀ ਪਸੰਦ(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>ਨਿਰਯਾਤ(&amp;E)...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>ਛਾਪੋ(&amp;P)...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>ਬਾਹਰ</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>ਬਾਹਰ(&amp;Q)</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>ਚਾਪ ਚੋਣ</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>ਸੱਜਾ ਦਾਅ</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>ਖੱਬੇ ਦਾਅ</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation>ਸਪਰਸ਼ ਚਾਪ ਚੋਣ</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>ਅਰਧ-ਵਿਆਸ:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>ਬੀਵੀਲ ਚੋਣ</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>ਛਾਂਟੋ</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>ਦੋਵੇਂ ਇਕਾਈਆਂ ਨੂੰ ਬੀਵੀਲ ਲਈ ਛਾਂਟਣ ਲਈ ਜਾਂਚੋ</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>ਲੰਬਾਈ 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>ਲੰਬਾਈ 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>ਬਲਾਕ ਵਿਵਸਥਾ</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>ਬਲਾਕ ਨਾਂ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>ਬਲਾਕ ਨਾਂ-ਤਬਦੀਲ</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>ਨਾਂ ਬਲਾਕ ਨਹੀ ਹੋ ਸਕਿਆ। ਬਲਾਕ ਨਾਂ &quot;%1&quot; ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ।</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Add a block</source>
        <translation>ਇੱਕ ਬਲਾਕ ਵਿੱਚ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>ਸਰਗਰਮ ਬਲਾਕ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>ਸਰਗਰਮ ਬਲਾਕ ਨਾਂ-ਤਬਦੀਲ</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>ਸਰਗਰਮ ਬਲਾਕ ਨੂੰ
ਵੱਖਰੇ ਝਰੋਖੇ ਵਿੱਚ ਸੋਧੋ</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>ਸਰਗਰਮ ਬਲਾਕ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>ਬਲਾਕ ਮੇਨੂ</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>ਸਭ ਬਲਾਕ ਵੱਖ ਕਰੋ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>ਸਭ ਬਲਾਕ ਜਮਾਉ(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>ਬਲਾਕ ਸ਼ਾਮਿਲ(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>ਬਲਾਕ ਹਟਾਓ(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>ਬਲਾਕ ਸੋਧ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>ਦਿੱਖ ਬਦਲੋ(&amp;T)</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>ਸਭ ਬਲਾਕ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>ਸਭ ਬਲਾਕ ਓਹਲੇ</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>ਬਲਾਕ ਨਾਂ-ਤਬਦੀਲ(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>ਬਲਾਕ ਸ਼ਾਮਿਲ(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>ਨਵਾਂ ਬਲਾਕ ਬਣਾਓ(&amp;C)</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>CAD ਸੰਦ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>ਚਾਪਾਂ</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>ਤਿੰਨ ਬਿੰਦੂਆਂ ਨਾਲ ਚਾਪ</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>ਕੇਂਦਰ, ਬਿੰਦੂ, ਕੋਣ ਨਾਲ ਚਾਪ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>ਸਮ-ਕੇਂਦਰੀ</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation>ਅਰਧ-ਵਿਆਸ ਨਾਲ ਮੂਲ ਇਕਾਈ ਤੋਂ ਸਪਰਸ਼ ਚਾਪ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation type="unfinished">ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>ਦੋ ਉਲਟ ਬਿੰਦੂਆਂ ਨਾਲ ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>ਕੇਂਦਰ ਅਤੇ ਅਰਧ-ਵਿਆਸ ਨਾਲ ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>ਕੇਂਦਰ ਅਤੇ ਬਿੰਦੂ ਨਾਲ ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>ਤਿੰਨ ਬਿੰਦੂਆਂ ਨਾਲ ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>ਸਮ-ਕੇਂਦਰ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>ਮਾਪ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>ਡਾਈਮੈਟਰਿਕ ਮਾਪ</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>ਰੇਡੀਅਲ ਮਾਪ</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>ਲੰਬਕਾਰੀ ਮਾਪ</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>ਖਿਤਿਜੀ ਮਾਪ</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>ਰੇਖਿਕ ਮਾਪ</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>ਇਕਸਾਰ ਮਾਪ</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>ਕੋਣੀ ਮਾਪ</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>ਲੀਡਰ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>ਅੰਡਾਕਾਰ</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>ਕੇਂਦਰ, ਦੋ ਬਿੰਦੂਆਂ ਅਤੇ ਕੋਣਾਂ ਨਾਲ ਅੰਡਾਕਾਰ ਚਾਪ</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>ਕੇਂਦਰ ਅਤੇ ਦੋ ਬਿੰਦੂਆਂ ਨਾਲ ਅੰਡਾਕਾਰ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>ਜਾਣਕਾਰੀ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>ਦੂਰੀ (ਬਿੰਦੂ, ਬਿੰਦੂ)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>ਦੂਰੀ (ਇਕਾਈ, ਬਿੰਦੂ)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>ਕੋਣ</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>ਚੁਣੀਆਂ ਇਕਾਈਆਂ ਦੀ ਕੁੱਲ ਲੰਬਾਈ</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation>ਬਹੁਭੁਜ ਦਾ ਖੇਤਰਫਲ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>ਰੇਖਾਵਾਂ</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>ਹੱਥਲੀ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>ਅਰਥੋਗਨ ਰੇਖਾਵਾਂ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>ਦੁਭਾਜਕ</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>ਚੱਕਰੋ ਤੋਂ ਚੱਕਰ ਸਪਰਸ਼ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>ਬਿੰਦੂ ਤੋਂ ਚੱਕਰ ਸਪਰਸ਼ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>ਦੋ ਬਿੰਦੂਆਂ ਨਾਲ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>ਅਨੁਸਾਰੀ ਕੋਣਾਂ ਨਾਲ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>ਦਿੱਤੇ ਕੋਣ ਨਾਲ ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>ਖਿਤਿਜੀ ਰੇਖਾਵਾਂ</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>ਲੰਬਕਾਰੀ ਰੇਖਾਵਾਂ</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>ਚਤੁਰਭੁਜਾਵਾਂ</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>ਕੇਂਦਰ ਅਤੇ ਕੋਨੇ ਨਾਲ ਬਹੁਭੁਜ</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>ਦੋ ਕੋਨਿਆਂ ਨਾਲ ਬਹੁਭੁਜਾਂ</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>ਦੂਰੀ ਨਾਲ ਸਮਾਂਤਰ</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>ਬਿੰਦੂ ਰਾਹੀਂ ਸਮਾਂਤਰ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>ਮੁੱਖ</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>&quot;ਰੇਖਾਵਾਂ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>&quot;ਚਾਪਾਂ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>&quot;ਚੱਕਰ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>&quot;ਮਾਪਕ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>&quot;ਅੰਡਾਕਾਰ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>ਮੋਘਾ / ਗੂੜਾ ਭਰੋ</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>&quot;ਸੋਧ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>&quot;ਮਾਪ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>ਪਾਠ</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>&quot;ਚੋਣ&quot; ਮੇਨੂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>ਬਲਾਕ ਬਣਾਓ</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>ਰਾਸ਼ਟਰ ਚਿੱਤਰ </translation>
    </message>
    <message>
        <source>Points</source>
        <translation>ਬਿੰਦੂ</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>ਸਪਲਾਈਨ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>ਸੋਧੀ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>ਘੁੰਮਾਉ</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>ਪੈਮਾਨਾ</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>ਹਿਲਾਉ</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>ਘੁੰਮਾਉ ਤੇ ਹਿਲਾਓ</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation>ਫੈਲਾਓ</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>ਤਾਣੋ</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>ਗੋਲ</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>ਬੀਲੀਵ</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>ਮਾਤਰਾ ਨਾਲ ਛਾਂਟੋ</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>ਦੋ ਛਾਂਟੋ / ਫੈਲਾਓ</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>ਛਾਂਟੋ / ਫੈਲਾਓ</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>ਦੋ ਕੇਂਦਰਾਂ ਨਾਲ ਘੁੰਮਾਓ</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>ਇਕਾਈ ਗੁਣ ਸੋਧ</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>ਇਕਾਈ ਜੁਮੈਟਰੀ ਸੋਧ</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>ਪ੍ਰਤੀਬਿੰਰ</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>ਵੰਡੋ</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>ਸ਼ਬਦਾਂ ਨੂੰ ਅੱਖਰਾਂ ਵਿੱਚ ਫੈਲਾਉ</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>ਪਾਠ ਸੋਧ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>ਬਿੰਦੂ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>ਇੱਕਲੇ ਬਿੰਦੂ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation>ਬਹੁ-ਰੇਖੀ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation>ਬਹੁ-ਰੇਖਾ ਬਣਾਓ</translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation>ਦੋ ਨੋਡਾਂ ਵਿੱਚੋਂ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>ਨੋਡ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation>ਨੋਡ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation>ਰੇਖਾ-ਖੰਡਾਂ ਛਾਂਟੋ</translation>
    </message>
    <message>
        <source>Append node</source>
        <translation>ਨੋਡ ਵਿੱਚ ਸ਼ਾਮਿਲ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>ਸਭ ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>ਕਾਟਵੀਆਂ ਇਕਾਈਆਂ ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>ਕਾਟਵੀਆਂ ਇਕਾਈਆਂ ਨਾ-ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>ਸਭ ਨਾ-ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>ਉਲਟ ਚੋਣ</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>ਪਰਤ ਚੁਣੋ</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>ਖਾਕਾ (ਨਾ-)ਚੋਣ</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>ਇਕਾਈ (ਨਾ-)ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>ਝਰੋਖਾ ਨਾ-ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>ਝਰੋਖਾ ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>ਕਾਰਵਾਈ ਜਾਰੀ ਰੱਖੋ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>ਗਰਿੱਡ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>ਮੁਕਤ ਸਥਿਤੀ</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>ਅੰਤ-ਬਿੰਦੂਆਂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>ਇਕਾਈ &apos;ਤੇ ਨੇੜਲੇ ਬਿੰਦੂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>ਕੇਂਦਰੀ ਬਿੰਦੂਆਂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>ਮੱਧ ਬਿੰਦੂਆਂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>ਅੰਤ-ਬਿੰਦੂ ਤੋਂ ਇੱਕ ਦਿੱਤੀ ਦੂਰੀ ਨਾਲ ਬਿੰਦੂ &apos;ਤੇ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>ਕਾਟਵੇਂ ਬਿੰਦੂਆਂ ਤੇ ਖੁਦ ਹੀ ਸਨੈਪ</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>ਕੋਈ ਪਾਬੰਦੀ ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>ਅਰਥੋਗਨਲੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>ਖਿਤਿਜੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>ਲੰਬਕਾਰੀ ਪਾਬੰਦੀ</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>ਅਨੁਸਾਰੀ ਜ਼ੀਰੋ ਭੇਜੋ</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>ਅਨੁਸਾਰੀ ਜ਼ੀਰੋ ਲਾਕ</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>ਕਾਟਵੇਂ ਬਿੰਦੂਆਂ ਤੇ ਦਸਤੀ ਸਨੈਪ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation>ਸਪਾਈਨ</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>ਮੁੱਖ ਮੇਨੂ &apos;ਤੇ ਵਾਪਿਸ</translation>
    </message>
    <message>
        <source>Spline</source>
        <translation>ਸਪਲਾਈਨ</translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>ਚੱਕਰ ਚੋਣ</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>ਅਰਧ-ਵਿਆਸ:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>ਪਰਤ ਨਾਲ</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>ਬਲਾਕ ਨਾਲ</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>ਲਾਲ</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>ਪੀਲੀ</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>ਹਰਾ</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>ਨੀਲਾ-ਹਰਾ</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>ਨੀਲਾ</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>ਕਿਰਮਚੀ</translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>ਕਾਲਾ / ਚਿੱਟਾ</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>ਸਲੇਟੀ</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>ਹਲਕਾ ਸਲੇਟੀ</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>ਹੋਰ...</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>ਨਾ-ਤਬਦੀਲ</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>ਕਮਾਂਡ ਲਾਇਨ</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>ਕਮਾਂਡ:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>ਧੁਰੇ</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>ਰੇਖਿਕ ਮਾਪ ਚੋਣ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>ਮਾਪ ਚੋਣ</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>ਨਾਂ:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation>ø</translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation>°</translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation>±</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation>¶</translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation>×</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation>÷</translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>ਮਾਪ ਨਾਂ ਸੰਪਾਦਕ</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>ਮਾਪ ਨਾਂ:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>ਨਾਂ:</translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>ਸ਼ਾਮਿਲ:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation>ø (ਵਿਆਸ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (ਡਿਗਰੀ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation>± (ਜੋੜ / ਘਟਾਓ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation>¶ (ਪਾਈ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>× (ਗੁਣਾ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (ਭਾਗ)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>ਚਾਪ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>ਅਰਧ-ਵਿਆਸ:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>ਕੇਂਦਰ (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>ਕੇਂਦਰ (x):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>ਸ਼ੁਰੂ ਕੋਣ:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>ਅੰਤ ਕੋਣ:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>ਉਲਟ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>ਗੁਣ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>ਚੱਕਰ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>ਅਰਧ-ਵਿਆਸ:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>ਕੇਂਦਰ (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>ਕੇਂਦਰ (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>ਰੇਖਿਕ ਮਾਪ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation>ਮਾਪ</translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>ਅੰਡਾਕਾਰ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>ਕੇਂਦਰ (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>ਕੇਂਦਰ (x):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>ਅੰਤ ਕੋਣ:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>ਸ਼ੁਰੂ ਕੋਣ:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>ਘੁੰਮਾਉ:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>ਪ੍ਰਤੀਬਿੰਬ:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>ਵੱਡਾ:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>ਉਲਟ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>ਮੋਘਾ ਗੁਣ ਚੁਣੋ</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>ਤਰਤੀਬ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>ਪੈਮਾਨਾ:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>ਗੂੜਾ ਭਰੋ</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>ਝਲਕ</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>ਝਲਕ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>ਜੀ ਆਇਆਂ ਨੂੰ</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;QCad ਵਲੋਂ ਜੀ ਆਇਆਂ ਨੂੰ&lt;/b&gt;(new line)
&lt;/font&gt;(new line)
&lt;br&gt;(new line)
ਕਿਰਪਾ ਕਰਕੇ ਨਵੀਂ ਡਰਾਇੰਗ ਲਈ ਵਰਤਣ ਲਈ ਇਕਾਈਆਂ ਅਤੇ ਆਪਣੀ ਪਸੰਦੀਦਾ ਭਾਸ਼ਾ ਦੀ ਚੋਣ ਕਰੋ।&lt;br&gt;(new line)
ਤੁਸੀਂ ਆਪਣੀ ਪਸੰਦ ਬਾਅਦ ਵਿੱਚ QCad ਦੇ ਚੋਣ ਵਾਰਤਾਲਾਪ ਕਦੇ ਵੀ ਬਦਲ ਸਕਦੇ ਹੋ।</translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>ਮੂਲ ਇਕਾਈ:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>ਕਾਰਜ ਭਾਸ਼ਾ:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>ਕਮਾਂਡ ਭਾਸ਼ਾ:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>ਠੀਕ ਹੈ</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>ਦਾਖਲ ਬਿੰਦ (x):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>ਦਾਖਲ ਬਿੰਦ (y):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>ਪੈਮਾਨਾ:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>ਕਤਾਰਾਂ:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>ਕਾਲਮ:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>ਕਤਾਰ ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>ਕਾਲਮ ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>ਰੇਖਾ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>ਅੰਤ ਬਿੰਦੂ (x):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>ਅੰਤ ਬਿੰਦੂ (y):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>ਸ਼ੁਰੂ ਬਿੰਦੂ (y):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>ਸ਼ੁਰੂ ਬਿੰਦੂ (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>ਪ੍ਰਤੀਬਿੰਬ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>ਹਿਲਾਉ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>ਕਈ ਨਕਲਾਂ(&amp;M)</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>ਘੁੰਮਾਉ/ਹਿਲਾਓ ਚੋਣ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>ਕੋਣ (a)(&amp;A):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>ਕਈ ਨਕਲਾਂ(&amp;M)</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Main Unit</source>
        <translation>ਮੁੱਖ ਇਕਾਈ</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>ਲੰਬਾਈ</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>ਦਸ਼ਮਲਵ</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>ਵਿਗਿਆਨਕ</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>ਇੰਜਨੀਅਰਗ</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>ਆਰਚੀਟੈਕਚਰਕਲ</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>ਭਿੰਨ</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>ਕੋਣ</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>ਦਸ਼ਮਲਵ ਡਿਗਰੀਆਂ</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>ਰੇਡੀਂਅਨ</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>ਝਲਕ</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>ਰੇਖਿਕ</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>ਕੋਣੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>ਪੇਪਰ ਫਾਰਮਿਟ</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>ਪਾਠ ਉਚਾਈ:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>ਇਕਾਈਆਂ</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>ਡਿਗਰੀ/ਮਿੰਟ/ਸਕਿੰਘ</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation>ਗਰੇਡੀਐਂਟ</translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation>ਸਰਵੇਅਰ ਦੀਆਂ ਇਕਾਈਆਂ</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>ਚੋਣ</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>&apos;ਇੰਜਨੀਅਰਗ&apos; ਅਤੇ &apos;ਆਰਚੀਟੈਕਚਰਕਲ&apos; ਲੰਬਾਈ ਫਾਰਮਿਟ ਲਈ ਇਕਾਈ ਇੰਚ ਹੀ ਹੋਣੀ ਚਾਹੀਦੀ ਹੈ।</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>ਐਕਸ਼ਟੇਸ਼ਨ ਰੇਖਾ ਐਕਟੇਸ਼ਨ:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>ਤੀਰ ਅਕਾਰ:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>ਐਕਸ਼ਟੇਸ਼ਨ ਰੇਖਾ ਹਾਸ਼ੀਆ ਦੂਰੀ:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>ਮਾਪ ਰੇਖਾ ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>ਡਰਾਇੰਗ ਪਸੰਦ</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>ਪੇਪਰ(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>ਲੈਂਡਸਕੇਪ(&amp;L)</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>ਪੋਰਟਰੇਟ(&amp;o)</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>ਪੇਪਰ ਉਚਾਈ(&amp;H):</translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>ਪੇਪਰ ਚੌੜਾਈ(&amp;W):</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>ਇਕਾਈਆਂ(&amp;U)</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>ਮੁੱਖ ਡਰਾਇੰਗ ਇਕਾਈ(&amp;M):</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>ਫਾਰਮਿਟ(&amp;F):</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>ਸ਼ੁੱਧਤਾ(&amp;r):</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>ਫਾਰਮਿਟ(&amp;o):</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>ਸ਼ੁੱਧਤਾ(&amp;c):</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>ਮਾਪ(&amp;D)</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>ਗਰਿੱਡ ਵਿਵਸਥਾ</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>ਗਰਿੱਡ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>X ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Y ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>ਸਵੈ-ਚਾਲਤ</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>ਗਰਿੱਡ(&amp;G)</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>ਸਪਲਾਈਨ</translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation>ਪ੍ਰਤੀ ਸਪਲਾਇਨ ਪੈਂਚ ਰੇਖਾ ਖੰਡਾਂ ਦੀ ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>16</source>
        <translation>16</translation>
    </message>
    <message>
        <source>32</source>
        <translation>32</translation>
    </message>
    <message>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation>0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation>0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>ਮੇਰੀ ਪਸੰਦ</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>ਅਨੁਵਾਦ:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>ਮੋਘਾ ਤਰਤੀਬ:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>ਫੌਂਟ:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>ਸਕ੍ਰਿਪਟ:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>ਪਾਰਟ ਲਾਇਬ੍ਰੀਆਂ:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>ਭਾਸ਼ਾ</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>ਗਰਾਫਿਕਸ ਝਲਕ</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>ਕਾਰਜ ਪਸੰਦ</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>ਨਵੀਂ ਡਰਾਇੰਗ ਲਈ ਮੂਲ</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>ਦਿੱਖ(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>&amp;GUI ਭਾਸ਼ਾ:</translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>ਕਮਾਂਡ ਭਾਸ਼ਾ(&amp;C):</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>ਵੱਡਾ ਕੇਂਦਰ ਵੇਖਾਓ(&amp;S)</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>ਝਲਕ ਇਕਾਈਆਂ ਦੀ ਗਿਣਤੀ(&amp;r):</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>ਮਾਰਗ(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>ਮੂਲ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>ਇਕਾਈ(&amp;U):</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>ਰੰਗ</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>ਪਿੱਠਭੂਮੀ(&amp;o):</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>ਗਰਿੱਡ ਰੰਗ(&amp;r):</translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>ਮੀਟਾ ਗਰਿੱਡ ਰੰਗ(&amp;M):</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation>#404040</translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>ਫੋਂਟ ਰੰਗ</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>ਸਥਿਤੀ ਪੱਟੀ:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation>#000000</translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation>#ffffff</translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation>#c0c0c0</translation>
    </message>
    <message>
        <source>#808080</source>
        <translation>#808080</translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>ਸਵੈ-ਚਾਲਤ ਪੈਮਾਨਾ ਗਰਿੱਡ(&amp;u)</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>ਚੁਣਿਆ ਰੰਗ(&amp;e):</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation>#a54747</translation>
    </message>
    <message>
        <source>#739373</source>
        <translation>#739373</translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>ਉਘਾੜਨ ਰੰਗ(&amp;H):</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>ਸਭ ਕੀਤੀਆਂ ਤਬਦੀਲੀਆਂ ਨੂੰ ਲਾਗੂ ਕਰਨ ਲਈ ਕਾਰਜ ਨੂੰ ਬੰਦ ਕਰਕੇ ਚਲਾਉ।</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation>Alt+S</translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation>ਘੱਟੋ-ਘੱਟ ਗਰਿੱਡ ਖਾਲੀ ਥਾਂ (px):</translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>ਬਿੰਦੂ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>ਟਿਕਾਣਾ (y):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>ਟਿਕਾਣਾ (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>ਘੁੰਮਾਉ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>ਰੱਦ ਕਰੋ(&amp;C)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>ਕਈ ਨਕਲਾਂ(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>ਕੋਣ (a)(&amp;A):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>ਘੁੰਮਾਉ ਦੋ ਚੋਣ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>ਕਈ ਨਕਲਾਂ(&amp;M)</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>ਕੋਣ (&amp;a):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>ਕੋਣ (&amp;b):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>ਪੈਮਾਨਾ ਗੁਣ</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>ਨਕਲਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>ਰੱਦ ਕਰੋ(&amp;C)</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>ਫੈਕਟਰ (f)(&amp;F):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>ਮੌਜੂਦਾ ਗੁਣ ਵਰਤੋਂ(&amp;a)</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਵਰਤੋਂ(&amp;l)</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>ਅਸਲੀ ਹਟਾਓ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>ਅਸਲੀ ਰੱਖੋ(&amp;K)</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>ਕਈ ਨਕਲਾਂ(&amp;M)</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation>ਸਪਲਾਈਨ</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>ਪਰਤ:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>ਜੁਮੈਟਰੀ</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>ਡਿਗਰੀ:</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>ਬੰਦ ਕੀਤਾ</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>ਪਾਠ</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>ਪਾਠ:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>ਪਾਠ ਸਾਫ਼</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>ਫਾਇਲ ਤੋਂ ਪਾਠ ਲੋਡ</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>ਪਾਠ ਫਾਇਲ ਵਿੱਚ ਸੰਭਾਲੋ</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>ਕੱਟੋ</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>ਨਕਲ</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>ਚੇਪੋ</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>ਫੋਂਟ</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>ਇਕਸਾਰ</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>ਉਪਰ ਸੱਜੇ</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>ਉੱਪਰੇ ਖੱਬੇ</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>ਮੱਧ ਖੱਬੇ</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>ਮੱਧ ਕੇਂਦਰ</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>ਮੱਧ ਸੱਜਾ</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>ਹੇਠਾਂ ਖੱਬੇ</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>ਹੇਠਾਂ ਸੱਜੇ</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>ਮੱਧ ਕੇਂਦਰ</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>ਉੱਪਰ ਕੇਂਦਰ</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>ਕੋਣ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>ਨਿਸ਼ਾਨ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation>ਵਿਆਸ (ø)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>ਡਿਗਰੀ (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation>ਜੋੜ / ਘਟਾਓ (±)</translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation>At (@)</translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>ਹੈਂਸ਼ (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>ਡਾਲਰ ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation>ਕਾਪੀਰਾਈਟ (©)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (®)</source>
        <translation>ਰਜਿਸਟਰਡ (®)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>ਪੈਰਾ (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation>ਪਾਈ (¶)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation>ਪਾਊਂਡ (£)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (¥)</source>
        <translation>ਯੇਨ (¥)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>ਗੁਣਾ (×)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation>ਭਾਗ (÷)</translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>ਯੂਨੀਕੋਡ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>ਸਫ਼ਾ:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>ਅੱਖਰ:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation>[0000-007F] ਮੂਲ ਲੈਟਿਨ</translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation>[0080-00FF] ਲੈਟਿਨ-1 ਹੋਰ</translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation>[0100-017F] Latin Extended-A</translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation>[0180-024F] Latin Extended-B</translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation>[0250-02AF] IPA Extensions</translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation>[02B0-02FF] Spacing Modifier Letters</translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation>[0300-036F] Combining Diacritical Marks</translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation>[0370-03FF] Greek and Coptic</translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation>[0400-04FF] Cyrillic</translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation>[0500-052F] Cyrillic Supplementary</translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation>[0530-058F] Armenian</translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation>[0590-05FF] Hebrew</translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation>[0600-06FF] Arabic</translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation>[0700-074F] Syriac</translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation>[0780-07BF] Thaana</translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation>[0900-097F] ਦੇਵਨਾਗਰੀ</translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation>[0980-09FF] ਬੰਗਾਲੀ</translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation>[0A00-0A7F] ਗੁਰਮੁਖੀ</translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation> [0A80-0AFF] ਗੁਜਰਾਤੀ</translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation>[0B00-0B7F] ਉੜੀਆ</translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation>[0B80-0BFF] ਤਾਮਿਲ</translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation>[0C00-0C7F] ਤੇਲਗੂ</translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation>[0C80-0CFF] ਕੰਨੜ</translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation>[0D00-0D7F] ਮਲਿਆਲਮ</translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation>[0D80-0DFF] Sinhala</translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation>[0E00-0E7F] Thai</translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation>[0E80-0EFF] Lao</translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation>[0F00-0FFF] Tibetan</translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation>[1000-109F] Myanmar</translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation>[10A0-10FF] Georgian</translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation>[1100-11FF] Hangul Jamo</translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation>[1200-137F] Ethiopic</translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation>[13A0-13FF] Cherokee</translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation>[1400-167F] Unified Canadian Aboriginal Syllabic</translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation>[1680-169F] Ogham</translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation>[16A0-16FF] Runic</translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation>[1700-171F] Tagalog</translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation>[1720-173F] Hanunoo</translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation>[1740-175F] Buhid</translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation>[1760-177F] Tagbanwa</translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation>[1780-17FF] Khmer</translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation>[1800-18AF] Mongolian</translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation>[1E00-1EFF] Latin Extended Additional</translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation>[1F00-1FFF] Greek Extended</translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation>[2000-206F] ਆਮ ਵਿਰਾਮ ਚਿੰਨ</translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation>[2070-209F] Superscripts and Subscripts</translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation>[20A0-20CF] Currency Symbols</translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation>[20D0-20FF] Combining Marks for Symbols</translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation>[2100-214F] Letterlike Symbols</translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation>[2150-218F] ਨੰਬਰ ਫਾਰਮ</translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation>[2190-21FF] ਤੀਰ</translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation>[2200-22FF]  ਗਣਿਤ ਓਪਰੇਟਰ</translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation>[2300-23FF] ਫੁਟਕਲ ਤਕਨੀਕੀ</translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation>[2400-243F] ਕੰਟਰੋਲ ਤਸਵੀਰਾਂ</translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation>[2440-245F] Optical Character Recognition</translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation>[2460-24FF] Enclosed Alphanumerics</translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation>[2500-257F] Box Drawing</translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation>[2580-259F] Block Elements</translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation>[25A0-25FF] ਜੁਮੈਟਰੀ ਸ਼ਕਲਾਂ</translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation>[2600-26FF] ਫੁਟਕਲ ਨਿਸ਼ਾਨ</translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation>[2700-27BF] Dingbats</translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation>[27C0-27EF] Miscellaneous Mathematical Symbols-A</translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation>[27F0-27FF] Supplemental Arrows-A</translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation>[2800-28FF] Braille Patterns</translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation>[2900-297F] Supplemental Arrows-B</translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation>[2980-29FF] Miscellaneous Mathematical Symbols-B</translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation>[2A00-2AFF] Supplemental Mathematical Operators</translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation>[2E80-2EFF] CJK Radicals Supplemen</translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation>[2F00-2FDF] Kangxi Radicals</translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation>[2FF0-2FFF] Ideographic Description Characters</translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation>[3000-303F] CJK Symbols and Punctuation</translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation>[3040-309F] Hiragana</translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation>[30A0-30FF] Katakana</translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation>[3100-312F] Bopomofo</translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation>[3130-318F] Hangul Compatibility Jamo</translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation>[3190-319F] Kanbun</translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation>[31A0-31BF] Bopomofo Extended</translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation>[3200-32FF] Enclosed CJK Letters and Months</translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation>[3300-33FF] CJK Compatibility</translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation>[3400-4DBF] CJK Unified Ideographs Extension A</translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation>[4E00-9FAF] CJK Unified Ideographs</translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation>[A000-A48F] Yi Syllables</translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation>[A490-A4CF] Yi Radicals</translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation>[AC00-D7AF] Hangul Syllables</translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation>[D800-DBFF] High Surrogates</translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation>[DC00-DFFF] Low Surrogate Area</translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation>[E000-F8FF] Private Use Area</translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation>F900-FAFF] CJK Compatibility Ideographs</translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation>[FB00-FB4F] Alphabetic Presentation Forms</translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation>[FB50-FDFF] Arabic Presentation Forms-A</translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation>[FE00-FE0F] Variation Selectors</translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation>[FE20-FE2F]Combining Half Marks</translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation>[FE30-FE4F] CJK Compatibility Forms</translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation>[FE50-FE6F] Small Form Variants</translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation>[FE70-FEFF] Arabic Presentation Forms-B</translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation>[FF00-FFEF] Halfwidth and Fullwidth Forms</translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation>[FFF0-FFFF] Specials</translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation>[10300-1032F] Old Italic</translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation>[10330-1034F] Gothic</translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation>[10400-1044F] Deseret</translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation>[1D000-1D0FF] Byzantine Musical Symbols</translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation>[1D100-1D1FF] Musical Symbols</translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation>[1D400-1D7FF] Mathematical Alphanumeric Symbols</translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation>[20000-2A6DF] CJK Unified Ideographs Extension B</translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation>[E0000-E007F] ਟੈਗ</translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation>[F0000-FFFFD] Supplementary Private Use Area-A</translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation>[100000-10FFFD] Supplementary Private Use Area-B</translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>ਉਚਾਈ(&amp;H):</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>ਰੇਖਾ ਖਾਲੀ ਥਾਂ(&amp;s):</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>ਮੂਲ ਰੇਖਾ ਖਾਲੀ ਥਾਂ(&amp;D)</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation>Alt+D</translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation>ਸੰਭਾਲੋ(&amp;S)</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>ਏਦਾਂ ਸੰਭਾਲੋ(&amp;A)..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>ਰੱਦ ਕਰੋ(&amp;C)</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>ਕੋਈ ਪਾਠ ਨਹੀਂ ਦਿੱਤਾ ਹੈ।</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation>QCad</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>ਬੰਦ ਕਰੋ(&amp;l)</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>ਚੋਣ ਦਿਓ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>ਘੁੰਮਾਓ ਕੋਣ</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>ਫੈਕਟਰ:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>ਪੈਮਾਨਾ ਫੈਕਟਰ</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>ਚਿੱਤਰ ਮਾਹਿਰ ਚੋਣ</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>ਬਿਟਮੈਪ ਚੋਣ</translation>
    </message>
    <message>
        <source>640</source>
        <translation>640</translation>
    </message>
    <message>
        <source>480</source>
        <translation>480</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>ਚੌੜਾਈ:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>ਉਚਾਈ:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>ਪਿੱਠਭੂਮੀ</translation>
    </message>
    <message>
        <source>White</source>
        <translation>ਚਿੱਟੀ</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>ਕਾਲੀ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>ਰੈਜ਼ੋਲੇਸ਼ਨ:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>ਸਵੈ-ਚਾਲਤ</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>25</source>
        <translation>25</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>75</source>
        <translation>75</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>ਚੋਣ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>ਘੁੰਮਾਓ ਕੋਣ</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>ਫੈਕਟਰ:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>ਪੈਮਾਨਾ ਫੈਕਟਰ</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>ਲੜੀ:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>ਕਾਲਮਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>ਕਤਾਰਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>ਖਾਲੀ ਥਾਂ:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>ਕਾਲਮ ਖਾਲੀ ਥਾਂ</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>ਕਤਾਰ ਖਾਲੀ ਥਾਂ</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>- ਨਾ-ਤਬਦੀਲ -</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>ਪਰਤ ਵਿਵਸਥਾ</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>ਪਰਤ ਨਾਂ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>ਮੂਲ ਪੈਨ</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ਠੀਕ ਹੈ(&amp;O)</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Show all layers</source>
        <translation>ਸਭ ਪਰਤਾਂ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>ਸਭ ਪਰਤਾਂ ਓਹਲੇ</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>ਇੱਕ ਪਰਤ ਸ਼ਾਮਿਲ</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>ਮੌਜੂਦਾ ਪਰਤ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>ਪਰਤ ਗੁਣ ਸੋਧ / ਨਾਂ-ਤਬਦੀਲ</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>ਪਰਤ ਮੇਨੂ</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>ਸਭ ਪਰਤਾਂ ਵੱਖ ਕਰੋ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>ਸਭ ਪਰਤਾਂ ਜਮਾਉ(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>ਪਰਤ ਸ਼ਾਮਿਲ(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>ਬਲਾਕ ਹਟਾਓ(&amp;R)</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>ਪਰਤ ਸੋਧ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>ਦਿੱਖ ਬਦਲੋ(&amp;T)</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>ਲਾਇਬ੍ਰੇਰੀ ਸ਼ਾਮਿਲ ਚੋਣ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>ਘੁੰਮਾਓ ਕੋਣ</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>ਫੈਕਟਰ:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>ਪੈਮਾਨਾ ਫੈਕਟਰ</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>ਲਾਇਬ੍ਰੇਰੀ ਝਲਕ</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>ਡਾਇਰੈਕਟਰੀਆਂ</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>ਸ਼ਾਮਿਲ</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>ਰੇਖਾ ਕੋਣ ਚੋਣ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>ਰੇਖਾ ਕੋਣ</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>ਲੰਬਾਈ:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>ਰੇਖਾ ਦੀ ਲੰਬਾਈ</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>ਸਨੈਪ ਬਿੰਦੂ:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>ਸ਼ੁਰੂ</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>ਮੱਧ</translation>
    </message>
    <message>
        <source>End</source>
        <translation>ਅੰਤ</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>ਰੇਖਾ ਦੁਭਾਜਕ ਚੋਣ</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>ਲੰਬਾਈ:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>ਦੋ-ਭੁਜਾਕ ਦੀ ਲੰਬਾਈ</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>ਬਣਾਉਣ ਲਈ ਦੋ-ਭਾਜਕਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>ਰੇਖਾ ਚੋਣ</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>ਬੰਦ</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>ਵਾਪਿਸ</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>ਰੇਖਾ ਸਮਾਂਤਰ ਚੋਣ</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>ਦੂਰੀ:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>ਅਸਲੀ ਇਕਾਈ ਤੋਂ ਦੂਰੀ</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>ਬਣਾਉਣ ਲਈ ਸਮਾਂਤਰਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>ਰੇਖਾ ਸਮਾਂਤਰ ਰਾਹੀਂ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>ਬਣਾਉਣ ਲਈ ਸਮਾਂਤਰਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>ਬਹੁਭੁਜ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>ਭੁਜਾਵਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>ਬਹੁਭੁਜ ਚੋਣ</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>ਗਿਣਤੀ:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>ਭੁਜਾਵਾਂ ਦੀ ਗਿਣਤੀ</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>ਰੇਖਾ ਅਨੁਸਾਰੀ ਕੋਣ ਚੋਣ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>ਰੇਖਾ ਕੋਣ</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>ਲੰਬਾਈ:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>ਰੇਖਾ ਦੀ ਲੰਬਾਈ</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>ਪਰਤ ਨਾਲ</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>ਬਲਾਕ ਨਾਲ</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>ਕੋਈ ਪੈਨ ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>ਲਗਾਤਾਰ</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>ਬਿੰਦੀ</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>ਬਿੰਦੀ (ਛੋਟੀ)</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>ਬਿੰਦੀ (ਵੱਡੀ)</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>ਡੈਸ਼</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>ਡੈਸ਼ (ਛੋਟੀ)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>ਡੈਸ਼ (ਵੱਡੀ)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>ਡੈਸ਼ ਡਾਟ </translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>ਡੈਸ਼ ਡਾਟ (ਛੋਟੀ)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>ਡੈਸ਼ ਡਾਟ (ਵੱਡੀ)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>ਭਾਗ</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>ਭਾਗ (ਛੋਟੀ)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>ਭਾਗ (ਵੱਡੀ)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>ਕੇਂਦਰ</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>ਕੇਂਦਰ (ਛੋਟਾ)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>ਕੇਂਦਰ (ਵੱਡਾ)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>ਹਾਸ਼ੀਆ</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>ਹਾਸ਼ੀਆ (ਛੋਟਾ)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>ਹਾਸ਼ੀਆ (ਵੱਡਾ)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- ਨਾ-ਤਬਦੀਲ -</translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>ਮਾਊਸ</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>ਸੱਜਾ</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>ਖੱਬਾ</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>ਭੇਜਣ ਘੁੰਮਾਉਣ ਚੋਣ</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation>ਛਪਾਈ ਝਲਕ ਚੋਣ</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation>ਕਾਲਾ / ਚਿੱਟਾ ਢੰਗ ਤਬਦੀਲ</translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation>ਕੇਂਦਰ ਤੋਂ ਸਫ਼ਾ</translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation>ਸਫ਼ੇ ਤੇ ਫਿੱਟ</translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>ਗੋਲ ਚੋਣ</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>ਛਾਂਟੋ</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>ਗੋਲ ਕਰਨ ਲਈ ਦੋਵੇ ਭੁਜਾਵਾਂ ਦੀ ਛਾਂਟੀ ਕਰਨ ਦੀ ਪੜਤਾਲ ਕਰੋ</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>ਅਰਧ-ਵਿਆਸ:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>ਚੋਣ</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>ਚੁਣੀਆਂ ਇਕਾਈਆਂ:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>ਸਨੈਪ ਦੂਰੀ ਚੋਣ</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>ਦੂਰੀ:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation>ਸਪਾਈਨ ਚੋਣ</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>ਡਿਗਰੀ:</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>ਬੰਦ ਕੀਤਾ</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>ਵਾਪਿਸ</translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>ਪਾਠ ਚੋਣ</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>ਪਾਠ:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>ਕੋਣ:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>ਛਾਂਟ ਮੁੱਲ ਚੋਣ</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>ਦੂਰੀ ਹੈ। ਰਿਣਾਤਮਕ ਮੁੱਲਾਂ ਨੂੰ ਹਟਾਇਆ ਜਾ ਰਿਹਾ ਹੈ, ਧਨਾਤਮਕ ਮੁੱਲਾਂ ਨੂੰ ਫੈਲਾਇਆ ਜਾ ਰਿਹਾ ਹੈ।</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>ਮਾਤਰਾ:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>ਪੈਨ</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>ਰੇਖਾ ਕਿਸਮ:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>ਚੌੜਾਈ:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>ਰੰਗ:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>ਪਰਤ ਨਾਲ</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>ਬਲਾਕ ਨਾਲ</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>ਮੂਲ</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation>0.00ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation>0.05ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation>0.09ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation>0.13ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation>0.15ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation>0.18ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation>0.20ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation>0.25ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation>0.30ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation>0.35ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation>0.40ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation>0.50ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation>0.53ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation>0.60ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation>0.70ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation>0.80ਮਿਮੀ</translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation>0.90ਮਿਮੀ</translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation>1.00ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation>1.06ਮਿਮੀ</translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation>1.20ਮਿਮੀ</translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation>1.40ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation>1.58ਮਿਮੀ</translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation>2.00ਮਿਮੀ (ISO)</translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation>2.11ਮਿਮੀ</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- ਨਾ-ਤਬਦੀਲ -</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>ਚੇਤਾਵਨੀ</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>ਪਰਤ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>ਪਰਤ &quot;%1&quot; ਅਤੇ ਇਸ ਦੀਆਂ ਸਭ ਇਕਾਈਆਂ ਨੂੰ ਹਟਾ ਦਿੱਤਾ ਜਾਵੇਗਾ।</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>ਪਰਤ &quot;%1&quot; ਨੂੰ ਕਦੇ ਵੀ ਹਟਾਇਆ ਨਹੀਂ ਜਾ ਸਕਦਾ ਹੈ।</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>ਪਰਤ ਵਾਰਤਾਲਾਪ</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>ਬਲਾਕ ਹਟਾਓ</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>ਬਲਾਕ &quot;%1&quot; ਅਤੇ ਇਸ ਦੀਆਂ ਸਭ ਇਕਾਈਆਂ ਨੂੰ ਹਟਾ ਦਿੱਤਾ ਜਾਵੇਗਾ।</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>ਪਰਤ ਗੁਣ</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>&quot;%1&quot;  ਨਾਂ ਨਾਲ ਪਰਤ ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਵੱਖਰਾ ਨਾਂ ਦਿਓ।</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>ਡਰਾਇੰਗ ਏਦਾਂ ਸੰਭਾਲੋ</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 ਪਹਿਲਾਂ ਹੀ ਮੌਜੂਦ ਹੈ।
ਕੀ ਇਸ ਨੂੰ ਤਬਦੀਲ ਕਰਨਾ ਹੈ?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>ਹਾਂ</translation>
    </message>
    <message>
        <source>No</source>
        <translation>ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>ਰੱਦ ਕਰੋ</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>ਡਰਾਇੰਗ ਖੋਲੋ</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>ਚਿੱਤਰ ਖੋਲੋ</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation>Windows Bitmap</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation>Multiple-image Network Graphics</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation>Portable Grey Map</translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation>Portable Network Graphic</translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation>Portable Pixel Map</translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation>X Bitmap Format</translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation>X Pixel Map</translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>ਸਭ ਚਿੱਤਰ ਫਾਇਲਾਂ (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation>ਡਰਾਇੰਗ ਐਕਸ਼ਚੇਜ਼ %1</translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation>QCad 1.x ਫਾਇਲ %1</translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>ਫੋਂਟ %1</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>ਸਭ ਫਾਇਲਾਂ (*.*)</translation>
    </message>
</context>
</TS>
