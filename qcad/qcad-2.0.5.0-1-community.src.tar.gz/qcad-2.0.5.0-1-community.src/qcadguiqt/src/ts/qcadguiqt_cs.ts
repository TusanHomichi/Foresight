<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Nový</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="obsolete">&amp;Otevřít...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="obsolete">&amp;Uložit</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="obsolete">Uložit &amp;jako...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Tisk</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Ukončit</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">U&amp;končit</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>Vypne program</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="obsolete">Přiblížit</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="obsolete">Při&amp;blížit</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="obsolete">Zvětší požadovanou oblast kreslící plochy</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="obsolete">Oddálit</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="obsolete">Od&amp;dálit</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="obsolete">Oddálí pohled na kreslící plochu</translation>
    </message>
    <message>
        <source>Auto Zoom</source>
        <translation type="obsolete">Automatické zvětšení</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="obsolete">&amp;Automatické zvětšení</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="obsolete">Automaticky upraví zobrazení objektů kreslící plochy </translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation type="obsolete">Zvětšit Okno</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="obsolete">Zvětšit &amp;Okno</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="obsolete">Přiblíží objekty označené oknem</translation>
    </message>
    <message>
        <source>Pan Zoom</source>
        <translation type="obsolete">Posun pohledu</translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="obsolete">Posun Po&amp;hledu</translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="obsolete">Posune pohled na obrazovce</translation>
    </message>
    <message>
        <source>Redraw</source>
        <translation type="obsolete">Překreslit</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="obsolete">&amp;Překreslit</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Zpět</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">&amp;Zpět</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="obsolete">Vrátí zpět poslední akci</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Vpřed</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Vpřed</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="obsolete">Opakuje posledně vrácenou akci</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Vyjmout</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">Vyj&amp;mout</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopírovat</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">&amp;Kopírovat</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Vložit</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">&amp;Vložit</translation>
    </message>
    <message>
        <source>Select Entity</source>
        <translation type="obsolete">Vyber prvek</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="obsolete">Vybere jednotlivé prvky</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation type="obsolete">Výběr oknem</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="obsolete">Výběr &amp;oknem</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="obsolete">Vybere všechny prvky v daném okně</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="obsolete">Odznačit oknem</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="obsolete">Odznačit o&amp;knem</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="obsolete">Odznačí všechny prvky v daném okně</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">O(d)značit Obrys</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">O(d)značí spojené prvky</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="obsolete">Vybrat vše</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="obsolete">&amp;Vybrat vše</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="obsolete">Vybere všechny prvky</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Odznačit vše</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="obsolete">O&amp;dznačit vše</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="obsolete">Zruší výběr všech prvků</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="obsolete">Inverzní výběr</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="obsolete">&amp;Inverzní výběr</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="obsolete">Invertuje stávající výběr</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="obsolete">Vyber protínající se prvky</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="obsolete">Pro&amp;tínající se prvky</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="obsolete">Vybere všechny prvky protnuté čarou</translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="obsolete">Zrušit výběr protínajících se prvků</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="obsolete">Zrušit výběr protí&amp;najících se prvků</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="obsolete">Zruší výběr všech prvků které protíná čára</translation>
    </message>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="obsolete">O(d)značit hladinu</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="obsolete">O(d)značí všechny prvky v dané hladině</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Body</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="obsolete">&amp;Body</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="obsolete">Kreslí body</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation type="obsolete">Úsečka: 2 body</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="obsolete">2 &amp;Body</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="obsolete">Kreslí úsečky</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Úsečka: úhel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Úhel</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Kreslí úsečky pod daným úhlem</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Úsečka: vodorovně</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Vodorovně</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Kreslí vodorovné úsečky</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="obsolete">vod./svis. úsečka</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="obsolete">V&amp;odorovně / Svisle</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="obsolete">Kreslí vodorovné / svislé úsečky </translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Úsečka: Svisle</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Svisle</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Kreslí svislé úsečky</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation type="obsolete">Čára: Od ruky</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="obsolete">Čára od r&amp;uky</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="obsolete">Kreslí čáru od ruky</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Rovnoběžně</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="obsolete">&amp;Rovnoběžně</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Obdélník</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="obsolete">&amp;Obdélník</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="obsolete">Kreslí obdélníky</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation type="obsolete">Osa úhlu</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="obsolete">Osa ú&amp;hlu</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="obsolete">Kreslí osy úhlu</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="obsolete">Tečna (B,K)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="obsolete">&amp;Tečna (B,K)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="obsolete">Kreslí tečnu (bod, kružnice)</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="obsolete">Tečna (K,K)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="obsolete">T&amp;ečna (K,K)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="obsolete">Kreslí tečnu (kružnice,kružnice)</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Kolmo</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">&amp;Kolmo</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Kreslí kolmou úsečku</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation type="obsolete">Relativní úhel</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="obsolete">Re&amp;lativní úhel</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="obsolete">Kreslí úsečku zadanou relativním úhlem</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="obsolete">Mnohoúhelník</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="obsolete">&amp;Mnohoúhelník (Stř,Roh)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="obsolete">Kreslí mnohoúhelník zadaný středem a rohem</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cor,Cor)</source>
        <translation type="obsolete">Mno&amp;hoúhelník (Roh,Roh)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="obsolete">Kreslí mnohoúhelník zadaný dvěma rohy</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="obsolete">Kružnice: Střed, Bod</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="obsolete">Střed, &amp;Bod</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="obsolete">Kreslí kružnice zadané středem a bodem</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="obsolete">Kružnice: Střed, Poloměr</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="obsolete">Střed, &amp;Poloměr</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="obsolete">Kreslí kružnice zadané středem a poloměrem</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="obsolete">Kružnice: 2 body</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="obsolete">2 body</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="obsolete">Kreslí kružnice zadané 2 body</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Kružnice: 3 body</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 body</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Kreslí kružnice zadané 3 body</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="obsolete">Oblouk: Střed, Bod, Úhel</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="obsolete">&amp;Střed, Bod, Úhel</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="obsolete">Kreslí oblouky</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="obsolete">Oblouk: 3 body</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="obsolete">&amp;3 body</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="obsolete">Kreslí oblouky zadané 3 body</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="obsolete">Elipsa zadaná osou</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="obsolete">&amp;Elipsa (Osa)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="obsolete">Kreslí elipsy</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="obsolete">Elipsovité oblouky zadané osou</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="obsolete">Elipsovitý &amp;oblouk (osa)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="obsolete">Kreslí elipsovité oblouky</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Text</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="obsolete">&amp;Text</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="obsolete">Tvoří textové prvky</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="obsolete">Kreslí šrafy a výplně ploch</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation type="obsolete">Zarovnaná</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="obsolete">&amp;Zarovnaná</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Zarovnaná kóta</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="obsolete">Přímá</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="obsolete">&amp;Přímá</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="obsolete">Přímá kóta</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="obsolete">Vodorovná</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="obsolete">Vodorovná kóta</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="obsolete">Svislá</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="obsolete">Svislá kóta</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation type="obsolete">Poloměr</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="obsolete">Polo&amp;měr</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="obsolete">Kóta poloměru</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation type="obsolete">Průměr</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="obsolete">P&amp;růměr</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="obsolete">Kóta průměru</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation type="obsolete">Úhel</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="obsolete">&amp;Úhel</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="obsolete">Úhlová kóta</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation type="obsolete">Odkaz</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="obsolete">&amp;Odkaz</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="obsolete">Odkaz</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Smazat</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;Smazat</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="obsolete">Smaže prvky</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation type="obsolete">Smazat &quot;od ruky&quot;</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="obsolete">&amp;Smazat &quot;od ruky&quot;</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Posun</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Posun</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Posune prvky</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation type="obsolete">Otočení</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="obsolete">Otoč&amp;ení</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="obsolete">Otočí prvky</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="obsolete">Měřítko</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="obsolete">&amp;Měřítko</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="obsolete">Změní měřítko prvků</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Zrcadlení</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">&amp;Zrcadlení</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Ozrcadlí vybrané prvky</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation type="obsolete">Posun a otočení</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="obsolete">P&amp;osun a Otočení</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="obsolete">Posune a otočí prvky</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation type="obsolete">Otočit okolo dvou středů</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="obsolete">Otočit okolo &amp;dvou středů</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="obsolete">Otočí prvky okolo dvou středů</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Zkrátit</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">Z&amp;krátit</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Zkrátí prvky</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Zkrátit oba dva</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">Zkrát&amp;it oba dva</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Zkrátí oba dva prvky</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Prodloužit</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">Prodlo&amp;užit</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Prodlouží o danou délku</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">Ořez&amp;at</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Ořeže prvky</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation type="obsolete">Natáhnout</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="obsolete">&amp;Natáhnout</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="obsolete">Natáhne prvky</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation type="obsolete">Úkos</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="obsolete">&amp;Úkos</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="obsolete">Vytvoří úkos mezi prvky</translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="obsolete">Zaoblení</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="obsolete">Zao&amp;blení</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="obsolete">Vytvoří zaoblení mezi prvky</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>Volný</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>&amp;Volný</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Volné umístění</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Mřížka</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>Mří&amp;žka</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>Uchopení do mřížky</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>Koncové body</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>&amp;Koncové body</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>Uchopení za koncové body</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>Nejblíže</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>Ne&amp;jblíže</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>Uchopení za nejbližší bod na prvku</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>&amp;Střed</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>Uchopení za střed</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Polovina</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>Polovin&amp;a</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Uchopení za body v polovině prvku</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>Vzdálenost od koncového bodu</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>Vz&amp;dálenost od koncového bodu</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>Uchopení za body s danou vzdáleností od koncového bodu</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>Průsečík</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>P&amp;růsečík</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>Uchopení za průsečíky</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation type="obsolete">Průsečík manuálně</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="obsolete">Průsečík ma&amp;nuálně</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="obsolete">Uchopení za průsečík ručně</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>Bez omezení</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>&amp;Bez omezení</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>Uchopení bez omezení</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>Pouze kolmo</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>Pouze ko&amp;lmo</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>Uchopení pouze v kolmém směru</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>Pouze vodorovně</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>Pouze v&amp;odorovně</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>Uchopení pouze ve vodorovném směru</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>Pouze svisle</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>Pouze sv&amp;isle</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>Uchopení pouze ve svislém směru</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation type="obsolete">Nastavit relativní počátek</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="obsolete">Nastavit relativní &amp;počátek</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="obsolete">Nastaví pozici relativního počátku</translation>
    </message>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="obsolete">(Odemknout) Zamknout relativní počátek</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="obsolete">(Odemknout) &amp;Zamknout relativní počátek</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="obsolete">Uzamkne nebo odemkne polohu relativního počátku</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation type="obsolete">Bod uvnitř obrysu</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="obsolete">&amp;Bod uvnitř obrysu</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="obsolete">Zkontroluje, zda-li je zadaný bod uvnitř zvoleného obrysu</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Zobrazit vše</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">&amp;Zobrazit vše</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Rozmrazí všechny hladiny</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Skrýt vše</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">&amp;Skrýt vše</translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation type="obsolete">Zmrazí všechny hladiny</translation>
    </message>
    <message>
        <source>Add Layer</source>
        <translation type="obsolete">Vytvoří novou hladinu</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="obsolete">&amp;Přidat hladinu</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation type="obsolete">Odstraní zvolenou hladinu</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="obsolete">&amp;Odebrat hladinu</translation>
    </message>
    <message>
        <source>Edit Layer</source>
        <translation type="obsolete">Umožní upravit vlastnosti zvolené hladiny</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="obsolete">&amp;Editovat hladinu</translation>
    </message>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="obsolete">Přepnout viditelnost hladiny</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="obsolete">Přep&amp;nout hladinu</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="obsolete">Přepne na vybranou hladinu</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Rozmrazí všechny bloky</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Zmrazí všechny bloky</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Připojí blok</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">&amp;Připojit blok</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Odstraní blok</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">Vyj&amp;mout blok</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Přejmenuje blok</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">Pře&amp;jmenovat blok</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Přejmenuje blok a všechny vložky</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Umožní změnit vlastnosti bloku</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">&amp;Editovat blok</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Vloží blok</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">V&amp;ložit blok</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Přepnout viditelnost bloku</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">Přep&amp;nout blok</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Přepnout blok</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation type="obsolete">Vytvoří nový blok</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">&amp;Vytvořit blok</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Rozložit</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">Rozloži&amp;t</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Rozloží bloky a jiné skupiny prvků</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>Základní nastavení programu</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="obsolete">Výkres</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="obsolete">Vytvoří nový výkres</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="obsolete">Otevře výkres</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="obsolete">Uloží aktuální výkres</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="obsolete">Uloží aktuální výkres pod novým jménem</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>Uzavře aktuální výkres</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>Vytiskne aktuální výkres</translation>
    </message>
    <message>
        <source>New Drawing</source>
        <translation type="obsolete">Nový výkres</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation type="obsolete">Otevřít výkres</translation>
    </message>
    <message>
        <source>Save Drawing</source>
        <translation type="obsolete">Uložit výkres</translation>
    </message>
    <message>
        <source>Save Drawing As</source>
        <translation type="obsolete">Uložit výkres jako</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>Zavřít výkres</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>Tisknout výkres</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="obsolete">Vyjme prvky a uloží je do schránky</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="obsolete">Zkopíruje prvky do schránky</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="obsolete">Vloží obsah schránky</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="obsolete">O(d)&amp;značit prvek</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">O(d)značit o&amp;brys</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="obsolete">Kreslí rovnoběžky k existujícím čárám, obloukům, kružnicím</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation type="obsolete">Rovnoběžne skrz bod</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="obsolete">Rov&amp;noběžně skrz bod</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="obsolete">Kreslí rovnoběžku procházející daným bodem</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="obsolete">Vlastnosti skupiny prvků</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="obsolete">&amp;Vlastnosti skupiny prvků</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="obsolete">Upraví vlastnosti skupiny prvků</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="obsolete">Označené vymaž</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="obsolete">Označené V&amp;ymaž</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="obsolete">Vymaže vybrané prvky</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">Náhled před tiskem</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="obsolete">Ná&amp;hled před tiskem</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="obsolete">Zobrazí náhled tisku</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation type="obsolete">Vzdálenost z bodu do bodu</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="obsolete">Vzdálenost z &amp;bodu do bodu</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="obsolete">Změří vzdálenost mezi dvěma body</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="obsolete">Vzdálenost od prvku k bodu</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="obsolete">Vzdálenost od &amp;prvku k bodu</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="obsolete">Změří vzdálenost mezi prvkem a bodem</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation type="obsolete">Úhel mezi dvěma čarami</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="obsolete">&amp;Úhel mezi dvěma čarami</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="obsolete">Změří úhel mezi dvěma čarami</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>Exportu výkresu</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Export..</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>Exportuje aktuální výkres jako obrázek zvoleného typu</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Vlastnosti prvku</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="obsolete">Upraví vlastnosti prvku</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="obsolete">&amp;Vlastnosti prvku</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>&amp;Nastavení programu</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="obsolete">Nastavení &amp;aktuálního výkresu</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="obsolete">Nastavení pro aktuální výkres</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>Povolí/Zakáže mřížku</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Kružnice: Soustředná</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Soustředná</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Kreslí kružnice soustředné s již existujícími kružnicemi</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Oblouk: Soustředný</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Kreslí oblouky soustředné s již existujícími oblouky</translation>
    </message>
    <message>
        <source>Hatch</source>
        <translation type="obsolete">Šrafy</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="obsolete">&amp;Šrafy</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="obsolete">Obrázek</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="obsolete">Ob&amp;rázek</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="obsolete">Vložit obrázek (bitmapu)</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Stavový řádek</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>&amp;Stavový řádek</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>Povolí/Zakáže zobrazení stavového řádku</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation type="obsolete">Celková délka vybraných prvků</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="obsolete">&amp;Celková délka vybraných prvků</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="obsolete">Změří celkovou délku vybraných prvků</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Náčrt</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>Náčr&amp;t</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>Povolí/zakáže mód náčrtu</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>Otevřít IDE</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>Otevřít I&amp;DE</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>Otevře integrované vývojové prostředí pro tvorbu skriptů</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>Spustit skript..</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>&amp;Spustit skript..</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>Spustí skript</translation>
    </message>
    <message>
        <source>CAM Export</source>
        <translation type="obsolete">CAM Export</translation>
    </message>
    <message>
        <source>&amp;CAM Export..</source>
        <translation type="obsolete">&amp;CAM Export..</translation>
    </message>
    <message>
        <source>Exports the current drawing as CAM CNC program</source>
        <translation type="obsolete">Exportuje aktuální výkres jako CAM program pro CNC stroj</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Tisk...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Vypnout</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Vypnout</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>Vlastnosti Oblouku</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>Ve směru chodu hodinových ručiček</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>Proti směru chodu hodinových ručiček</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="unfinished">Poloměr:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>Vlastnosti Zkosení</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Zkrátit</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>Zkusí zkrátit oba prvky a vytvoří zkosení</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>Délka 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>Délka 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>Nastavení bloku</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>Název bloku:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>Přejmenování bloku</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>Nelze pojmenovat blok. Blok &quot;%1&quot; již existuje.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Add a block</source>
        <translation>Přidat blok</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>Odstranit aktivní blok</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>Přejmenovat aktivní blok</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>Upravit aktivní blok
v jiném okně</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>Vložit aktivní blok</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>Menu bloky</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>&amp;Zobrazit všechny bloky</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>&amp;Skrýt všechny bloky</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>Při&amp;dat blok</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>V&amp;yjmout blok</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>&amp;Editovat blok</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Přepnout viditelnost</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>Ukázat všechny bloky</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>Skrýt všechny bloky</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>Pře&amp;jmenovat blok</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>&amp;Vložit blok</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>&amp;Vytvořit nový blok</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>Nástroje CADu</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>Oblouky</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>Oblouk zadaný 3 body</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>Oblouk zadaný Středem, Bodem, Úhly</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Soustředný</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation>Kružnice</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>Kružnice zadaná dvěma protilehlými body</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>Kružnice zadaná středem a poloměrem</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>Kružnice zadaná středem a bodem</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>Kružnice zadaná třemi body</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Soustředná</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>Kóty</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Kóta průměru</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Kóta poloměru</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Svislá kóta</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Vodorovná kóta</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Přímá kóta</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Zarovnaná kóta</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Úhlová kóta</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Odkaz</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>Elipsy</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>Elipsovitý oblouk zadaný středem, dvěma body a úhly</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>Elipsa zadaná Středem a dvěma body</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>Vzdálenost (Bod, Bod)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>Vzdálenost (prvek, bod)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Úhel</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Celková délka vybraných prvků</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>Úsečky</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>Čáry od ruky</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>Kolmé úsečky</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>Osy</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>Tečna od kružnice ke kružnici</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>Tečna z bodu ke kružnici</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>Úsečka zadaná dvěma body</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>Úsečky zadané relativním úhlem</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>Úsečka pod daným úhlem</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>Vodorovné úsečky</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>Svislé úsečky</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>Obdélníky</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>Mnohoúhelníky zadané středem a rohem</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>Mnohoúhelníky zadané dvěma rohy</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>Rovnoběžky s danou vzdáleností</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>Rovnoběžky skrz bod</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>Hlavní</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>Zobrazit menu &quot;Úsečky&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>Zobrazit menu &quot;Oblouky&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>Zobrazit menu &quot;Kružnice&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Points&quot;</source>
        <translation type="obsolete">Zobrazit menu &quot;Body&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>Zobrazit menu &quot;Měření&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>Zobrazit menu &quot;Elipsy&quot;</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>Šrafy / Výplně ploch</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>Zobrazit menu &quot;Úpravy&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>Zobrazit menu &quot;Kóty&quot;</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>Texty</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>Zobrazit menu &quot;Výběr&quot;</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Vytvoř Blok</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>Rastrový obrázek</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="unfinished">Body</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>Upravit</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Otočení</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Měřítko</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Posun</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Posun a otočení</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation>Rozložit</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Natáhnout</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Ořezat</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Zaoblit</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Úkos</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>Zkrátit o kolik</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>Zkrátit / Prodloužit oba dva</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>Zkrátit / Prodloužit</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>Otočit okolo dvou středů</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>Upravit vlastnosti prvku</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>Upravit geometrii prvku</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Zrcadlení</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Dělení</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>Rozložit text na písmena</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Upravit text</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>Body</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>Jednotlivé body</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished">Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append node</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>Vyber</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Vybrat Vše</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>Vyber protínající se prvky</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>Zrušit výběr protínajících se prvků</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Odznačit Vše</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>Inverzní výběr</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>Označit hladinu</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>O(d)značit obrys</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>O(d)značit prvek</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Odznačit oknem</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Výběr oknem</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>Pokračuj</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>Uchop</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>Uchopení do mřížky</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Volné umístění</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>Uchopení za koncové body</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>Uchopení za nejbližší bod na prvku</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>Uchopení za středy</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Uchopení za body v polovině prvku</translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>Uchopení za body s danou vzdáleností od koncového bodu</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>Uchopení za průsečíky automaticky</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>Bez omezení</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>Pouze kolmo</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>Pouze vodorovně</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>Pouze svisle</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>Posunout relativní počátek</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>Zamknout relativní počátek</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>Uchopení za průsečíky ručně</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation type="unfinished">Zpět do hlavního menu</translation>
    </message>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>Kružnice: Vlastnosti</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Poloměr:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>Dle hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Dle bloku</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Žlutá</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Azurová</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Fialová</translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>Černá / Bílá</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Šedá</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Světle šedá</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>Jiné..</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Beze změny</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>Příkazový řádek</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Příkaz:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>Souřadnice</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>Vlastnosti přímé kóty</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>Vlastnosti kóty</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Značka:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>Editor popisku kóty</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>Popisek kóty:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Značka:</translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>Vložit:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (Stupeň)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>x (Krát)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (Děleno)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>Oblouk</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Poloměr:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Střed (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Střed (x):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Počáteční úhel:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Koncový úhel:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Opačně</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>Kružnice</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Poloměr:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Střed (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Střed (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>Přímá kóta</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Zarovnaná kóta</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>Elipsa</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Střed (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Střed (x):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Koncový úhel:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Počáteční úhel:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>Natočení:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>Vedlejší:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>Hlavní:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Opačně</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>Vyber vlastnosti šrafů</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>Paternovat</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Měřítko:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>Výplň plochy</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>Povolit náhled</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>Vítejte</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Vítejte v QCADu&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Vyberte prosím jednotky, které si přejete použít pro nový výkres a Váš oblíbený jazyk.&lt;br&gt;
Toto nastavení můžete později změnit v menu Nastavení QCADu.</translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>Výchozí jednotky:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>Jazyk:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>Jazyk pro příkazy:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>Bod vložení (x):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>Bod vložení (y):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Měřítko:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Řádky:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Sloupce:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>Vzdálenost mezi řádky:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>Vzdálenost mezi sloupci:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>Úsečka</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>Koncový bod (x):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>Koncový bod (y):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>Počáteční bod (y):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>Počáteční bod (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>Vlastnosti zrcadlení</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální &amp;vlastnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>Vlastnosti posunu</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Ví&amp;cenásobné kopie</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální &amp;vlastnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>Vlastnosti Posunu/Otočení</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Úhel (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální &amp;vlastnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Ví&amp;cenásobné kopie</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Main Unit</source>
        <translation>Hlavní jednotky</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Délka</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Desítkový</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>Vědecký</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>Strojařský</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>Stavařský</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>Zlomkový</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Úhel</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>Desetinné stupně</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>Radiány</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>přímý</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>úhlový</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>Formát papíru</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>Výška textu:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>jednotky</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>Stupně/minuty/vteřiny</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation>Grady</translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation>Kontrolní jednotky</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>Pro formát délkových měr &apos;Stojařský a Stavařský&apos;, musí být jednotky nastaveny na palcovou míru.</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>Prodloužení prodlužované čáry:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>Velikost šipek:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>Vzdálenost prodlužované čáry:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>Odsazení kótovací čáry:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>Nastavení výkresu</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>&amp;Papír</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>Vo&amp;dorovně</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>Sv&amp;isle</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>&amp;Výška papíru:</translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>&amp;Šířka papíru:</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>&amp;Jednotky</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>&amp;Hlavní jednotky výkresu:</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>&amp;Formát:</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>P&amp;řesnost:</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>F&amp;ormát:</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>Pře&amp;snost:</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>&amp;Kóty</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Mřížka</translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>Nastavení mřížky</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>Zobrazit mřížku</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>Vzdálenost X:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Vzdálenost Y:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>Mří&amp;žka</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished">8</translation>
    </message>
    <message>
        <source>16</source>
        <translation type="unfinished">16</translation>
    </message>
    <message>
        <source>32</source>
        <translation type="unfinished">32</translation>
    </message>
    <message>
        <source>64</source>
        <translation type="unfinished">64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation type="unfinished">0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation type="unfinished">0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="unfinished">10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Překlady:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>Šrafovací vzory:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>Písma:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>Skripty:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>Knihovny součástí:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <source>Please restart QCad to apply all changes.</source>
        <translation type="obsolete">Restartujte prosím QCAD aby se projevily všechny změny.</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>Naztavení programu</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>Výchozí hodnoty pro nové výkresy</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>&amp;Vzhled</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>&amp;Jazyk:</translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>Jazyk pro &amp;příkazy:</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>&amp;Ukaž velký nitkový kříž</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>Počet prvků v n&amp;áhledu:</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>&amp;Cesty</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>Výcho&amp;zí</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>&amp;Jednotka:</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Barvy</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>Poza&amp;dí:</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>Barva M&amp;řížky:</translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>&amp;Barva pomocné mřížky:</translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="obsolete">Černá</translation>
    </message>
    <message>
        <source>White</source>
        <translation type="obsolete">Bílá</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation type="obsolete">Šedá</translation>
    </message>
    <message>
        <source>Darkgray</source>
        <translation type="obsolete">Tmavě šedá</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation>#404040</translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>Velikost písma</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>Stavový řádek:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation>#000000</translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation>#ffffff</translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation>#c0c0c0</translation>
    </message>
    <message>
        <source>#808080</source>
        <translation>#808080</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>Zvo&amp;lená barva:</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation>#a54747</translation>
    </message>
    <message>
        <source>#739373</source>
        <translation>#739373</translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>Zv&amp;ýrazněná barva:</translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>Au&amp;tomatické měřítko mřížky</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing:</source>
        <translation type="obsolete">Minimální rastr mřížky:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>Restartujte prosím program aby se projevily všechny změny.</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation>Alt+S</translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>Bod</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>Pozice (y):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>Pozice (x):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>Vlastnosti otočení</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>Ví&amp;cenásobné kopie:</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Úhel (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální vl&amp;astnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>Vlastnosti pro otočení okolo dvou</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Ví&amp;cenásobné kopie</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>Úhel (&amp;a):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>Úhel (&amp;b):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální vl&amp;astnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>Vlastnosti změny měřítka</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Počet zkopírovaných objektů</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>&amp;Měřítko (m):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Použij aktuální vl&amp;astnosti</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Použij aktuální &amp;hladinu</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Vymazat původní objekt</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Ponechej původní objekt</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>Ví&amp;cenásobné kopie</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation type="unfinished">Hladina:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation type="unfinished">Geometrie</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="unfinished">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished">Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>Smazat text</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>Načíst text ze souboru</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>Uložit text do souboru</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Vyjmout</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Písmo</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Zarovnání</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>Vpravo nahoru</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>Vlevo nahoru</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>Vlevo uprostřed</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>Vprostřed</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>Vpravo uprostřed</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>Vlevo dole</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>Vpravo dole</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>Dole uprostřed</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>Nahoře uprostřed</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Úhel</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>Vlož symbol</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>Stupeň (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation></translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation></translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>Mřížka (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dolar ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (®)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>Paragraf (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (¥)</source>
        <translation></translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>Krát (x)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation></translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>Vložit Unicode</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>Strana:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>Znak:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation>[0000-007F] Základní Latin</translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation>[0080-00FF] Latin-1 Dodatek</translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation>[0100-017F] Latin Rozšíření-A</translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation>[0180-024F] Latin Rozšíření-B</translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation>[0250-02AF] IPA Rozšíření</translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation>[02B0-02FF] Znaky nahrazující mezery</translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation>[0300-036F] Kombinované diakritické znaky</translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation>[0370-03FF] Řečtina a Koptština</translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation>[0400-04FF] Cyrilice</translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation>[0500-052F] Cyrilice Dodatek</translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation>[0530-058F] Arménština</translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation>[0590-05FF] Hebrejština</translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation>[0600-06FF] Arabština</translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation>[0700-074F] Syrština</translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation></translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation></translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation>[0980-09FF] Bengálština</translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation></translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation></translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation></translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation>[0B80-0BFF] Tamilština</translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation></translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation></translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation></translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation></translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation>[0E00-0E7F] Thajština</translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation>[0E80-0EFF] Laoština</translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation>[0F00-0FFF] Tibetština</translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation></translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation></translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation></translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation>[1200-137F] Etiopština</translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation></translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation></translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation></translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation></translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation></translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation></translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation></translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation></translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation></translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation>[1800-18AF] Mongolština</translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation></translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation>[1F00-1FFF] Rozšířená Řečtina</translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation>[2000-206F] Základní interpunkce</translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation>[2070-209F] Horní a dolní indexy</translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation>[20A0-20CF] Symboly měn</translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation>[20D0-20FF] Kombinované znaky pro symboly</translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation>[2100-214F] Písmenné znaky</translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation>[2150-218F] Zlomky</translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation>[2190-21FF] Šipky</translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation>[2200-22FF] Matematické operátory</translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation>[2300-23FF] Rúzné technické</translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation>[2400-243F] Kontrolní obrazce</translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation>[2440-245F] Optické rozpoznávání znaků</translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation>[2460-24FF] Uzavřené alfanumerické</translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation>[2500-257F] Obdélníková kresba</translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation>[2580-259F] Blokové prvky</translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation>[25A0-25FF] Geometrické tvary</translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation>[2600-26FF] Různé symboly</translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation></translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation>[27C0-27EF] Různé matematické znaky - A</translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation>[27F0-27FF] Podporované šipky - A</translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation>[2800-28FF] Braillovy znaky</translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation>[2900-297F] Podpůrné šipky - B</translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation>[2980-29FF] Různé matematické znaky - B</translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation>[2A00-2AFF] Podporované matematické operátory</translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation></translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation></translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation>[2FF0-2FFF] Popisy ideografických znaků</translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation>[3000-303F] CJK symboly a interpunkce</translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation>[3040-309F] Hiragana</translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation>[30A0-30FF] Katakana</translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation></translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation></translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation></translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation></translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation>[3200-32FF] Přiložené CJK dny a měsíce</translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation>[3300-33FF] CJK kompatibilita</translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation>[3400-4DBF] CJK Unifikované ideografické rozšíření A</translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation>[4E00-9FAF] CJK Unifikované ideografy</translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation>[A000-A48F] Yi slabiky</translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation>[A490-A4CF] Yi základ</translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation>[AC00-D7AF] Hangul slabiky</translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation></translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation></translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation>[E000-F8FF] Uživatelská oblast</translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation>[F900-FAFF] CJK Kompatibilní ideografy</translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation>[FB00-FB4F] Abecední podací formulář</translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation>[FB50-FDFF] Arabský podací formulář-A</translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation>[FE00-FE0F] Přepínač voleb</translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation>[FE20-FE2F] Kombinované poloviční znaky</translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation>[FE30-FE4F] CJK podací formulář</translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation>[FE70-FEFF] Arabský podací formulář-B</translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation>[FFF0-FFFF] Speciály</translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation></translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation></translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation></translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation>[1D000-1D0FF] Byzantske hudební znaky</translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation>[1D100-1D1FF] Hudební znaky</translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation>[1D400-1D7FF] Matematické alfanumerické znaky</translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation>[20000-2A6DF] CJK Unifikované ideografické rozšíření B</translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation>[2F800-2FA1F] CJK Kompatibilní ideografy - Dodatek</translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation>[E0000-E007F] Značky</translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation>[F0000-FFFFD] Dodatečná uživatelská oblast-A</translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation>[100000-10FFFD] Dodatečná uživatelská oblast-B</translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>&amp;Výška:</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>Řá&amp;dkování:</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>&amp;Výchozí řádkování</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="obsolete">Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation>Alt+D</translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Uložit</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>Uložit &amp;jako..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>Nepodporovaný text.</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation>QCad</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="obsolete">Esc</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Z&amp;avřít</translation>
    </message>
    <message>
        <source>Alt+L</source>
        <translation type="obsolete">Alt+A</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Vlastnosti vkládání</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Úhel otočení</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Dělitel:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Měřítko</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>Vlastnosti vkládání obrázků</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>Velikost bitmapy</translation>
    </message>
    <message>
        <source>640</source>
        <translation>640</translation>
    </message>
    <message>
        <source>480</source>
        <translation>480</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Šířka:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Výška:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Bílá</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Černá</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Rozlišení:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>25</source>
        <translation>25</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>75</source>
        <translation>75</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Vlastnosti vkládání</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Úhel otočení</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Dělitel:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Měřítko</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>Pole:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>Počet sloupců</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>Počet řádků</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>Vzdálenost:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>Vzdálenost mezi sloupci</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>Vzdálenost mezi řádky</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>-Beze změny-</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>Nastavení hladin</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>Název hladiny:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>Výchozí pero</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Show all layers</source>
        <translation>Zobrazit všechny hladiny</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>Skrýt všechny hladiny</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>Přidat hladinu</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>Odstranit aktuální hladinu</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>Upravit vlastnosti hladiny / přejmenovat</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>Menu Hladiny</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>&amp;Zobrazit všechny hladiny</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>&amp;Skrýt všechny hladiny</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>Přida&amp;t hladinu</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>&amp;Odstranit hladinu</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>&amp;Editovat hladinu</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Přepnout viditelnost</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>Vlastnosti vkládání knihoven</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Úhel otočení</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Dělitel:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Měřítko</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>Prohlížeč knihoven součástí</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Adresáře</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Vložit</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>Vlastnosti úsečky pod úhlem</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Úhel úsečky</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Délka:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Délka úsečky</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>Uchopovací bod:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Střed</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Konec</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>Vlastnosti osy úhlu</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Délka:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>Délka osy úhlu</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>Počet os úhlu k vytvoření</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>Vlastnosti úsečky</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Uzavřít</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Zpět</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>Vlastnosti rovnoběžky</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Vzdálenost:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>Vzdálenost od původního prvku</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Počet rovnoběžek k vytvoření</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>Vlastnosti rovnoběžných přímek</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Počet rovnoběžek k vytvoření</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>Vlastnosti mnohoúhelníku</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Počet stran</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>Vlastnosti mnohoúhelníku</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Počet:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Počet stran</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>Vlastnosti úsečky pod relativním úhlem</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Úhel úsečky</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Délka:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Délka úsečky</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>Dle hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Dle bloku</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>Bez pera</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>Kontinuální</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>Tečka</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>Tečka (malá)</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>Tečka (velká)</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>Čárka</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>Čárka (malá)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>Čárka (dlouhá)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>Čerchovaná</translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>Čerchovaná (malá)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>Čerchovaná (velká)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Dělená</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>Dělená (malá)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>Dělená (velká)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Střed</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>Střed (malý)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>Střed (velký)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Obrys</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>Obrys (malý)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>Obrys (velký)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Beze změny-</translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>Myš</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Pravé</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Levé</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>Vlastnosti Posunu a Otočení</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
</context>
<context>
    <name>QG_PolylineOptions</name>
    <message>
        <source>Polyline Options</source>
        <translation type="obsolete">Lomená čára</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Uzavřít</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Zpět</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation type="obsolete">Oblouk</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="obsolete">Poloměr:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation>Vlastnosti náhledu před tiskem</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation>Přepnout čeno-bílý mód</translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation>Vystředit na stránku</translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation>Roztáhnout na celou stránku</translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>Vlastnosti zaoblení</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Zkrátit</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>Zkusí zkrátit oba prvky a vytvoří zaoblení</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Poloměr:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>Výběr</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>Vybrané prvky:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>Zachytávací vzdálenost</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Vzdálenost:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished">Zpět</translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>Vlastnosti textu</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Úhel:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>Vlastnosti vícenásobného zkracování</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>Vzdálenost. Záporné hodnoty pro zkrácení, kladné hodnoty pro prodloužení.</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Množství:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>Pero</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>Typ čáry:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Šířka:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Barva:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>Dle hladiny</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Dle bloku</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation>0.00mm</translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation>0.05mm</translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation>0.09mm</translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation>0.13mm (ISO)</translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation>0.15mm</translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation>0.18 (ISO)</translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation>0.20mm</translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation>0.25mm (ISO)</translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation>0.30mm</translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation>0.35mm (ISO)</translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation>0.40mm</translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation>0.50mm (ISO)</translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation>0.53mm</translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation>0.60mm</translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation>0.70mm (ISO)</translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation>0.80mm</translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation>0.90mm</translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation>1.00mm (ISO)</translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation>1.06mm</translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation>1.20mm</translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation>1.40mm (ISO)</translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation>1.58mm</translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation>2.00mm (ISO)</translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation>2.11mm</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Beze změny-</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Upozornění</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>Odeber hladinu</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>Hladina &quot;%1&quot; a všechny prvky v ní budou vymazány.</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>Hladina &quot;%1&quot; nemůže být nikdy vymazána.</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>Hladiny</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>Vyjmi blok</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>Blok &quot;%1&quot; a všechny jeho prvky budou odstraněny.</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>Vlastnosti Hladiny</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>Hladina pojmenovaná &quot;%1&quot; již existuje. Zadejte prosím jiný název.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Uložit výkres jako</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 již existuje.
Přejete si ho přepsat?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>Otevřít výkres</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Otevřít obrázek</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation>Bitmapa</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation>Multiple-image Network Graphics</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation>Portabe Grey Map</translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation>Portable Network Graphic</translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation>Portable Pixel Map</translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation>X Bitmap Format</translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation>X Pixel Map</translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>Všechny soubory s obrázky (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation>Výkres %1</translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation>Soubor QCad 1.x %1</translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>Písmo %1</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Všechny soubory (*.*)</translation>
    </message>
</context>
</TS>
