<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Νέο</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="obsolete">&amp;Άνοιγμα...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="obsolete">Α&amp;ποθήκευση</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="obsolete">Αποθήκευση &amp;ως...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Κλείσιμο</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Εκτύπωση</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Εξοδος</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">Ε&amp;ξοδος</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>Εξοδος απ&apos;την εφαρμογή</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="obsolete">Μεγέθυνση</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="obsolete">Μεγέ&amp;θυνση</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="obsolete">Μεγεθύνει το σχέδιο</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="obsolete">Σμίκρυνση</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="obsolete">Σ&amp;μίκρυνση</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="obsolete">Σμικρύνει το σχέδιο</translation>
    </message>
    <message>
        <source>Auto Zoom</source>
        <translation type="obsolete">Αυτόματη εστίαση</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="obsolete">Α&amp;υτόματη εστίαση</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="obsolete">Εστιάζει αυτόματα σε όλο το σχέδιο</translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation type="obsolete">Παράθυρο εστίασης</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="obsolete">&amp;Παράθυρο εστίασης</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="obsolete">Εστιάζει σε παράθυρο</translation>
    </message>
    <message>
        <source>Pan Zoom</source>
        <translation type="obsolete">Μετακίνηση εστίασης </translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="obsolete">&amp;Μετακίνηση εστίασης </translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="obsolete">Μετακίνηση σε πραγματικό χρόνο</translation>
    </message>
    <message>
        <source>Redraw</source>
        <translation type="obsolete">Επανασχεδίαση</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="obsolete">&amp;Επανασχεδίαση</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Αναίρεση</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">Α&amp;ναίρεση</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="obsolete">Αναιρεί την τελευταία πράξη</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Επαναφορά</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Επαναφορά</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="obsolete">Επαναφέρει την τελευταία αναίρεση</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Αποκοπή</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">Απ&amp;οκοπή</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Αντιγραφή</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">Α&amp;ντιγραφή</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Επικόληση</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">Επι&amp;κόληση</translation>
    </message>
    <message>
        <source>Select Entity</source>
        <translation type="obsolete">Επιλογή Στοιχείου</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="obsolete">Επιλέγει μονά Στοιχεία</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation type="obsolete">Παράθυρο επιλογής</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="obsolete">Παρά&amp;θυρο επιλογής</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="obsolete">Επιλέγει όλα τα στοιχεία σε καθορισμένο παράθυρο</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="obsolete">Παράθυρο Αποεπιλογής</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="obsolete">Παράθυ&amp;ρο Αποεπιλογής</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="obsolete">Αποεπιλέγει όλα τα στοιχεία σε καθορισμένο παράθυρο</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">(Απο-)Επιλογή Περιγράμματος</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">(Απο-)Επιλέγει συνδεδεμένα στοιχεία</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="obsolete">Επιλογή όλων</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="obsolete">Επι&amp;λογή όλων</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="obsolete">Επιλέγει όλα τα στοιχεία</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Αποεπιλογή όλων</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="obsolete">Αποεπι&amp;λογή όλων</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="obsolete">Αποεπιλέγει όλα τα στοιχεία</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="obsolete">Αντιστροφή επιλογής</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="obsolete">Αντιστρο&amp;φή επιλογής</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="obsolete">Αντιστρέφει την τρέχουσα επιλογή</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="obsolete">Επιλογή διασταυρούμενων Στοιχείων</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="obsolete">Δια&amp;σταυρούμενα Στοιχεία</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="obsolete">Επιλέγει όλα τα στοιχεία διασταυρούμενα με γραμμή</translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="obsolete">Αποεπιλογή διασταυρούμενων Στοιχείων</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="obsolete">Αποεπι&amp;λογή διασταυρούμενων Στοιχείων</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="obsolete">Αποεπιλέγει όλα τα στοιχεία διασταυρούμενα με γραμμή</translation>
    </message>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="obsolete">(Απο-)Επιλογή στρώματος</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="obsolete">(Απο-)Επιλέγει στρώματα</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Σημεία</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="obsolete">&amp;Σημεία</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="obsolete">Σχεδίαση σημείων</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation type="obsolete">Γραμμή: 2 Σημεία</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="obsolete">&amp;2 Σημεία</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="obsolete">Σχεδίαση γραμμών</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Γραμμή: Γωνία</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Γωνία</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Σχεδίαση γραμμών με καθορισμένη γωνία</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Γραμμή: Οριζόντια</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Οριζόντια</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Σχεδίαση οριζόντιων γραμμών</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="obsolete">Οριζ./Καθ. γραμμή</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="obsolete">Ο&amp;ριζόντια / Κάθετα</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="obsolete">Σχεδιάζει οριζόντιες/κάθετες γραμμές</translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Γραμμή: Κάθετα</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Κάθετα</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Σχεδίαση κάθετων γραμμών</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation type="obsolete">Γραμμή: Χειροποίητα</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="obsolete">&amp;Χειροποίητη Γραμμή</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="obsolete">Σχεδίαση χειροποίητων γραμμών</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Παράλληλα</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="obsolete">Πα&amp;ράλληλα</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Ορθογώνιο</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="obsolete">Ορ&amp;θογώνιο</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="obsolete">Σχεδίαση ορθογώνιων</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation type="obsolete">Διχοτόμος</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="obsolete">&amp;Διχοτόμος</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="obsolete">Σχεδίαση διχοτόμων</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="obsolete">Εφαπτομένη (Σ,Κ)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="obsolete">Ε&amp;φαπτομένη (Σ,Κ)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="obsolete">Σχεδίαση εφαπτομένης (σημείο,κύκλος)</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="obsolete">Εφαπτομένη (Κ,Κ)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="obsolete">&amp;Εφαπτομένη (Κ,Κ)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="obsolete">Σχεδίαση εφαπτομένης (κύκλος,κύκλος)</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Ορθογώνια</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">&amp;Ορθογώνια</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Σχεδίαση ορθογώνιας γραμμής</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation type="obsolete">Σχετική γωνία</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="obsolete">&amp;Σχετική γωνία</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="obsolete">Σχεδίαση γραμμών με σχετική γωνία</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="obsolete">Πολύγωνα</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="obsolete">Π&amp;ολύγωνα (Κεντ,Γων)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="obsolete">Σχεδίαση πολυγώνων με κέντρο και γωνία</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cor,Cor)</source>
        <translation type="obsolete">Πο&amp;λύγωνα (Γων,Γων)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="obsolete">Σχεδίαση πολυγώνων με δύο γωνίες</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="obsolete">Κύκλος: Κέντρο, Σημείο</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="obsolete">&amp;Κέντρο, Σημείο</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="obsolete">Σχεδίαση κύκλων με κέντρο και σημείο</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="obsolete">Κύκλος: Κέντρο, Ακτίνα</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="obsolete">Κ&amp;έντρο, Ακτίνα</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="obsolete">Σχεδίαση κύκλων με κέντρο και ακτίνα</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="obsolete">Κύκλος: 2 Σημεία</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="obsolete">2 Σημεία</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="obsolete">Σχεδίαση κύκλων με 2 σημεία</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Κύκλος: 3 Σημεία</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 Σημεία</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Σχεδίαση κύκλων με 3 σημεία</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="obsolete">Τόξο: Κέντρο, Σημείο, Γωνίες</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="obsolete">&amp;Κέντρο, Σημείο, Γωνίες</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="obsolete">Σχεδίαση τόξων</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="obsolete">Τόξο: 3 Σημεία</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="obsolete">&amp;3 Σημεία</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="obsolete">Σχεδίαση τόξων με 3 σημεία</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="obsolete">Ελειψη με Άξονα</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="obsolete">Ε&amp;λειψη (Άξονας)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="obsolete">Σχεδίαση Ελείψεων</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="obsolete">Ελειπτικό Τόξο με Άξονα</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="obsolete">Ελει&amp;πτικό Τόξο (Άξονας)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="obsolete">Σχεδίαση Ελειπτικών Τόξων</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Κείμενο</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="obsolete">&amp;Κείμενο</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="obsolete">Σχεδίαση Στοιχείων Κειμένου</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="obsolete">Σχεδίαση Διαγραμίσεων και Γεμισμάτων</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation type="obsolete">Στοιχισμένη</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="obsolete">&amp;Στοιχισμένη</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Στοιχισμένη Διάσταση</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="obsolete">Γραμμική</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="obsolete">&amp;Γραμμική</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="obsolete">Γραμμική Διάσταση</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="obsolete">Οριζόντια</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="obsolete">Οριζόντια Διάσταση</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="obsolete">Κάθετα</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="obsolete">Κάθετη Διάσταση</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation type="obsolete">Ακτινωτή</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="obsolete">&amp;Ακτίνα</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="obsolete">Διάσταση Ακτίνας</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation type="obsolete">Διάμετρος</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="obsolete">&amp;Διάμετρος</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="obsolete">Διάμετρος</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation type="obsolete">Γωνία</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="obsolete">&amp;Γωνία</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="obsolete">Διάσταση Γωνίας</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation type="obsolete">Δείκτης</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="obsolete">&amp;Δείκτης</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="obsolete">Δείκτης</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Διαγραφή</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;Διαγραφή</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="obsolete">Διαγραφή Στοιχείων</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation type="obsolete">Διαγραφή Χειροποίητων</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="obsolete">Διαγραφή &amp;Χειροποίητων</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Μετακίνηση</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Μετακίνηση</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Μετακίνηση στοιχείων</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation type="obsolete">Περιστροφή</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="obsolete">&amp;Περιστροφή</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="obsolete">Περιστροφή Στοιχείων</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="obsolete">Κλίμακα</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="obsolete">&amp;Κλίμακα</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="obsolete">Αλλαγή Μεγέθους</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Αντιστροφή</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">Α&amp;ντιστροφή</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Αντιστροφή στοιχείων</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation type="obsolete">Μετακίνηση και Περιστροφή</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="obsolete">Με&amp;τακίνηση και Περιστροφή</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="obsolete">Μετακίνηση και Περιστροφή στοιχείων</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation type="obsolete">Περιστροφή Δύο</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="obsolete">Περιστροφή &amp;Δύο</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="obsolete">Περιστροφή στοιχείων περι δυο κέντρων</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Διευθέτηση</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">Διευ&amp;θέτηση</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Διευθέτηση Στοιχείων</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Διευθέτηση Δύο</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">&amp;Διευθέτηση Δύο</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Διευθέτηση δυο στοιχείων</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Επιμήκυνση</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">&amp;Επιμήκυνση</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Επιμηκύνει με καθορισμένη τιμή</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">&amp;Αποκοπή</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Αποκοπή Στοιχείων</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation type="obsolete">Επέκταση</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="obsolete">&amp;Επέκταση</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="obsolete">Επέκταση στοιχείων</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation type="obsolete">Λοξή Γωνία</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="obsolete">Λοξή &amp;Γωνία</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="obsolete">Στοιχεία λοξής γωνίας</translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="obsolete">Κυκλικό</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="obsolete">Κ&amp;υκλικό</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="obsolete">Στοιχεία κυκλικής γωνίας</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>Ελεύθερα</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>&amp;Ελεύθερα</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Ελεύθερη τοποθέτηση</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Καμβάς</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Καμβάς</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>Τοποθέτηση στον καμβά</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>Άκρα</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>Άκ&amp;ρα</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>Προσκόλληση στα άκρα</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>Πάνω στα στοιχεία</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>&amp;Πάνω στα στοιχεία</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>Προσκόλληση στο κοντινότερο σημείο του στοιχείου</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Κέντρο</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>Κέ&amp;ντρο</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>Προσκόλληση σε κέντρα</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Μέση</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>&amp;Μέση</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Προσκόλληση στη μέση</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>Απόσταση απο το άκρο</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>&amp;Απόσταση απο το άκρο</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>Προσκόλληση σε σημείο με καθορισμένη απόσταση από την άκρη</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>Διασταύρωση</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>&amp;Διασταύρωση</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>Προσκόλληση σε διασταυρώσεις</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation type="obsolete">Διασταυρώσεις χειροκίνητα</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="obsolete">Δ&amp;ιασταυρώσεις χειροκίνητα</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="obsolete">Έλξη σε διασταυρώσεις χειροκίνητα</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>Χωρίς περιορισμό</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>&amp;Χωρίς περιορισμό</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>Χωρίς περιορισμό προσκόλλησης</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>Περιορισμός Ορθογώνια</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>Περιορισμός &amp;Ορθογώνια</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>Περιορισμός Προσκόλλησης Ορθογώνια</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>Περιορισμός Οριζόντια</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>Περιορισμός Ορι&amp;ζόντια</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>Περιορισμός Προσκόλλησης Οριζόντια</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>Περιορισμός Κάθετα</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>Περιορισμός &amp;Κάθετα</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>Περιορισμός Προσκόλλησης Κάθετα</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation type="obsolete">Καθορισμός σχετικού σημείου Μηδέν</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="obsolete">&amp;Καθορισμός σχετικού σημείου Μηδέν</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="obsolete">Καθορισμός θέσης του σχετικού σημείου μηδέν</translation>
    </message>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="obsolete">(Απ-)Ασφάλιση σχετικού σημείου Μηδέν</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="obsolete">(Απ-)&amp;Ασφάλιση σχετικού σημείου Μηδέν</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="obsolete">(Απ-)Ασφάλιση σχετικού σημείου Μηδέν</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation type="obsolete">Σημείο εντος περιγράμματος</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="obsolete">&amp;Σημείο εντός περιγράμματος</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="obsolete">Ελέγχει αν ένα σημείο είναι εντός του επιλεγμένου περιγράμματος</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Εμφάνιση όλων</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">&amp;Εμφάνιση όλων</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Εμφάνιση όλων των Στρωμάτων</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Απόκρυψη όλων</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">&amp;Απόκρυψη όλων</translation>
    </message>
    <message>
        <source>Add Layer</source>
        <translation type="obsolete">Πρόσθεση Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="obsolete">&amp;Πρόσθεση Στρώματος</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation type="obsolete">Αφαίρεση Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="obsolete">Αφαίρεση &amp;Στρώματος</translation>
    </message>
    <message>
        <source>Edit Layer</source>
        <translation type="obsolete">Διόρθωση Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="obsolete">Διόρ&amp;θωση Στρώματος</translation>
    </message>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="obsolete">Εναλλαγή ορατότητας στρωμάτων</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="obsolete">Ενα&amp;λλαγή στρωμάτων</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="obsolete">Εναλλαγή στρωμάτων</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Εμφάνιση όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Απόκρυψη όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Πρόσθεση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">&amp;Προσθεση Μπλόκ</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Αφαίρεση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">&amp;Αφαίρεση Μπλόκ</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Μετονομασία Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">&amp;Μετονομασία Μπλόκ</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Μετονομασία Μπλόκ και όλων των εισαγωγών</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Διόρθωση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">&amp;Διόρθωση Μπλόκ</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Εισαγωγή Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">&amp;Εισαγωγή Μπλόκ</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Εναλλαγή ορατότητας Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">Ενα&amp;λλαγή Μπλόκ</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Εναλλαγή Μπλόκ</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation type="obsolete">Δημιουργία Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">Δ&amp;ημιουργία Μπλόκ</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Διαχωρισμός</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">&amp;Διαχωρισμός</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Διαχωρισμός Μπλόκ και άλλων Ομάδων Στοιχείων</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>Γενικές Προτιμήσεις Εφαρμογής</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="obsolete">Σχέδιο</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="obsolete">Δημιουργεί Νέο Σχέδιο</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="obsolete">Ανοίγει ένα υπάρχον σχέδιο</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="obsolete">Αποθηκεύει το τρέχων σχέδιο</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="obsolete">Αποθηκεύει το τρέχων σχέδιο μέ νέο όνομα</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>Κλείνει το τρέχων σχέδιο</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>Εκτυπώνει το τρέχων σχέδιο</translation>
    </message>
    <message>
        <source>New Drawing</source>
        <translation type="obsolete">Νέο Σχέδιο</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation type="obsolete">Άνοιγμα Σχεδίου</translation>
    </message>
    <message>
        <source>Save Drawing</source>
        <translation type="obsolete">Αποθήκευση Σχεδίου</translation>
    </message>
    <message>
        <source>Save Drawing As</source>
        <translation type="obsolete">Αποθήκευση Σχεδίου Ως</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>Κλείσιμο Σχεδίου</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>Εκτύπωση Σχεδίου</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="obsolete">Αποκοπή στοιχείων στο clipboard</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="obsolete">Αντιγραφή στοιχείων στο clipboard</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="obsolete">Επικόληση των περιεχομένων του clipboard</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="obsolete">(Απο-)&amp;Επιλογή στοιχείου</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">(Απο-)Επι&amp;λογή Περιγράμματος</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="obsolete">Σχεδιάζει παράλληλες σε υπάρχοντα τόξα, κύκλους, γραμμές</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation type="obsolete">Παράλληλα μέσω σημείου</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="obsolete">Παράλληλα &amp;μέσω σημείου</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="obsolete">Σχεδίαση Παράλληλων διαμέσω καθορισμένου σημείου</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="obsolete">Χαρακτηριστικά</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="obsolete">&amp;Χαρακτηριστικά</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="obsolete">Διόρθωση χαρακτηριστικών των στοιχείων</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="obsolete">Διαγραφή επιλεγμένων</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="obsolete">&amp;Διαγραφή επιλεγμένων</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="obsolete">Διαγραφή επιλεγμένων στοιχείων</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">Προεπισκόπηση Εκτύπωσης</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="obsolete">Προεπισκόπηση &amp;Εκτύπωσης</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="obsolete">Εμφάνιση προεπισκόπησης εκτύπωσης</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation type="obsolete">Απόσταση από Σημείο σε Σημείο</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="obsolete">Απόσταση από &amp;Σημείο σε Σημείο</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="obsolete">Μέτρηση απόστασης μεταξύ σημείων</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="obsolete">Απόσταση από Στοιχείο σε Σημείο</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="obsolete">Απόστ&amp;αση από Στοιχείο σε Σημείο</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="obsolete">Μέτρηση απόστασης μεταξύ στοιχείου και σημείου</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation type="obsolete">Γωνία μεταξύ δύο γραμμών</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="obsolete">&amp;Γωνία μεταξύ δύο γραμμών</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="obsolete">Μέτρηση Γωνίας μεταξύ δύο γραμμών</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>Εξαγωγή Σχεδίου</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Εξαγωγή..</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>Εξάγει το τρέχων σχέδιο σαν εικόνα</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Ιδιότητες</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="obsolete">Διόρθωση Ιδιοτήτων των στοιχείων</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="obsolete">&amp;Ιδιότητες</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>Εφαρμογή</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>&amp;Προτιμήσεις Εφαρμογής</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="obsolete">Προτιμήσεις &amp;Τρέχοντος Σχεδίου</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="obsolete">Ρυθμίσεις γιά το τρέχων Σχέδιο</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>Εμφάνιση/απόκρυψη καμβά</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Κύκλος: Ομόκεντρα</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Ομόκεντρα</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Σχεδίαση κύκλων ομόκεντρα σε υπάρχοντες κύκλους</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Τόξο: Ομόκεντρα</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Σχεδίαση τόξων ομόκεντρα σε υπάρχοντα τόξα</translation>
    </message>
    <message>
        <source>Hatch</source>
        <translation type="obsolete">Διαγράμμηση</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="obsolete">&amp;Διαγράμμηση</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="obsolete">Εικόνα</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="obsolete">&amp;Εικόνα</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="obsolete">Εισαγωγή Εικόνας (Bitmap)</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Πλαίσιο κατάστασης</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>Π&amp;λαίσιο κατάστασης</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>Εμφάνιση/απόκρυψη πλαισίου κατάστασης</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation type="obsolete">Συνολικό μήκος των επιλεγμένων στοιχείων</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="obsolete">&amp;Συνολικό μήκος των επιλεγμένων στοιχείων</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="obsolete">Μετράει το συνολικό μήκος όλων των επιλεγμένων στοιχείων</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Προσχέδιο</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>&amp;Προσχέδιο</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>(Απ)Ενεργοποίηση κατάστασης προσχεδίου</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>Άνοιγμα IDE</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>&amp;Άνοιγμα IDE</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>Ανοίγει το περιβάλλον ανάπτυξης για συγγραφή κώδικα κειμένου</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>Εκτέλεση Script..</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>&amp;Εκτέλεση Script..</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>Εκτελεί ένα script</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>&amp;Προτιμήσεις</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>Ε&amp;ξαγωγή...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>Ε&amp;κτύπωση...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Έξοδος</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>Έ&amp;ξοδος</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>Επιλογές Τόξων</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>Δεξιόστροφα</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>Αριστερόστροφα</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation>Επιλογές Εφαπτομένου Τόξου</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Ακτίνα:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>Επιλογές λοξής γωνίας</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Διευθέτηση</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>Ελεγχος και διευθέτηση και των δύο στοιχείων προς το κυκλικό</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>Μήκος 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>Μήκος 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>Ρυθμίσεις Μπλόκ</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>Όνομα Μπλόκ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>Μετονομασία Μπλόκ</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>Δεν μπορώ να ονομάσω το μπλόκ. Μπλόκ με όνομα &quot;%1&quot; υπάρχει ίδη.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Add a block</source>
        <translation>Πρόσθεση Μπλόκ</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>Αφαίρεση του ενεργού Μπλόκ</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>Μετονομασία του ενεργού Μπλόκ</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>Διόρθωση του ενεργού Μπλόκ
σε ξεχωριστό παράθυρο</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>Εισαγωγή του ενεργού Μπλόκ</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>Μενού Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>&amp;Εμφάνιση όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>&amp;Απόκρυψη όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>&amp;Προσθεση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>&amp;Αφαίρεση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>&amp;Διόρθωση Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>Εναλλαγή &amp;Ορατότητας</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>Εμφάνιση όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>Απόκρυψη όλων των Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>&amp;Μετονομασία Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>&amp;Εισαγωγή Μπλόκ</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>&amp;Δημιουργία Νέου Μπλόκ</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>Εργαλεία CAD</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>Τόξα</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>Τόξο με 3 σημεία</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>Τόξο με Κέντρο, Σημείο, Γωνίες</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Ομόκεντρα</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation>Τόξο εφαπτόμενο στο βασικό στοιχείο με ακτίνα</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation>Κύκλοι</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>Κύκλος με δυο απέναντι σημεία</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>Κύκλος με κέντρο και ακτίνα</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>Κύκλος με κέντρο και σημείο</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>Κύκλος με τρία σημεία</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Ομόκεντρα</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>Διαστάσεις</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Διάμετρος</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Ακτίνα</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Κάθετη Διάσταση</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Οριζόντια Διάσταση</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Γραμμική Διάσταση</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Στοιχισμένη Διάσταση</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Γωνία</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Δείκτης</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>Ελείψεις</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>Ελειπτικό τόξο με κέντρο, δυο σημεία και γωνίες</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>Ελειψη με Κέντρο και δυο σημεία</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>Πληροφορίες</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>Απόσταση (Σημείο, Σημείο)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>Απόσταση (Στοιχείο, Σημείο)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Γωνία</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Συνολικό μήκος των επιλεγμένων στοιχείων</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation>Περιοχή του πολυγώνου</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>Γραμμές</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>Χειροποίητες Γραμμές</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>Ορθογώνιες γραμμές</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>Διχοτόμοι</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>Εφαπτομένη από κύκλο σε κύκλο</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>Εφαπτομένη από σημείο σε κύκλο</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>Γραμμή με δύο σημεία</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>Γραμμές με σχετική γωνία</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>Γραμμές με καθορισμένη γωνία</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>Οριζόντιες γραμμές</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>Κάθετες γραμμές</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>Ορθογώνια</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>Πολύγωνα με Κέντρο και Γωνία</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>Πολύγωνα με δύο Γωνίες</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>Παράλληλα με απόσταση</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>Παράλληλα μέσω σημείου</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>Κεντρικό</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>Εμφάνιση μενού &quot;Γραμμές&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>Εμφάνιση μενού &quot;Τόξα&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>Εμφάνιση μενού &quot;Κύκλοι&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Points&quot;</source>
        <translation type="obsolete">Εμφάνιση μενού &quot;Σημεία&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>Εμφάνιση μενού &quot;Μέτρηση&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>Εμφάνιση μενού &quot;Ελείψεις&quot;</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>Διαγραμίσεις / Γεμίσματα</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>Εμφάνιση μενού &quot;Διόρθωση&quot;</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>Εμφάνιση μενού &quot;Διαστάσεις&quot;</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>Κείμενα</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>Εμφάνιση μενού &quot;Επέλεξε&quot;</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Δημιουργία Μπλόκ</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>Εισαγωγή εικόνας</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Σημεία</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>Καμπύλες</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>Τροποποίηση</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Περιστροφή</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Κλίμακα</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Μετακίνηση</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Μετακίνηση και Περιστροφή</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Διαγραφή</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Επέκταση</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Αποκοπή</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Κυκλικό</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Λοξή Γωνία</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>Διευθέτηση με καθορισμένη τιμή</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>Διευθέτηση / Επιμήκυνση δύο</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>Διευθέτηση / Επιμήκυνση</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>Περιστροφή περι δυο κέντρων</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>Διόρθωση χαρακτηριστικών των στοιχείων</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>Διόρθωση Γεωμετρίας των στοιχείων</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Αντιστροφή</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Διαίρεση</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>Διαχωρισμός Κειμένου σε μονά γράμματα</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Διόρθωση Κειμένου</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>Σημεία</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>Μονά σημεία</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation>Πολυγραμμές</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation>Κατασκευή Πολυγραμμής</translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation>Διαγραφή μεταξύ δυο nodes</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Πρόσθεση node</translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation>Διαγραφή node</translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation>Τακτοποίηση τομέων</translation>
    </message>
    <message>
        <source>Append node</source>
        <translation>Προσάρτηση node</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>Επιλογή</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Επιλογή όλων</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>Επιλογή διασταυρούμενων Στοιχείων</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>Αποεπιλογή διασταυρούμενων Στοιχείων</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Αποεπιλογή όλων</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>Αντιστροφή επιλογής</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>Επιλογή στρώματος</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>(Απο-)Επιλογή περιγράμματος</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>(Απο-)Επιλογή στοιχείου</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Αποεπιλογή Παραθύρου</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Επιλογή Παραθύρου</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>Συνέχεια &quot;δράσης&quot;</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>Προσκόλληση</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>Προσκόλληση στον καμβά</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Ελεύθερη τοποθέτηση</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>Προσκόλληση στις άκρες</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>Προσκόλληση στο κοντινότερο σημείο του στοιχείου</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>Προσκόλληση σε κέντρα</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Προσκόλληση στη μέση</translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>Προσκόλληση σε σημείο με καθορισμένη απόσταση από την άκρη</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>Προσκόλληση σε διασταυρώσεις αυτόματα</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>Χωρίς περιορισμό</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>Περιορισμός Ορθογώνια</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>Περιορισμός Οριζόντια</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>Περιορισμός Κάθετα</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>Μετακίνηση σημείου Μηδέν</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>Ασφάλιση σημείου Μηδέν</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>Προσκόλληση σε διασταυρώσεις χειροκίνητα</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation>Καμπύλες</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Επιστροφή στο κεντρικό μενού</translation>
    </message>
    <message>
        <source>Spline</source>
        <translation>Καμπύλη</translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>Επιλογές Κύκλου</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Ακτίνα:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>Κατά Στρώμα</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Κατά Μπλόκ</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Κόκκινο</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Κίτρινο</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Πράσινο</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Γαλάζιο</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Μπλέ</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation></translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>Μαύρο / Άσπρο</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Γκρί</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Ανοικτό Γκρί</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>Άλλα..</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Αμετάβλητο</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>Γραμμή Εντολών</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Εντολή:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>Συντεταγμένες</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>Επιλογές Γραμμικών Διαστάσεων</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>Επιλογές Διαστάσεων</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Ετικέτα:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation>ø</translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation>°</translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation>±</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation>¶</translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation>×</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation>÷</translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>Διορθωτής Ετικέτας Διάστασης</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>Ετικέτα Διάστασης:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Ετικέτα:</translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>Εισαγωγή:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation>ø (Διάμετρος)</translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (Μοίρες)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation>± (Συν /Πλήν)</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation>¶ (π)</translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>× (Επί)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (Διέρεση)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>Τόξο</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Ακτίνα:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Κέντρο (Υ):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Κέντρο (Χ):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Αρχική Γωνία:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Τελική Γωνία:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Αντιστραμένο</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+Ε</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Χαρακτηριστικά</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>Κύκλος</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Ακτίνα:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Κέντρο (Υ):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Κέντρο (Χ):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>Γραμμική Διάσταση</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Στοιχισμένη Διάσταση</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation>Διάσταση</translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>Έλειψη</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Κέντρο (Υ):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Κέντρο (Χ):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Τελική Γωνία:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Αρχική Γωνία:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>Περιστροφή:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>Ελάχιστο:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>Μέγιστο:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Αντιστρεμένο</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>Επιλογή χαρακτηριστικών διαγραμμίσεων</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>Σχέδιο</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Κλίμακα:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>Συμπαγές Γέμισμα</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Προεπισκόπηση</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>Προεπισκόπηση Ενεργή</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>Καλώς ήλθατε</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Καλώς ήλθατε στο QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Παρακαλώ επιλέξτε τή μονάδα που θέλετε να χρησιμοποιείτε για τα νέα σχέδια και τη γλώσσα που προτιμάτε&lt;br&gt;
Μπορείτε να αλλάξετε αυτές τις παραμέτρους αργότερα απο το διάλογο προτιμήσεων του QCad. </translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>Προεπιλεγμένη μονάδα:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>Γλώσσα GUI:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>Γλώσσα Εντολών:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Εντάξει</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Επικύρωση</translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>Εισαγωγή</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>Σημείο εισαγωγής (Χ):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>Σημείο εισαγωγής (Υ):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Κλίμακα:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Σειρές:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Στήλες:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>Διάκενο Σειρών:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>Διάκενο Στηλών:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>Γραμμή</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>Σημείο Τέλους (Χ):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>Σημείο Τέλους (Υ):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>Σημείο Αρχής (Υ):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>Σημείο Αρχής (Χ):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>Επιλογές Αντιστροφής</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>Επιλογές Μετακίνησης</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Πολαπλά αντίγραφα</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>Επιλογές Μετακίνησης/Περιστροφής</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Γωνία (α):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Πολαπλά αντίγραφα</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Main Unit</source>
        <translation>Βασική Μονάδα</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Μήκος</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Δεκαδικό</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>Επιστημονικό</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>Μηχανολογικό</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>Αρχιτεκτονικό</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>Κλασματικό</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Γωνία</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>Μοίρες</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>Ακτίνια</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Προεπισκόπηση</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>Γραμμικό</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>Γωνιακό</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>Τύπος Σελίδας</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>Ύψος κειμένου:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>μονάδες</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>Μοι/λεπ/δευτ</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation></translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation></translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Επιλογές</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>Γιά τους τρόπους μέτρησης &quot;Μηχανολογικό&quot; και &quot;Αρχιτεκτονικό&quot;, η μονάδα πρέπει να είναι η ίντσα.</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>Επέκταση βοηθητικής γραμμής:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>Μέγεθος βέλους:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>Διάκενο βοηθητικής γραμμής:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>Διάκενο γραμμής διάστασης:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>Προτιμήσεις Σχεδίου</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>&amp;Χαρτί</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>&amp;Οριζόντια</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>&amp;Κάθετα</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>&amp;Υψος Χαρτιού:</translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>&amp;Πλάτος Χαρτιού:</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>&amp;Μονάδες</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>&amp;Βασική μονάδα σχεδίου:</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>&amp;Τύπος:</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>Α&amp;κρίβεια:</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>Τ&amp;ύπος:</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>Α&amp;κρίβεια:</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>&amp;Διαστάσεις</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Καμβάς</translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>Επιλογές Καμβά</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>Εμφάνιση Καμβά</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>Χ Διάκενο:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Υ Διάκενο:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>Αυτόματο</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Καμβάς</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>Καμπύλες</translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation>Αριθμός τομέων γραμμών ανά spline:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>16</source>
        <translation>16</translation>
    </message>
    <message>
        <source>32</source>
        <translation>32</translation>
    </message>
    <message>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation>0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation>0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>Προτιμήσεις</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Μεταφράσεις:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>Σχέδια Διαγραμμίσεων:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>Γραμματοσειρές:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>Scripts:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>Βιβλιοθήκες:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Γλώσσα</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>Γραφική απεικόνιση</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <source>Please restart QCad to apply all changes.</source>
        <translation type="obsolete">Παρακαλώ επανεκκινήστε το QCad για να ισχύσουν οι αλλαγές.</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>Προτιμήσεις Εφαρμογής</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>Προεπιλογές για τα νέα σχέδια</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>&amp;Εμφάνιση</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>&amp;Γλώσσα GUI:</translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>Γλώσσα &amp;Εντολών:</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>&amp;Εμφάνιση μεγάλων σταυρών</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>Αριθμός &amp;προεπισκόπησης στοιχείων:</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>Δ&amp;ιαδρομές</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>&amp;Προεπιλεγμένα</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>&amp;Μονάδα:</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Χρώμματα</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>&amp;Φόντο:</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>Χρώμμα &amp;Καμβά: </translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>&amp;Meta Grid Color:</translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="obsolete">Μαύρο</translation>
    </message>
    <message>
        <source>White</source>
        <translation type="obsolete">Άσπρο</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation type="obsolete">Γκρί</translation>
    </message>
    <message>
        <source>Darkgray</source>
        <translation type="obsolete">Σκούρο Γκρί</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation>#404040</translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>Μέγεθος γραμματοσειράς</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>Πλαίσιο κατάστασης:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>11</source>
        <translation>11</translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation>#000000</translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation>#ffffff</translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation>#c0c0c0</translation>
    </message>
    <message>
        <source>#808080</source>
        <translation>#808080</translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>Α&amp;υτόματη κλίμακα καμβά</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>S&amp;elected Color:</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation>#a54747</translation>
    </message>
    <message>
        <source>#739373</source>
        <translation>#739373</translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>&amp;Highlighted Color:</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing:</source>
        <translation type="obsolete">Ελάχιστο Διάκενο Καμβά:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>Παρακαλώ επανεκκινήστε το πρόγραμμα για να ισχύσουν οι αλλαγές.</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation>Alt+S</translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation>Ελάχιστο Διάκενο Καμβά (px):</translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>Σημείο</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>Θέση (Υ):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>Θέση (Χ):</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>Επιλογές Περιστροφής</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>&amp;Πολαπλά αντίγραφα:</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Γωνία (α):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>Επιλογές Περιστροφής Δύο</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Πολαπλά αντίγραφα</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>&amp;Γωνία (α):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>Γωνία (&amp;β):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>Επιλογές Αλλαγής Μεγέθους</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Αριθμός αντιγράφων</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>&amp;Σχέση (σ):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>&amp;Χρήση υπάρχοντων χαρακτηριστικών</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Χρήση &amp;υπάρχοντος στρώματος</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>&amp;Διαγραφή Προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>&amp;Παραμονή προτότυπου</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Πολαπλά αντίγραφα</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation>Καμπύλη</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Στρώμα:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Γεωμετρία</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>Μοίρες:</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>Κλειστό</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>Κείμενο</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>Καθαρισμός Κειμένου</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>Φόρτωση Κειμένου απο Αρχείο</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>Αποθήκευση Κειμένου σε Αρχείο</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Αποκοπή</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Αντιγραφή</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Επικόληση</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Γραμματοσειρά</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Στοίχιση</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>Επάνω Δεξιά</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>Επάνω Αριστερά</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>Μέση Αριστερά</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>Μέση Κέντρο</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>Μέση Δεξιά</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>Κάτω Αριστερά</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>Κάτω Δεξιά</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>Κάτω Κέντρο</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>Επάνω Κέντρο</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Γωνία</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>Εισαγωγή Συμβόλου</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation>Διάμετρος (ø)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>Μοίρες (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation>Συν /Πλήν (±)</translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation>At (@)</translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>Δίεση (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Δολάριο ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation>Copyright (©)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (Τ)</source>
        <translation>Registered (Τ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>Παράγραφος (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation>π (¶)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation>Στερλίνα (£)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (Τ)</source>
        <translation>Γιέν (Τ)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>Επί (×)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation>Διέρεση (÷)</translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>Εισαγωγή Unicode</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>Σελίδα:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>Χαρ:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation>[0000-007F] Βασικό Λατινικό</translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation></translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation></translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation></translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation></translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation></translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation>[0370-03FF] Ελληνικά και Κοπτικά</translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation>[0400-04FF] Κυριλικά</translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation></translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation>[0530-058F] Αρμενικά</translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation>[0590-05FF] Εβραϊκά</translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation>[0600-06FF] Αραβικά</translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation>[0700-074F] Συριακά</translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation></translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation>[0B80-0BFF] Ταμίλ</translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation>[0C80-0CFF] Κανάντα</translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation>[0E00-0E7F] Τάϊ</translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation>[0E80-0EFF] Λάο</translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation>[0F00-0FFF] Θιβετιανά</translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation>[1000-109F] Μιανμάρ</translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation>[10A0-10FF] Γεωργιανά</translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation>[1200-137F] Αιθιοπιακά</translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation>[13A0-13FF] Τσερόκι</translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation>[16A0-16FF] Ρουνικά</translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation></translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation>[1780-17FF] Χμέρ</translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation>[1800-18AF] Μογκολικά</translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation>[1E00-1EFF] Εκτεταμένα Λατινικά Πρόσθετα</translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation>[1F00-1FFF] Ελληνικά Πρόσθετα</translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation>[20A0-20CF] Σύμβολα Νομισμάτων</translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation>[2190-21FF] Βέλη</translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation>[2200-22FF] Μαθηματικά Σύμβολα</translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation>[2300-23FF] Διάφορα Τεχνικά</translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation>[2400-243F] Εικόνες Ελέγχου</translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation>[2440-245F] Οπτική αναγνώριση χαρακτήρων</translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation>[2460-24FF] Εγκλεισμένα Αλφαριθμιτικά</translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation>[2500-257F] Σχεδίαση κουτιού</translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation>[25A0-25FF] Γεωμετρικά Σχήματα</translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation>[2600-26FF] Διάφορα σύμβολα</translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation>[27C0-27EF] Διάφορα Μαθηματικά σύμβολα-Α</translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation>[2800-28FF] Σύμβολα Μπράϊγ</translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation>[2980-29FF] Διάφορα Μαθηματικά σύμβολα-Β</translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation>[3040-309F] Χιραγκάνα</translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation>[30A0-30FF] Κατακάνα</translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation>[E000-F8FF] Περιοχή Ιδιωτικής Χρήσης</translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation>[10300-1032F] Αρχαία Ιταλικά</translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation>[10330-1034F] Γοτθικά</translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation>[1D000-1D0FF] Βυζαντινά Μουσικά Σύμβολα</translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation>[1D100-1D1FF] Μουσικά Σύμβολα</translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation>[1D400-1D7FF] Μαθηματικά αλφαριθμητικά σύμβολα</translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation>[E0000-E007F] Ετικέτες</translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>&amp;Υψος:</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>Διάκενο &amp;Γραμμών:</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>&amp;Προκαθορισμένο διάκενο σειρών</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation type="obsolete">Alt+E</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation>Alt+D</translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>&amp;Save</source>
        <translation>Α&amp;ποθήκευση</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>Αποθήκευση &amp;ως..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Ακύρωση</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>Δέν δόθηκε κείμενο.</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation>QCad</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="obsolete">Διαφυγή</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Κλείσιμο</translation>
    </message>
    <message>
        <source>Alt+L</source>
        <translation type="obsolete">Alt+Κ</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Επιλογές Εισαγωγής</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Γωνία Περιστροφής</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Σχέση:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation> Σχέση Κλίμακας</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>Επιλογές Εξαγωγής Εικόνας</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>Μέγεθος Bitmap</translation>
    </message>
    <message>
        <source>640</source>
        <translation>640</translation>
    </message>
    <message>
        <source>480</source>
        <translation>480</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Πλάτος:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Υψος:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Φόντο</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Άσπρο</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Μαύρο</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+Ε</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Ανάλυση:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>Αυτόματο</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <source>20</source>
        <translation>20</translation>
    </message>
    <message>
        <source>25</source>
        <translation>25</translation>
    </message>
    <message>
        <source>50</source>
        <translation>50</translation>
    </message>
    <message>
        <source>75</source>
        <translation>75</translation>
    </message>
    <message>
        <source>100</source>
        <translation>100</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Επιλογές Εισαγωγής</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Γωνία Περιστροφής</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Σχέση:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation> Σχέση Κλίμακας</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>Διάταξη:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>Αριθμός Στηλών</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>Αριθμός Σειρών</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>Διάκενο:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>Διάκενο Στηλών</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>Διάκενο Σειρών</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>-Αμετάβλητο-</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>Επιλογές Στρώματος</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>Όνομα Στρώματος:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>Προεπιλεγμένη Πένα</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;Εντάξει</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Διαφυγή</translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Show all layers</source>
        <translation>Εμφάνιση όλων των Στρωμάτων</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>Απόκρυψη όλων των στρωμάτων</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>Πρόσθεση Στρώματος</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>Αφαίρεση του τρέχοντος Στρώματος</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>Διόρθωση χαρακτηριστικών των στρωμάτων / μετονομασία</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>Μενού Στρωμάτων</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>&amp;Εμφάνιση όλων των Στρωμάτων</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>&amp;Απόκρυψη όλων των στρωμάτων</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>&amp;Πρόσθεση Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>Αφαίρεση &amp;Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>Διόρ&amp;θωση Στρώματος</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>Εναλλαγή &amp;Ορατότητας</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>Επιλογές Εισαγωγής Βιβλιοθήκης</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Γωνία Περιστροφής</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Σχέση:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation> Σχέση Κλίμακας</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>Πίνακας Βιβλιοθηκών</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Κατάλογοι</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Εισαγωγή</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>Επιλογές Γωνιακής Γραμμής</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Γωνιακή Γραμμή</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Μήκος:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Μήκος γραμμής</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>Σημείο Προσκόλλησης:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Αρχή</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Μέση</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Τέλος</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>Επιλογές Διχοτόμου γραμμής</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Μήκος:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>Μήκος Διχοτόμου</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Αριθμός:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>Αριθμός διχοτόμων</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>Επιλογές γραμμής</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Αναίρεση</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>Επιλογές Παράλληλων γραμμών</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Απόσταση:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>Απόσταση από το Αρχικό στοιχείο</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Αριθμός:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Αριθμός Παράλληλων</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>Επιλογές Παράλληλων Γραμμών Διαμέσω...</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Αριθμός:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Αριθμός Παράλληλων</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>Επιλογές Πολυγώνων</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Αριθμός:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Αριθμός Πλευρών</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>Επιλογές Πολυγώνων</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Αριθμός:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Αριθμός Πλευρών</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>Επιλογές Γραμμών με σχετική γωνία</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Γωνιακή Γραμμή</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Μήκος:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Μήκος γραμμής</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>Κατά Στρώμα</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Κατά Μπλόκ</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>Χωρίς Πένα</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>Συνεχόμενη</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>Τελεία</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>Τελεία (μικρή)</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>Τελεία (μεγάλη)</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>Παύλα</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>Παύλα (μικρή)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>Παύλα (μεγάλη)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>Παύλα Τελεία</translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>Παύλα Τελεία (μικρή)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>Παύλα Τελεία (μεγάλη)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Διαίρεση</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>Διαίρεση (μικρή)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>Διαίρεση (μεγάλη)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Κέντρο</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>Κέντρο (μικρό)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>Κέντρο (μεγάλο)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Περιθόριο</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>Περιθόριο (μικρό)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>Περιθόριο (μεγάλο)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Αμετάβλητο-</translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>Ποντίκι</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Δεξί</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Αριστερό</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>Επιλογές Μετακίνησης/Περιστροφής</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
</context>
<context>
    <name>QG_PolylineOptions</name>
    <message>
        <source>Close</source>
        <translation type="obsolete">Κλείσιμο</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Αναίρεση</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation type="obsolete">Τόξο</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="obsolete">Ακτίνα:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation>Επιλογές Προεπισκόπησης Εκτύπωσης</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation>Ενναλαγή κατάστασης Μαύρο/Άσπρο</translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation>Κεντράρισμα στη σελίδα</translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation>Ταίριαγμα στη σελίδα</translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>Επιλογές κυκλικού</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Διευθέτηση</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>Ελεγχος και διευθέτηση και των δύο στοιχείων προς το κυκλικό</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Ακτίνα:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>Επιλογή</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>Επιλεγμένα στοιχεία:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>Επιλογές Απόστασης Προσκόλλησης</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Απόσταση:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation>Επιλογές Καμπύλης</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>Μοίρες:</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>Κλειστό</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Αναίρεση</translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>Επιλογές Κειμένου</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Κείμενο:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Γωνία:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>Trim Amount Options</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>Απόσταση. Αρνητική τιμή για περικοπή, θετική τιμή για επιμύκινση.</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Σύνολο:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>Πένα</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>Τύπος γραμμής:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Πλάτος:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Χρώμμα:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>Κατά Στρώμα</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Κατά Μπλόκ</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Προεπιλεγμένο</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation>0.00mm</translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation>0.05mm</translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation>0.09mm</translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation>0.13mm (ISO)</translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation>0.15mm</translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation>0.18mm (ISO)</translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation>0.20mm</translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation>0.25mm (ISO)</translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation>0.30mm</translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation>0.35mm (ISO)</translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation>0.40mm</translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation>0.50mm (ISO)</translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation>0.53mm</translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation>0.60mm</translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation>0.70mm (ISO)</translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation>0.80mm</translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation>0.90mm</translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation>1.00mm (ISO)</translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation>1.06mm</translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation>1.20mm</translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation>1.40mm (ISO)</translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation>1.58mm</translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation>2.00mm (ISO)</translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation>2.11mm</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>-Αμετάβλητο-</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Προειδοποίηση</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>Αφαίρεση Στρώματος</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>Το Στρώμα &quot;%1&quot; και όλα τα στοιχεία σε αυτό θα αφαιρεθούν.</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>Το Στρώμα &quot;%1&quot; δεν μπορεί ποτέ να αφαιρεθεί.</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>Διάλογος Στρώματος</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>Αφαίρεση Μπλόκ</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>Το Μπλόκ &quot;%1&quot; και όλα τα στοιχεία σε αυτό θα αφαιρεθούν.</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>Ιδιότητες στρώματος</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>Στρώμα με όνομα &quot;%1&quot; υπάρχει ίδη. Παρακαλώ δώστε διαφορετικό όνομα.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Αποθήκευση Σχεδίου Ως</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>Το %1 υπάρχει ίδη.
Θέλεις να το αντικαταστήσεις?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Όχι</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ναί</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>Άνοιγμα Σχεδίου</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Άνοιγμα Εικόνας</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation>Windows Bitmap</translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation>Joint Photographic Experts Group</translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation>Multiple-image Network Graphics</translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation>Portable Bit Map</translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation>Portable Grey Map</translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation>Portable Network Graphic</translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation>Portable Pixel Map</translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation>X Bitmap Format</translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation>X Pixel Map</translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>Όλα τα Αρχεία Εικόνων (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation>Graphics Interchange Format</translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation>Drawing Exchange %1</translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation>Αρχεία QCad 1.x %1</translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>Γραμματοσειρά %1</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Όλα τα Αρχεία (*.*)</translation>
    </message>
</context>
</TS>
