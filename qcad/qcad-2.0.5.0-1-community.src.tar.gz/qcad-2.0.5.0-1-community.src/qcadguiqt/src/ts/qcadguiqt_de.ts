<!DOCTYPE TS><TS>
<context>
    <name>QG_ActionFactory</name>
    <message>
        <source>New File</source>
        <translation type="obsolete">Neue Datei</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="obsolete">&amp;Neu</translation>
    </message>
    <message>
        <source>Creates a new document</source>
        <translation type="obsolete">Erstellt eine neue Zeichung</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="obsolete">Öffnen</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="obsolete">Ö&amp;ffnen...</translation>
    </message>
    <message>
        <source>Opens an existing document</source>
        <translation type="obsolete">Öffnet eine bestehende Zeichung</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="obsolete">Datei Speichern</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="obsolete">&amp;Speichern</translation>
    </message>
    <message>
        <source>Saves the current document</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Save File As</source>
        <translation type="obsolete">Speichern unter</translation>
    </message>
    <message>
        <source>Save &amp;as...</source>
        <translation type="obsolete">Speichern &amp;unter...</translation>
    </message>
    <message>
        <source>Close File</source>
        <translation type="obsolete">Datei schliessen</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>Sc&amp;hliessen</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="obsolete">&amp;Drucken</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Beenden</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="obsolete">B&amp;eenden</translation>
    </message>
    <message>
        <source>Quits the application</source>
        <translation>Beendet die Applikation</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Statuszeile</translation>
    </message>
    <message>
        <source>&amp;Statusbar</source>
        <translation>&amp;Statuszeile</translation>
    </message>
    <message>
        <source>Enables/disables the statusbar</source>
        <translation>(De-)aktiviert die Statuszeile</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation type="obsolete">Layer Liste</translation>
    </message>
    <message>
        <source>&amp;Layer List</source>
        <translation type="obsolete">&amp;Layer Liste</translation>
    </message>
    <message>
        <source>Enables/disables the layerlist</source>
        <translation type="obsolete">(De-)aktiviert die Layer Liste</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation type="obsolete">Block Liste</translation>
    </message>
    <message>
        <source>&amp;Block List</source>
        <translation type="obsolete">&amp;Block Liste</translation>
    </message>
    <message>
        <source>Enables/disables the blocklist</source>
        <translation type="obsolete">(De-)aktiviert die Block Liste</translation>
    </message>
    <message>
        <source>Command Widget</source>
        <translation type="obsolete">Eingabezeile</translation>
    </message>
    <message>
        <source>&amp;Command Widget</source>
        <translation type="obsolete">&amp;Eingabezeile</translation>
    </message>
    <message>
        <source>Enables/disables the command widget</source>
        <translation type="obsolete">(De-)aktiviert die Eingabezeile</translation>
    </message>
    <message>
        <source>Option Toolbar</source>
        <translation type="obsolete">Optionen Symbolleiste</translation>
    </message>
    <message>
        <source>&amp;Option Toolbar</source>
        <translation type="obsolete">&amp;Optionen Symbolleiste</translation>
    </message>
    <message>
        <source>Enables/disables the option toolbar</source>
        <translation type="obsolete">(De-)aktiviert die Symbolleiste</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="obsolete">Ansicht vergrössern</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="obsolete">Ansicht ver&amp;grössern</translation>
    </message>
    <message>
        <source>Zooms in</source>
        <translation type="obsolete">Vergrössert die Ansicht</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="obsolete">Ansicht verkleinern</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="obsolete">Ansicht ver&amp;kleinern</translation>
    </message>
    <message>
        <source>Zooms out</source>
        <translation type="obsolete">Verkleinert die Ansicht</translation>
    </message>
    <message>
        <source>Auto Zoom</source>
        <translation type="obsolete">Auto Ansicht</translation>
    </message>
    <message>
        <source>&amp;Auto Zoom</source>
        <translation type="obsolete">&amp;Auto Ansicht</translation>
    </message>
    <message>
        <source>Zooms automatic</source>
        <translation type="obsolete">Zeigt die ganze Zeichnung</translation>
    </message>
    <message>
        <source>Window Zoom</source>
        <translation type="obsolete">Fenster Zoom</translation>
    </message>
    <message>
        <source>&amp;Window Zoom</source>
        <translation type="obsolete">&amp;Fenster Zoom</translation>
    </message>
    <message>
        <source>Zooms in a window</source>
        <translation type="obsolete">Vergrössert einen Ausschnitt</translation>
    </message>
    <message>
        <source>Pan Zoom</source>
        <translation type="obsolete">Ansicht verschieben</translation>
    </message>
    <message>
        <source>&amp;Pan Zoom</source>
        <translation type="obsolete">Ansicht &amp;verschieben</translation>
    </message>
    <message>
        <source>Realtime Panning</source>
        <translation type="obsolete">Echtzeit verschieben</translation>
    </message>
    <message>
        <source>Redraw</source>
        <translation type="obsolete">Neu aufbauen</translation>
    </message>
    <message>
        <source>&amp;Redraw</source>
        <translation type="obsolete">&amp;Neu aufbauen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Rückgängig</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">&amp;Rückgängig</translation>
    </message>
    <message>
        <source>Undoes last action</source>
        <translation type="obsolete">Macht die letzte Änderung rückgängig</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Wieder herstellen</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Wieder herstellen</translation>
    </message>
    <message>
        <source>Redoes last action</source>
        <translation type="obsolete">Stellt die zuletzt zurückgenommene Änderung wieder her</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Ausschneiden</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">Aus&amp;schneiden</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">&amp;Kopieren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Einfügen</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">Ein&amp;fügen</translation>
    </message>
    <message>
        <source>Select Entity</source>
        <translation type="obsolete">Objekt selektieren</translation>
    </message>
    <message>
        <source>Selects single Entities</source>
        <translation type="obsolete">Einzelne Objekte selektieren</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation type="obsolete">Bereich selektieren</translation>
    </message>
    <message>
        <source>Select &amp;Window</source>
        <translation type="obsolete">&amp;Bereich selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities in a given Window</source>
        <translation type="obsolete">Selektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation type="obsolete">Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselect &amp;Window</source>
        <translation type="obsolete">&amp;Bereich deselektieren</translation>
    </message>
    <message>
        <source>Deselects all Entities in a given Window</source>
        <translation type="obsolete">Deselektiert alle Objekte in einem rechteckigen Bereich</translation>
    </message>
    <message>
        <source>(De-)Select Contour</source>
        <translation type="obsolete">Kontur (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects connected entities</source>
        <translation type="obsolete">(De-)selektiert verbundene Objekte (Konturen)</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="obsolete">Alles selektieren</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="obsolete">&amp;Alles selektieren</translation>
    </message>
    <message>
        <source>Selects all Entities</source>
        <translation type="obsolete">Selektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation type="obsolete">Deselektiert alle Objekte</translation>
    </message>
    <message>
        <source>Deselect &amp;all</source>
        <translation type="obsolete">&amp;Alles Deselktieren</translation>
    </message>
    <message>
        <source>Deselects all Entities</source>
        <translation type="obsolete">Deselektiert alle sichtbaren Objekte</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation type="obsolete">Selektion invertieren</translation>
    </message>
    <message>
        <source>&amp;Invert Selection</source>
        <translation type="obsolete">Selektion &amp;invertieren</translation>
    </message>
    <message>
        <source>Inverts the current selection</source>
        <translation type="obsolete">Invertiert die aktuelle Selektion</translation>
    </message>
    <message>
        <source>Select Intersected Entities</source>
        <translation type="obsolete">Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>In&amp;tersected Entities</source>
        <translation type="obsolete">&amp;Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>Selects all entities intersected by a line</source>
        <translation type="obsolete">Selektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
    <message>
        <source>Deselect Intersected Entities</source>
        <translation type="obsolete">Geschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselect Inte&amp;rsected Entities</source>
        <translation type="obsolete">G&amp;eschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselects all entities intersected by a line</source>
        <translation type="obsolete">Deselektiert alle Objekte, die von einer Linie geschnitten werden</translation>
    </message>
    <message>
        <source>(De-)Select Layer</source>
        <translation type="obsolete">Layer (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Selects layers</source>
        <translation type="obsolete">(De-)selektiert alle Objekte auf einem Layer</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Punkte</translation>
    </message>
    <message>
        <source>&amp;Points</source>
        <translation type="obsolete">&amp;Punkte</translation>
    </message>
    <message>
        <source>Draw Points</source>
        <translation type="obsolete">Punkte zeichnen</translation>
    </message>
    <message>
        <source>Line: 2 Points</source>
        <translation type="obsolete">Linie: 2 Punkte</translation>
    </message>
    <message>
        <source>&amp;2 Points</source>
        <translation type="obsolete">&amp;2 Punkte</translation>
    </message>
    <message>
        <source>Draw lines</source>
        <translation type="obsolete">Linien zeichnen</translation>
    </message>
    <message>
        <source>Line: Angle</source>
        <translation type="obsolete">Linie: Winkel</translation>
    </message>
    <message>
        <source>&amp;Angle</source>
        <translation type="obsolete">&amp;Winkel</translation>
    </message>
    <message>
        <source>Draw lines with a given angle</source>
        <translation type="obsolete">Zeichnen von Linien mit gegebenem Winkel</translation>
    </message>
    <message>
        <source>Line: Horizontal</source>
        <translation type="obsolete">Linie: Horizontal</translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="obsolete">&amp;Horizontal</translation>
    </message>
    <message>
        <source>Draw horizontal lines</source>
        <translation type="obsolete">Zeichnen von horizontalen Linien</translation>
    </message>
    <message>
        <source>hor./vert. line</source>
        <translation type="obsolete">hor./vert. Linie</translation>
    </message>
    <message>
        <source>H&amp;orizontal / Vertical</source>
        <translation type="obsolete">H&amp;orizontal / Vertikal</translation>
    </message>
    <message>
        <source>Draw horizontal/vertical lines</source>
        <translation type="obsolete">Zeichnen von horizontalen oder vertikalen Linien</translation>
    </message>
    <message>
        <source>Line: Vertical</source>
        <translation type="obsolete">Linie: vertikal</translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="obsolete">&amp;Vertikal</translation>
    </message>
    <message>
        <source>Draw vertical lines</source>
        <translation type="obsolete">Zeichnen von vertikalen Linien</translation>
    </message>
    <message>
        <source>Line: Freehand</source>
        <translation type="obsolete">Linie: Freihand</translation>
    </message>
    <message>
        <source>&amp;Freehand Line</source>
        <translation type="obsolete">&amp;Freihand-Linie</translation>
    </message>
    <message>
        <source>Draw freehand lines</source>
        <translation type="obsolete">Freihand-Linien zeichnen</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Parallele</translation>
    </message>
    <message>
        <source>Para&amp;llel</source>
        <translation type="obsolete">Para&amp;llele</translation>
    </message>
    <message>
        <source>Draw parallels</source>
        <translation type="obsolete">Zeichnen von Parallelen Linien</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="obsolete">Rechteck</translation>
    </message>
    <message>
        <source>&amp;Rectangle</source>
        <translation type="obsolete">&amp;Rechteck</translation>
    </message>
    <message>
        <source>Draw rectangles</source>
        <translation type="obsolete">Zeichnen von Rechtecken</translation>
    </message>
    <message>
        <source>Bisector</source>
        <translation type="obsolete">Winkelhalbierende</translation>
    </message>
    <message>
        <source>&amp;Bisector</source>
        <translation type="obsolete">&amp;Winkelhalbierende</translation>
    </message>
    <message>
        <source>Draw bisectors</source>
        <translation type="obsolete">Winkelhalbierende zeichnen</translation>
    </message>
    <message>
        <source>Tangent (P,C)</source>
        <translation type="obsolete">Tangente (P,K)</translation>
    </message>
    <message>
        <source>&amp;Tangent (P,C)</source>
        <translation type="obsolete">&amp;Tangente (P,K)</translation>
    </message>
    <message>
        <source>Draw tangent (point, circle)</source>
        <translation type="obsolete">Tangente von einemPunkt an einen Kreis zeichnen</translation>
    </message>
    <message>
        <source>Tangent (C,C)</source>
        <translation type="obsolete">Tangente (K,K)</translation>
    </message>
    <message>
        <source>Tan&amp;gent (C,C)</source>
        <translation type="obsolete">Tan&amp;gente (K,K)</translation>
    </message>
    <message>
        <source>Draw tangent (circle, circle)</source>
        <translation type="obsolete">Tangente von Kreis zu Kreis zeichnen</translation>
    </message>
    <message>
        <source>Orthogonal</source>
        <translation type="obsolete">Orthogonal</translation>
    </message>
    <message>
        <source>&amp;Orthogonal</source>
        <translation type="obsolete">&amp;Orthogonal</translation>
    </message>
    <message>
        <source>Draw orthogonal line</source>
        <translation type="obsolete">Orthogonale Linien zeichnen</translation>
    </message>
    <message>
        <source>Relative angle</source>
        <translation type="obsolete">Relativer Winkel</translation>
    </message>
    <message>
        <source>R&amp;elative angle</source>
        <translation type="obsolete">R&amp;elativer Winkel</translation>
    </message>
    <message>
        <source>Draw line with relative angle</source>
        <translation type="obsolete">Linien mit relativem Winkel zu einem Objekt zeichnen</translation>
    </message>
    <message>
        <source>Polygon</source>
        <translation type="obsolete">Polygon</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cen,Cor)</source>
        <translation type="obsolete">Pol&amp;ygon (Zentrum,Ecke)</translation>
    </message>
    <message>
        <source>Draw polygon with center and corner</source>
        <translation type="obsolete">Polygon mit Zentrum und Ecke zeichnen</translation>
    </message>
    <message>
        <source>Pol&amp;ygon (Cor,Cor)</source>
        <translation type="obsolete">Pol&amp;ygon (zwei Ecken)</translation>
    </message>
    <message>
        <source>Draw polygon with two corners</source>
        <translation type="obsolete">Polygon mit zwei gegebenen Ecken zeichnen</translation>
    </message>
    <message>
        <source>Circle: Center, Point</source>
        <translation type="obsolete">Kreis: Zentrum, Kreispunkt</translation>
    </message>
    <message>
        <source>Center, &amp;Point</source>
        <translation type="obsolete">Zentrum, &amp;Kreispunkt</translation>
    </message>
    <message>
        <source>Draw circles with center and point</source>
        <translation type="obsolete">Kreis mit Zentrum und Kreispunkt zeichnen</translation>
    </message>
    <message>
        <source>Circle: Center, Radius</source>
        <translation type="obsolete">Kreis: Zentrum, Radius</translation>
    </message>
    <message>
        <source>Center, &amp;Radius</source>
        <translation type="obsolete">Zentrum, &amp;Radius</translation>
    </message>
    <message>
        <source>Draw circles with center and radius</source>
        <translation type="obsolete">Kreis mit Zentrum und Radius zeichnen</translation>
    </message>
    <message>
        <source>Circle: 2 Points</source>
        <translation type="obsolete">Kreis: 2 Punkte</translation>
    </message>
    <message>
        <source>2 Points</source>
        <translation type="obsolete">2 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 2 points</source>
        <translation type="obsolete">Kreis mit 2 Kreispunkten  zeichnen</translation>
    </message>
    <message>
        <source>Circle: 3 Points</source>
        <translation type="obsolete">Kreis: 3 Punkte</translation>
    </message>
    <message>
        <source>3 Points</source>
        <translation type="obsolete">3 Punkte</translation>
    </message>
    <message>
        <source>Draw circles with 3 points</source>
        <translation type="obsolete">Kreis mit 3 Kreispunkten zeichnen</translation>
    </message>
    <message>
        <source>Circle: Parallel</source>
        <translation type="obsolete">Kreis: Parallel</translation>
    </message>
    <message>
        <source>&amp;Parallel</source>
        <translation type="obsolete">&amp;Parallel</translation>
    </message>
    <message>
        <source>Draw arcs parallel to existing arcs</source>
        <translation type="obsolete">Kreisbogen parallel zu einem existierenden Kreisbogen</translation>
    </message>
    <message>
        <source>Arc: Center, Point, Angles</source>
        <translation type="obsolete">Kreisbogen: Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>&amp;Center, Point, Angles</source>
        <translation type="obsolete">&amp;Zentrum, Punkt, Winkel</translation>
    </message>
    <message>
        <source>Draw arcs</source>
        <translation type="obsolete">Kresibogen zeichnen</translation>
    </message>
    <message>
        <source>Arc: 3 Points</source>
        <translation type="obsolete">Kreisbogen: 3 Punkte</translation>
    </message>
    <message>
        <source>&amp;3 Points</source>
        <translation type="obsolete">&amp;3 Punkte</translation>
    </message>
    <message>
        <source>Draw arcs with 3 points</source>
        <translation type="obsolete">Kreisbogen mit 3 Punkten</translation>
    </message>
    <message>
        <source>Arc: Parallel</source>
        <translation type="obsolete">Kreisbogen: Parallel</translation>
    </message>
    <message>
        <source>Ellipse with Axis</source>
        <translation type="obsolete">Elllipse mit Achsen</translation>
    </message>
    <message>
        <source>&amp;Ellipse (Axis)</source>
        <translation type="obsolete">&amp;Ellipse (Achsen)</translation>
    </message>
    <message>
        <source>Draw Ellipses</source>
        <translation type="obsolete">Ellipse zeichnen</translation>
    </message>
    <message>
        <source>Ellipse Arc with Axis</source>
        <translation type="obsolete">Ellipsenbogen mit Achse</translation>
    </message>
    <message>
        <source>&amp;Ellipse Arc (Axis)</source>
        <translation type="obsolete">Ellipsen&amp;bogen (Achse)</translation>
    </message>
    <message>
        <source>Draw Ellipse Arcs</source>
        <translation type="obsolete">Ellipsenbogen zeichnen</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Text</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="obsolete">&amp;Text</translation>
    </message>
    <message>
        <source>Draw Text Entities</source>
        <translation type="obsolete">Text Objekt erstellen</translation>
    </message>
    <message>
        <source>Hatches</source>
        <translation type="obsolete">Schraffur</translation>
    </message>
    <message>
        <source>&amp;Hatches</source>
        <translation type="obsolete">&amp;Schraffuren</translation>
    </message>
    <message>
        <source>Draw Hatches and Solid Fills</source>
        <translation type="obsolete">Erstellen von Schraffuren und Füllungen</translation>
    </message>
    <message>
        <source>Aligned</source>
        <translation type="obsolete">Ausgerichtet</translation>
    </message>
    <message>
        <source>&amp;Aligned</source>
        <translation type="obsolete">&amp;Ausgerichtet</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Anliegende Bemassung</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="obsolete">Linear</translation>
    </message>
    <message>
        <source>&amp;Linear</source>
        <translation type="obsolete">&amp;Linear</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation type="obsolete">Lineare Bemassung</translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="obsolete">Horizontal</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation type="obsolete">Horizontale Bemassung</translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="obsolete">Vertikal</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation type="obsolete">Vertikale Bemassung</translation>
    </message>
    <message>
        <source>Radial</source>
        <translation type="obsolete">Radial</translation>
    </message>
    <message>
        <source>&amp;Radial</source>
        <translation type="obsolete">&amp;Radial</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation type="obsolete">Radiale Bemassung</translation>
    </message>
    <message>
        <source>Diametric</source>
        <translation type="obsolete">Durchmesser</translation>
    </message>
    <message>
        <source>&amp;Diametric</source>
        <translation type="obsolete">&amp;Durchmesser</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation type="obsolete">Durchmesser Bemassung</translation>
    </message>
    <message>
        <source>Angular</source>
        <translation type="obsolete">Winkel</translation>
    </message>
    <message>
        <source>&amp;Angular</source>
        <translation type="obsolete">&amp;Winkel</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation type="obsolete">Winkel Bemassung</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation type="obsolete">Führung</translation>
    </message>
    <message>
        <source>&amp;Leader</source>
        <translation type="obsolete">&amp;Führung</translation>
    </message>
    <message>
        <source>Leader Dimension</source>
        <translation type="obsolete">Führung</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Löschen</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;Löschen</translation>
    </message>
    <message>
        <source>Delete Entities</source>
        <translation type="obsolete">Objekte löschen</translation>
    </message>
    <message>
        <source>Quick Delete</source>
        <translation type="obsolete">Schnell Löschen</translation>
    </message>
    <message>
        <source>&amp;Quick Delete</source>
        <translation type="obsolete">&amp;Schnell Löschen</translation>
    </message>
    <message>
        <source>Delete Entities directly</source>
        <translation type="obsolete">Löscht Objekte direkt</translation>
    </message>
    <message>
        <source>Delete Freehand</source>
        <translation type="obsolete">Freihand löschen</translation>
    </message>
    <message>
        <source>&amp;Delete Freehand</source>
        <translation type="obsolete">&amp;Freihand Löschen</translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="obsolete">Verschieben</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation type="obsolete">&amp;Verschieben</translation>
    </message>
    <message>
        <source>Move Entities</source>
        <translation type="obsolete">Objekte verschieben / kopieren</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation type="obsolete">Rotieren</translation>
    </message>
    <message>
        <source>&amp;Rotate</source>
        <translation type="obsolete">&amp;Rotieren</translation>
    </message>
    <message>
        <source>Rotate Entities</source>
        <translation type="obsolete">Objekte rotieren</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="obsolete">Skalieren</translation>
    </message>
    <message>
        <source>&amp;Scale</source>
        <translation type="obsolete">&amp;Skalieren</translation>
    </message>
    <message>
        <source>Scale Entities</source>
        <translation type="obsolete">Objekte skalieren</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation type="obsolete">Spiegeln</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation type="obsolete">S&amp;piegeln</translation>
    </message>
    <message>
        <source>Mirror Entities</source>
        <translation type="obsolete">Objekte spiegeln</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation type="obsolete">Verschieben und Rotieren</translation>
    </message>
    <message>
        <source>M&amp;ove and Rotate</source>
        <translation type="obsolete">V&amp;erschieben und Rotieren</translation>
    </message>
    <message>
        <source>Move and Rotate Entities</source>
        <translation type="obsolete">Verschiebt und Rotiert Objekte</translation>
    </message>
    <message>
        <source>Rotate Two</source>
        <translation type="obsolete">Rotieren Zwei</translation>
    </message>
    <message>
        <source>Rotate T&amp;wo</source>
        <translation type="obsolete">Rotieren &amp;Zwei</translation>
    </message>
    <message>
        <source>Rotate Entities around two centers</source>
        <translation type="obsolete">Objekte um zwei Zentren rotieren</translation>
    </message>
    <message>
        <source>Entity</source>
        <translation type="obsolete">Objekt</translation>
    </message>
    <message>
        <source>&amp;Entity</source>
        <translation type="obsolete">&amp;Objekt</translation>
    </message>
    <message>
        <source>Modify Entities</source>
        <translation type="obsolete">Objekte modifizieren</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation type="obsolete">Trimmen</translation>
    </message>
    <message>
        <source>&amp;Trim</source>
        <translation type="obsolete">&amp;Trimmen</translation>
    </message>
    <message>
        <source>Trim Entities</source>
        <translation type="obsolete">Objekte trimmen</translation>
    </message>
    <message>
        <source>Trim Two</source>
        <translation type="obsolete">Trimmen Zwei</translation>
    </message>
    <message>
        <source>&amp;Trim Two</source>
        <translation type="obsolete">&amp;Trimmen Zwei</translation>
    </message>
    <message>
        <source>Trim two Entities</source>
        <translation type="obsolete">Zwei Objekte trimmen</translation>
    </message>
    <message>
        <source>Lengthen</source>
        <translation type="obsolete">Verlängern</translation>
    </message>
    <message>
        <source>&amp;Lengthen</source>
        <translation type="obsolete">&amp;Verlängern</translation>
    </message>
    <message>
        <source>Lengthen by a given amount</source>
        <translation type="obsolete">Um einen gegebenen Betrag verlängern</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation type="obsolete">T&amp;rennen</translation>
    </message>
    <message>
        <source>Cut Entities</source>
        <translation type="obsolete">Objekte trennen</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation type="obsolete">Strecken</translation>
    </message>
    <message>
        <source>&amp;Stretch</source>
        <translation type="obsolete">&amp;Strecken</translation>
    </message>
    <message>
        <source>Stretch Entities</source>
        <translation type="obsolete">Objektgruppen strecken</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation type="obsolete">Abschrägen</translation>
    </message>
    <message>
        <source>&amp;Bevel</source>
        <translation type="obsolete">&amp;Abschrägen</translation>
    </message>
    <message>
        <source>Bevel Entities</source>
        <translation type="obsolete">Ecken abschrägen</translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="obsolete">Runden</translation>
    </message>
    <message>
        <source>&amp;Round</source>
        <translation type="obsolete">&amp;Runden</translation>
    </message>
    <message>
        <source>Round Entities</source>
        <translation type="obsolete">Ecken runden</translation>
    </message>
    <message>
        <source>Free</source>
        <translation>Frei</translation>
    </message>
    <message>
        <source>&amp;Free</source>
        <translation>&amp;Frei</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Freie positionierung</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Raster</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Raster</translation>
    </message>
    <message>
        <source>Grid positioning</source>
        <translation>Raster Positionierung</translation>
    </message>
    <message>
        <source>Endpoints</source>
        <translation>Endpunkte</translation>
    </message>
    <message>
        <source>&amp;Endpoints</source>
        <translation>&amp;Endpunkte</translation>
    </message>
    <message>
        <source>Snap to endpoints</source>
        <translation>Endpunkte fangen</translation>
    </message>
    <message>
        <source>On Entity</source>
        <translation>Auf Objekt</translation>
    </message>
    <message>
        <source>&amp;On Entity</source>
        <translation>&amp;Auf Objekt</translation>
    </message>
    <message>
        <source>Snap to nearest point on entity</source>
        <translation>Nächsten Punkt auf einem Objekt fangen</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Zentrum</translation>
    </message>
    <message>
        <source>&amp;Center</source>
        <translation>&amp;Zentrum</translation>
    </message>
    <message>
        <source>Snap to centers</source>
        <translation>Zentern fangen</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Mittelpunkt</translation>
    </message>
    <message>
        <source>&amp;Middle</source>
        <translation>&amp;Mittelpunkt</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Mittelpunkte fangen</translation>
    </message>
    <message>
        <source>Distance from Endpoint</source>
        <translation>Distanz zum Endpunkt</translation>
    </message>
    <message>
        <source>&amp;Distance from Endpoint</source>
        <translation>&amp;Distanz zum Endpunkt</translation>
    </message>
    <message>
        <source>Snap to points with a given distance to an endpoint</source>
        <translation>Punkt mit gegebenem Abstand zu einem Endpunkt fangen</translation>
    </message>
    <message>
        <source>Intersection</source>
        <translation>Schnittpunkt</translation>
    </message>
    <message>
        <source>&amp;Intersection</source>
        <translation>&amp;Schnittpunkt</translation>
    </message>
    <message>
        <source>Snap to intersection points</source>
        <translation>Schnittpunkte fangen</translation>
    </message>
    <message>
        <source>Intersection Manually</source>
        <translation type="obsolete">Schnittpunkt manuell</translation>
    </message>
    <message>
        <source>I&amp;ntersection Manually</source>
        <translation type="obsolete">Sch&amp;nittpunkt manuell</translation>
    </message>
    <message>
        <source>Snap to intersection points manually</source>
        <translation type="obsolete">Schnittpunkte manuell fangen</translation>
    </message>
    <message>
        <source>Restrict Nothing</source>
        <translation>Keine Einschränkung</translation>
    </message>
    <message>
        <source>Restrict &amp;Nothing</source>
        <translation>&amp;Keine Einschränkung</translation>
    </message>
    <message>
        <source>No snap restriction</source>
        <translation>Alle Fang-Einschränkungen aufheben</translation>
    </message>
    <message>
        <source>Restrict Orthogonally</source>
        <translation>Orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Orthogonally</source>
        <translation>&amp;Orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping orthogonally</source>
        <translation>Fangen orthogonal einschränken</translation>
    </message>
    <message>
        <source>Restrict Horizontally</source>
        <translation>Horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Horizontally</source>
        <translation>&amp;Horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping horizontally</source>
        <translation>Fangen horizontal einschränken</translation>
    </message>
    <message>
        <source>Restrict Vertically</source>
        <translation>Vertikal einschränken</translation>
    </message>
    <message>
        <source>Restrict &amp;Vertically</source>
        <translation>&amp;Vertikal einschränken</translation>
    </message>
    <message>
        <source>Restrict snapping vertically</source>
        <translation>Fangen vertikal einschränken</translation>
    </message>
    <message>
        <source>Set Relative Zero</source>
        <translation type="obsolete">Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>&amp;Set Relative Zero</source>
        <translation type="obsolete">&amp;Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>Set position of the Relative Zero point</source>
        <translation type="obsolete">Position des relativen Nullpunktes neu setzten</translation>
    </message>
    <message>
        <source>(Un-)Lock Relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)&amp;Lock Relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt &amp;festhalten / loslassen</translation>
    </message>
    <message>
        <source>(Un-)Lock relative Zero</source>
        <translation type="obsolete">Relativen Nullpunkt festhalten / loslassen</translation>
    </message>
    <message>
        <source>Point inside contour</source>
        <translation type="obsolete">Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>&amp;Point inside contour</source>
        <translation type="obsolete">&amp;Punkt innerhalb einer Kontur</translation>
    </message>
    <message>
        <source>Checks if a given point is inside the selected contour</source>
        <translation type="obsolete">Testet, ob ein gegebener Punkt innerhalb der selektierten Kontur liegt</translation>
    </message>
    <message>
        <source>Defreeze all</source>
        <translation type="obsolete">Alle auftauen</translation>
    </message>
    <message>
        <source>&amp;Defreeze all</source>
        <translation type="obsolete">Alle auf&amp;tauen</translation>
    </message>
    <message>
        <source>Defreeze all layers</source>
        <translation type="obsolete">Alle Layer auftauen</translation>
    </message>
    <message>
        <source>Freeze all</source>
        <translation type="obsolete">Alle einfrieren</translation>
    </message>
    <message>
        <source>&amp;Freeze all</source>
        <translation type="obsolete">Alle ein&amp;frieren</translation>
    </message>
    <message>
        <source>Freeze all layers</source>
        <translation type="obsolete">Alle Layer einfrieren</translation>
    </message>
    <message>
        <source>Add Layer</source>
        <translation type="obsolete">Layer hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation type="obsolete">Layer &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation type="obsolete">Layer löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation type="obsolete">Layer &amp;löschen</translation>
    </message>
    <message>
        <source>Edit Layer</source>
        <translation type="obsolete">Layerattribute ändern</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation type="obsolete">Layer&amp;attribute ändern</translation>
    </message>
    <message>
        <source>Toggle Layer Visibility</source>
        <translation type="obsolete">Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>&amp;Toggle Layer</source>
        <translation type="obsolete">&amp;Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>Toggle Layer</source>
        <translation type="obsolete">Sichtbarkeit des Layers ändern</translation>
    </message>
    <message>
        <source>Defreeze all blocks</source>
        <translation type="obsolete">Alle Blöcke auftauen</translation>
    </message>
    <message>
        <source>Freeze all blocks</source>
        <translation type="obsolete">Alle Blöcke einfrieren</translation>
    </message>
    <message>
        <source>Add Block</source>
        <translation type="obsolete">Block hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation type="obsolete">Block &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation type="obsolete">Block löschen</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation type="obsolete">Block &amp;löschen</translation>
    </message>
    <message>
        <source>Rename Block</source>
        <translation type="obsolete">Block umbenennen</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation type="obsolete">Block um&amp;benennen</translation>
    </message>
    <message>
        <source>Rename Block and all Inserts</source>
        <translation type="obsolete">Block und alle Instanzen umbennenen</translation>
    </message>
    <message>
        <source>Edit Block</source>
        <translation type="obsolete">Block editieren</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation type="obsolete">Block &amp;editieren</translation>
    </message>
    <message>
        <source>Insert Block</source>
        <translation type="obsolete">Block einfügen</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation type="obsolete">Block ein&amp;fügen</translation>
    </message>
    <message>
        <source>Toggle Block Visibility</source>
        <translation type="obsolete">Sichtbareit umschalten</translation>
    </message>
    <message>
        <source>&amp;Toggle Block</source>
        <translation type="obsolete">Sichtbarkeit &amp;umschalten</translation>
    </message>
    <message>
        <source>Toggle Block</source>
        <translation type="obsolete">Sichtbarkeit umschalten</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation type="obsolete">Block erstellen</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">&amp;Block erstellen</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation type="obsolete">Aufbrechen</translation>
    </message>
    <message>
        <source>&amp;Explode</source>
        <translation type="obsolete">&amp;Aufbrechen</translation>
    </message>
    <message>
        <source>Explode Blocks and other Entity Groups</source>
        <translation type="obsolete">Blöcke und andere Objekt-Gruppen aufbrechen</translation>
    </message>
    <message>
        <source>General</source>
        <translation type="obsolete">Allgemein</translation>
    </message>
    <message>
        <source>&amp;General Preferences</source>
        <translation type="obsolete">&amp;Allgemeine Einstellungen</translation>
    </message>
    <message>
        <source>General Application Preferences</source>
        <translation>Allgemeine Applikations-Einstellungen</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="obsolete">Zeichnung</translation>
    </message>
    <message>
        <source>&amp;Drawing Preferences</source>
        <translation type="obsolete">&amp;Zeichnungs-Einstellungen</translation>
    </message>
    <message>
        <source>Drawing Settings</source>
        <translation type="obsolete">Zeichnungs-Einstellungen</translation>
    </message>
    <message>
        <source>Creates a new drawing</source>
        <translation type="obsolete">Erstellt eine neue Zeichnung</translation>
    </message>
    <message>
        <source>Opens an existing drawing</source>
        <translation type="obsolete">Öffnet eine bestehende Zeichnung</translation>
    </message>
    <message>
        <source>Saves the current drawing</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Saves the current drawing under a new filename</source>
        <translation type="obsolete">Speichert die aktuelle Zeichnung unter einem neuen Dateinamen</translation>
    </message>
    <message>
        <source>Closes the current drawing</source>
        <translation>Schliesst die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Prints out the current drawing</source>
        <translation>Druckt die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>New Drawing</source>
        <translation type="obsolete">Neue Zeichnung</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation type="obsolete">Zeichnung öffnen</translation>
    </message>
    <message>
        <source>Save Drawing</source>
        <translation type="obsolete">Zeichnung speichern</translation>
    </message>
    <message>
        <source>Save Drawing As</source>
        <translation type="obsolete">Zeichnung speichern als</translation>
    </message>
    <message>
        <source>Close Drawing</source>
        <translation>Zeichnung schliessen</translation>
    </message>
    <message>
        <source>Print Drawing</source>
        <translation>Zeichnung drucken</translation>
    </message>
    <message>
        <source>Cuts entities  to the clipboard</source>
        <translation type="obsolete">Schneidet Objekte aus auf die Zwischenablage</translation>
    </message>
    <message>
        <source>Copies entities to the clipboard</source>
        <translation type="obsolete">Kopiert Objekte auf die Zwischenablage</translation>
    </message>
    <message>
        <source>Pastes the clipboard contents</source>
        <translation type="obsolete">Fügt den Inhalt der Zwischenablage ein</translation>
    </message>
    <message>
        <source>(De-)&amp;Select Entity</source>
        <translation type="obsolete">Objekte (de-)&amp;selektieren</translation>
    </message>
    <message>
        <source>(De-)Select &amp;Contour</source>
        <translation type="obsolete">&amp;Konturen (de-)selektieren</translation>
    </message>
    <message>
        <source>Draw parallels to existing lines, arcs, circles</source>
        <translation type="obsolete">Parallelen zu existierenden Linien, Bögen und Kreisen</translation>
    </message>
    <message>
        <source>Parallel through point</source>
        <translation type="obsolete">Parallele durch Punkt</translation>
    </message>
    <message>
        <source>Par&amp;allel through point</source>
        <translation type="obsolete">Par&amp;allele durch Punkt</translation>
    </message>
    <message>
        <source>Draw parallel through a given point</source>
        <translation type="obsolete">Parallele durch einen gegebenen Punkt konstruieren</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation type="obsolete">Attribute</translation>
    </message>
    <message>
        <source>&amp;Attributes</source>
        <translation type="obsolete">&amp;Attribute</translation>
    </message>
    <message>
        <source>Modify Entity Attributes</source>
        <translation type="obsolete">Objekt Attribute editieren</translation>
    </message>
    <message>
        <source>Delete selected</source>
        <translation type="obsolete">Selektierte Objekte löschen</translation>
    </message>
    <message>
        <source>&amp;Delete selected</source>
        <translation type="obsolete">Selektierte &amp;löschen</translation>
    </message>
    <message>
        <source>Delete selected entities</source>
        <translation type="obsolete">Selektierte Objekte löschen</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="obsolete">Bilder</translation>
    </message>
    <message>
        <source>&amp;Images</source>
        <translation type="obsolete">&amp;Bilder</translation>
    </message>
    <message>
        <source>Insert Images (Bitmaps)</source>
        <translation type="obsolete">Bilder (Bitmaps) einfügen</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation type="obsolete">Druckvorschau</translation>
    </message>
    <message>
        <source>Print Pre&amp;view</source>
        <translation type="obsolete">Druck&amp;vorschau</translation>
    </message>
    <message>
        <source>Shows a preview of a print</source>
        <translation type="obsolete">Zeigt Druckvorschau an</translation>
    </message>
    <message>
        <source>Distance Point to Point</source>
        <translation type="obsolete">Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Point to Point</source>
        <translation type="obsolete">&amp;Abstand Punkt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between two points</source>
        <translation type="obsolete">Misst die Distanz zwischen zwei Punkten</translation>
    </message>
    <message>
        <source>Distance Entity to Point</source>
        <translation type="obsolete">Abstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>&amp;Distance Entity to Point</source>
        <translation type="obsolete">A&amp;bstand Objekt zu Punkt</translation>
    </message>
    <message>
        <source>Measures the distance between an entity and a point</source>
        <translation type="obsolete">Misst die Distanz zwischen einem Objekt und einem Punkt</translation>
    </message>
    <message>
        <source>Angle between two lines</source>
        <translation type="obsolete">Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>&amp;Angle between two lines</source>
        <translation type="obsolete">&amp;Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>Measures the angle between two lines</source>
        <translation type="obsolete">Misst den Winkel zwischen zwei Linien</translation>
    </message>
    <message>
        <source>Export Drawing</source>
        <translation>Zeichnung Exportieren</translation>
    </message>
    <message>
        <source>&amp;Export..</source>
        <translation type="obsolete">&amp;Export..</translation>
    </message>
    <message>
        <source>Exports the current drawing as bitmap</source>
        <translation>Exportiert die aktuelle Zeichnung als Bitmap</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Eigenschaften</translation>
    </message>
    <message>
        <source>Modify Entity Properties</source>
        <translation type="obsolete">Objekt Eigenschaften bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="obsolete">&amp;Eigenschaften</translation>
    </message>
    <message>
        <source>Application</source>
        <translation>Applikation</translation>
    </message>
    <message>
        <source>&amp;Application Preferences</source>
        <translation>&amp;Applikations Einstellungen</translation>
    </message>
    <message>
        <source>Current &amp;Drawing Preferences</source>
        <translation type="obsolete">&amp;Zeichnungseinstellungen</translation>
    </message>
    <message>
        <source>Settings for the current Drawing</source>
        <translation type="obsolete">Einstellungen für die aktuelle Zeichnung</translation>
    </message>
    <message>
        <source>Enables/disables the grid</source>
        <translation>Raster ein- / ausschalten</translation>
    </message>
    <message>
        <source>Circle: Concentric</source>
        <translation type="obsolete">Kreis: Konzentrisch</translation>
    </message>
    <message>
        <source>&amp;Concentric</source>
        <translation type="obsolete">&amp;Konzentrisch</translation>
    </message>
    <message>
        <source>Draw circles concentric to existing circles</source>
        <translation type="obsolete">Kreis konzentrisch zu existierendem Kreis</translation>
    </message>
    <message>
        <source>Arc: Concentric</source>
        <translation type="obsolete">Kreisbogen: Konzentrisch</translation>
    </message>
    <message>
        <source>Draw arcs concentric to existing arcs</source>
        <translation type="obsolete">Kreisbogen konzentrisch zu existierendem Kreisbogen</translation>
    </message>
    <message>
        <source>Hatch</source>
        <translation type="obsolete">Schraffur</translation>
    </message>
    <message>
        <source>&amp;Hatch</source>
        <translation type="obsolete">&amp;Schraffur</translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="obsolete">Bild</translation>
    </message>
    <message>
        <source>&amp;Image</source>
        <translation type="obsolete">&amp;Bild</translation>
    </message>
    <message>
        <source>Insert Image (Bitmap)</source>
        <translation type="obsolete">Bild (Bitmap) einfügen</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation type="obsolete">Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>&amp;Total length of selected entities</source>
        <translation type="obsolete">&amp;Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Measures the total length of all selected entities</source>
        <translation type="obsolete">Misst die totale Länge aller ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Polygo&amp;n (Cor,Cor)</source>
        <translation type="obsolete">Polygo&amp;n (2 Ecken)</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Entwurf</translation>
    </message>
    <message>
        <source>&amp;Draft</source>
        <translation>&amp;Entwurf</translation>
    </message>
    <message>
        <source>Enables/disables the draft mode</source>
        <translation>(De-)Aktiviert den Entwurfsmodus</translation>
    </message>
    <message>
        <source>Open IDE</source>
        <translation>IDE öffnen</translation>
    </message>
    <message>
        <source>&amp;Open IDE</source>
        <translation>&amp;IDE öffnen</translation>
    </message>
    <message>
        <source>Opens the integrated development environment for scripting</source>
        <translation>Öffnet die integrierte Entwicklungsumgebung für Skripte</translation>
    </message>
    <message>
        <source>Run Script..</source>
        <translation>Skript starten..</translation>
    </message>
    <message>
        <source>&amp;Run Script..</source>
        <translation>&amp;Skript starten..</translation>
    </message>
    <message>
        <source>Runs a script</source>
        <translation>Startet ein Skript</translation>
    </message>
    <message>
        <source>CAM Export</source>
        <translation type="obsolete">CAM Export</translation>
    </message>
    <message>
        <source>&amp;CAM Export..</source>
        <translation type="obsolete">&amp;CAM Export..</translation>
    </message>
    <message>
        <source>Exports the current drawing as CAM CNC program</source>
        <translation type="obsolete">Exportiert die aktuelle Zeichnung als CAM CNC Program</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Drucken...</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Beenden</translation>
    </message>
</context>
<context>
    <name>QG_ArcOptions</name>
    <message>
        <source>Arc Options</source>
        <translation>Bogen Optionen</translation>
    </message>
    <message>
        <source>Clockwise</source>
        <translation>Uhrzeigersinn</translation>
    </message>
    <message>
        <source>Counter Clockwise</source>
        <translation>Gegenuhrzeigersinn</translation>
    </message>
</context>
<context>
    <name>QG_ArcTangentialOptions</name>
    <message>
        <source>Tangential Arc Options</source>
        <translation>Optionen für tangentiale Bögen</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radius:</translation>
    </message>
</context>
<context>
    <name>QG_BevelOptions</name>
    <message>
        <source>Bevel Options</source>
        <translation>Abschrägen Optionen</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Trimmen</translation>
    </message>
    <message>
        <source>Check to trim both entities to the bevel</source>
        <translation>Beide Objekte zur Abschrägung trimmen</translation>
    </message>
    <message>
        <source>Length 1:</source>
        <translation>Länge 1:</translation>
    </message>
    <message>
        <source>Length 2:</source>
        <translation>Länge 2:</translation>
    </message>
</context>
<context>
    <name>QG_BlockDialog</name>
    <message>
        <source>Block Settings</source>
        <translation>Block Einstellungen</translation>
    </message>
    <message>
        <source>Block Name:</source>
        <translation>Block Name:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Renaming Block</source>
        <translation>Block umbenennen</translation>
    </message>
    <message>
        <source>Could not name block. A block named &quot;%1&quot; already exists.</source>
        <translation>Kann Block nicht benennen. Ein Block mit Name &quot;%1&quot; existiert bereits.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_BlockWidget</name>
    <message>
        <source>Block List</source>
        <translation type="obsolete">Block Liste</translation>
    </message>
    <message>
        <source>Add a block</source>
        <translation>Block hinzufügen</translation>
    </message>
    <message>
        <source>Remove the active block</source>
        <translation>Aktiven Block entfernen</translation>
    </message>
    <message>
        <source>Rename the active block</source>
        <translation>Aktiven Block umbenennen</translation>
    </message>
    <message>
        <source>Edit the active block
in a separate window</source>
        <translation>Aktiven Block in separatem
Fenster editieren</translation>
    </message>
    <message>
        <source>Insert the active block</source>
        <translation>Aktiven Block einfügen</translation>
    </message>
    <message>
        <source>Block Menu</source>
        <translation>Block Menu</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Blocks</source>
        <translation>Alle Blöcke &amp;auftauen</translation>
    </message>
    <message>
        <source>&amp;Freeze all Blocks</source>
        <translation>Alle Blöcke &amp;einfrieren</translation>
    </message>
    <message>
        <source>&amp;Add Block</source>
        <translation>Block &amp;hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Remove Block</source>
        <translation>Block &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Edit Block</source>
        <translation>Block &amp;editieren</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Sichtbarkeit umschalten</translation>
    </message>
    <message>
        <source>&amp;Create Block</source>
        <translation type="obsolete">&amp;Block erstellen</translation>
    </message>
    <message>
        <source>Show all blocks</source>
        <translation>Alle Blöcke anzeigen</translation>
    </message>
    <message>
        <source>Hide all blocks</source>
        <translation>Alle Blöcke verbergen</translation>
    </message>
    <message>
        <source>&amp;Rename Block</source>
        <translation>Block um&amp;benennen</translation>
    </message>
    <message>
        <source>&amp;Insert Block</source>
        <translation>Block ein&amp;fügen</translation>
    </message>
    <message>
        <source>&amp;Create New Block</source>
        <translation>&amp;Neuen Block erstellen</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBar</name>
    <message>
        <source>CAD Tools</source>
        <translation>CAD Tools</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarArcs</name>
    <message>
        <source>Arcs</source>
        <translation>Kreisbogen</translation>
    </message>
    <message>
        <source>Arc with three points</source>
        <translation>Kreisbogen mit drei Punkten</translation>
    </message>
    <message>
        <source>Parallel</source>
        <translation type="obsolete">Parallele</translation>
    </message>
    <message>
        <source>Arc with Center, Point, Angles</source>
        <translation>Kreisbogen mit Zentrum, Kreispunkt, Winkeln</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Konzentrisch</translation>
    </message>
    <message>
        <source>Arc tangential to base entity with radius</source>
        <translation>Bogen tangential zu Basiselement mit Radius</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarCircles</name>
    <message>
        <source>Circles</source>
        <translation>Kreise</translation>
    </message>
    <message>
        <source>Circle with distance to another circle</source>
        <translation type="obsolete">Kreis mit Abstand zu anderen Kreisen</translation>
    </message>
    <message>
        <source>Circle with two opposite points</source>
        <translation>Kreis mit zwei gegenüberliegenden Punkten</translation>
    </message>
    <message>
        <source>Circle with center and radius</source>
        <translation>Kreis mit Zentrum und Radius</translation>
    </message>
    <message>
        <source>Circle with center and point</source>
        <translation>Kreis mit Zentrum und Kreispunkt</translation>
    </message>
    <message>
        <source>Circle with three points</source>
        <translation>Kreis mit 3 Kreispunkten</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Concentric</source>
        <translation>Konzentrisch</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarDim</name>
    <message>
        <source>Dimensions</source>
        <translation>Bemassungen</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Diametric Dimension</source>
        <translation>Durchmesser Bemassung</translation>
    </message>
    <message>
        <source>Radial Dimension</source>
        <translation>Radiale Bemassung</translation>
    </message>
    <message>
        <source>Vertical Dimension</source>
        <translation>Vertikale Bemassung</translation>
    </message>
    <message>
        <source>Horizontal Dimension</source>
        <translation>Horizontale Bemassung</translation>
    </message>
    <message>
        <source>Linear Dimension</source>
        <translation>Lineare Bemassung</translation>
    </message>
    <message>
        <source>Aligned Dimension</source>
        <translation>Ausgerichtete Bemassung</translation>
    </message>
    <message>
        <source>Angular Dimension</source>
        <translation>Winkel Bemassung</translation>
    </message>
    <message>
        <source>Leader</source>
        <translation>Führung</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarEllipses</name>
    <message>
        <source>Ellipses</source>
        <translation>Ellipsen</translation>
    </message>
    <message>
        <source>Ellipse arc with center, two points and angles</source>
        <translation>Ellipsenbogen mit Zentrum, zwei Punkten und Winkeln</translation>
    </message>
    <message>
        <source>Ellipse with Center and two points</source>
        <translation>Ellipse mit Zentrum und zwei Punkten</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarInfo</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Distance (Point, Point)</source>
        <translation>Abstand (Punkt, Punkt)</translation>
    </message>
    <message>
        <source>Distance (Entity, Point)</source>
        <translation>Abstand (Objekt, Punkt)</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>Total length of selected entities</source>
        <translation>Totale Länge der ausgewählen Elemente</translation>
    </message>
    <message>
        <source>Area of polygon</source>
        <translation>Fläche eines Polygons</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarLines</name>
    <message>
        <source>Lines</source>
        <translation>Linen</translation>
    </message>
    <message>
        <source>Freehand lines</source>
        <translation>Freihand Linien</translation>
    </message>
    <message>
        <source>Orthogonal lines</source>
        <translation>Orthogonale Linien</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Bisectors</source>
        <translation>Winkelhalbierende</translation>
    </message>
    <message>
        <source>Tangents from circle to circle</source>
        <translation>Tangente von Kreis zu Kreis</translation>
    </message>
    <message>
        <source>Tangents from point to circle</source>
        <translation>Tangente von Punkt zu Kreis</translation>
    </message>
    <message>
        <source>Line with two points</source>
        <translation>Linie mit zwei Punkten</translation>
    </message>
    <message>
        <source>Lines with relative angles</source>
        <translation>Linie mit relativem Winkel</translation>
    </message>
    <message>
        <source>Line with given angle</source>
        <translation>Linie mit gegebenem Winkel</translation>
    </message>
    <message>
        <source>Horizontal lines</source>
        <translation>Horizontale Linien</translation>
    </message>
    <message>
        <source>Vertical lines</source>
        <translation>Vertikale Linien</translation>
    </message>
    <message>
        <source>Rectangles</source>
        <translation>Rechtecke</translation>
    </message>
    <message>
        <source>Polygons with Center and Corner</source>
        <translation>Polygone mit Zentrum und Ecke</translation>
    </message>
    <message>
        <source>Polygons with two Corners</source>
        <translation>Polygone mit zwei Ecken</translation>
    </message>
    <message>
        <source>Parallels with distance</source>
        <translation>Parallele mit Abstand</translation>
    </message>
    <message>
        <source>Parallels through point</source>
        <translation>Parallele durch Punkt</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarMain</name>
    <message>
        <source>Main</source>
        <translation>Haupt</translation>
    </message>
    <message>
        <source>Show menu &quot;Lines&quot;</source>
        <translation>Menu &quot;Linien&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Arcs&quot;</source>
        <translation>Menu &quot;Kreisbogen&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Circles&quot;</source>
        <translation>Menu &quot;Kreis&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Points&quot;</source>
        <translation type="obsolete">Menu &quot;Punkt&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Measure&quot;</source>
        <translation>Menu &quot;Messen&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Ellipses&quot;</source>
        <translation>Menu &quot;Ellipsen&quot; anzeigen</translation>
    </message>
    <message>
        <source>Hatches / Solid Fills</source>
        <translation>Schraffuren und Füllungen</translation>
    </message>
    <message>
        <source>Show menu &quot;Edit&quot;</source>
        <translation>Menu &quot;Edit&quot; anzeigen</translation>
    </message>
    <message>
        <source>Show menu &quot;Dimensions&quot;</source>
        <translation>Menu &quot;Bemassen&quot; anzeigen</translation>
    </message>
    <message>
        <source>Texts</source>
        <translation>Texte</translation>
    </message>
    <message>
        <source>Show menu &quot;Select&quot;</source>
        <translation>Menu &quot;Selektieren&quot; anzeigen</translation>
    </message>
    <message>
        <source>Create Block</source>
        <translation>Block erstellen</translation>
    </message>
    <message>
        <source>Raster Image</source>
        <translation>Raster Grafik</translation>
    </message>
    <message>
        <source>Show menu &quot;Splines&quot;</source>
        <translation type="obsolete">Menü &quot;Splines&quot; anzeigen</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Punkte</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>Splines</translation>
    </message>
    <message>
        <source>Polylines</source>
        <translation>Polylinien</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarModify</name>
    <message>
        <source>Modify</source>
        <translation>Modifizieren</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Rotieren</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Skalieren</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Verschieben</translation>
    </message>
    <message>
        <source>Move and Rotate</source>
        <translation>Verschieben und Rotieren</translation>
    </message>
    <message>
        <source>Explode</source>
        <translation>Aufbrechen</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Edit Entity Properties</source>
        <translation type="obsolete">Objekt Eigenschaften editieren</translation>
    </message>
    <message>
        <source>Stretch</source>
        <translation>Strecken</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Trennen</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Runden</translation>
    </message>
    <message>
        <source>Bevel</source>
        <translation>Abschrägen</translation>
    </message>
    <message>
        <source>Trim by amount</source>
        <translation>Um einen gegebenen Betrag trimmen</translation>
    </message>
    <message>
        <source>Trim / Extend two</source>
        <translation>Zwei Objekte trimmen</translation>
    </message>
    <message>
        <source>Trim / Extend</source>
        <translation>Objekte trimmen</translation>
    </message>
    <message>
        <source>Rotate around two centers</source>
        <translation>Objekte um zwei Zentren rotieren</translation>
    </message>
    <message>
        <source>Edit Entity Attributes</source>
        <translation>Objekt Attribute editieren</translation>
    </message>
    <message>
        <source>Edit Entity Geometry</source>
        <translation>Objekt Geometrie editieren</translation>
    </message>
    <message>
        <source>Mirror</source>
        <translation>Spiegeln</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Trennen</translation>
    </message>
    <message>
        <source>Explode Text into Letters</source>
        <translation>Text in Buchstaben aufbrechen</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Text editieren</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPoints</name>
    <message>
        <source>Points</source>
        <translation>Punkte</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Single points</source>
        <translation>Einzelne Punkte</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarPolylines</name>
    <message>
        <source>Polylines</source>
        <translation>Polylinien</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Create Polyline</source>
        <translation>Polylinien konstruieren</translation>
    </message>
    <message>
        <source>Delete between two nodes</source>
        <translation>Löschen zwischen zwei Knoten</translation>
    </message>
    <message>
        <source>Add node</source>
        <translation>Knoten hinzufügen</translation>
    </message>
    <message>
        <source>Delete node</source>
        <translation>Knoten löschen</translation>
    </message>
    <message>
        <source>Trim segments</source>
        <translation>Segmente trimmen</translation>
    </message>
    <message>
        <source>Append node</source>
        <translation>Knoten anfügen</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSelect</name>
    <message>
        <source>Select</source>
        <translation>Selektieren</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Alles selektieren</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Select intersected entities</source>
        <translation>Geschnittene Objekte selektieren</translation>
    </message>
    <message>
        <source>Deselect intersected entities</source>
        <translation>Geschnittene Objekte deselektieren</translation>
    </message>
    <message>
        <source>Deselect all</source>
        <translation>Deselektiert alle Objekte</translation>
    </message>
    <message>
        <source>Invert Selection</source>
        <translation>Selektion invertieren</translation>
    </message>
    <message>
        <source>Select layer</source>
        <translation>Layer (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Select contour</source>
        <translation>Kontur (de-)selektieren</translation>
    </message>
    <message>
        <source>(De-)Select entity</source>
        <translation>Objekte (de-)selektieren</translation>
    </message>
    <message>
        <source>Deselect Window</source>
        <translation>Bereich deselektieren</translation>
    </message>
    <message>
        <source>Select Window</source>
        <translation>Bereich selektieren</translation>
    </message>
    <message>
        <source>Continue action</source>
        <translation>Mit Tool fortfahren</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSnap</name>
    <message>
        <source>Snap</source>
        <translation>Fangen</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation>Rasterpunkte fangen</translation>
    </message>
    <message>
        <source>Free positioning</source>
        <translation>Freie positionierung</translation>
    </message>
    <message>
        <source>Snap to Endpoints</source>
        <translation>Endpunkte fangen</translation>
    </message>
    <message>
        <source>Snap to closest point on entity</source>
        <translation>Nächsten Punkt auf einem Objekt fangen</translation>
    </message>
    <message>
        <source>Snap to center points</source>
        <translation>Mittelpunkte fangen</translation>
    </message>
    <message>
        <source>Snap to middle points</source>
        <translation>Mittelpunkte fangen</translation>
    </message>
    <message>
        <source>Snap to point with given distance to endpoint</source>
        <translation>Punkt mit gegebenem Abstand zu einem Endpunkt fangen</translation>
    </message>
    <message>
        <source>Snap to intersections automatically</source>
        <translation>Schnittpunkte automatisch fangen</translation>
    </message>
    <message>
        <source>No Restriction</source>
        <translation>Keine Einschränkung</translation>
    </message>
    <message>
        <source>Orthogonal Restriction</source>
        <translation>Orthogonal einschränken</translation>
    </message>
    <message>
        <source>Horizontal Restriction</source>
        <translation>Horizontal einschränken</translation>
    </message>
    <message>
        <source>Vertical Restriction</source>
        <translation>Vertikal einschränken</translation>
    </message>
    <message>
        <source>Move relative Zero</source>
        <translation>Relativer Nullpunkt setzen</translation>
    </message>
    <message>
        <source>Lock relative Zero</source>
        <translation>Relativen Nullpunkt festhalten</translation>
    </message>
    <message>
        <source>Snap to intersections manually</source>
        <translation>Schnittpunkte manuell fangen</translation>
    </message>
</context>
<context>
    <name>QG_CadToolBarSplines</name>
    <message>
        <source>Splines</source>
        <translation>Splines</translation>
    </message>
    <message>
        <source>Back to main menu</source>
        <translation>Zurück zum Hauptmenü</translation>
    </message>
    <message>
        <source>Spline</source>
        <translation>Spline Kurve</translation>
    </message>
</context>
<context>
    <name>QG_CircleOptions</name>
    <message>
        <source>Circle Options</source>
        <translation>Kreis Optionen</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radius:</translation>
    </message>
</context>
<context>
    <name>QG_ColorBox</name>
    <message>
        <source>By Layer</source>
        <translation>Nach Layer</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Nach Block</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Gelb</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Cyan</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <source>Black / White</source>
        <translation>Schwarz / Weiss</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Grau</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Hellgrau</translation>
    </message>
    <message>
        <source>Others..</source>
        <translation>Andere..</translation>
    </message>
    <message>
        <source>Unchanged</source>
        <translation>Unverändert</translation>
    </message>
</context>
<context>
    <name>QG_CommandWidget</name>
    <message>
        <source>Command Line</source>
        <translation>Eingabezeile</translation>
    </message>
    <message>
        <source>Command:</source>
        <translation>Eingabe:</translation>
    </message>
</context>
<context>
    <name>QG_CoordinateWidget</name>
    <message>
        <source>Coordinates</source>
        <translation>Koordinaten</translation>
    </message>
</context>
<context>
    <name>QG_DimLinearOptions</name>
    <message>
        <source>Linear Dimension Options</source>
        <translation>Optionen für Lineare Bemassung</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
</context>
<context>
    <name>QG_DimOptions</name>
    <message>
        <source>Dimension Options</source>
        <translation>Optionen für Bemassung</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Text:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø</source>
        <translation>ø</translation>
    </message>
    <message encoding="UTF-8">
        <source>°</source>
        <translation>°</translation>
    </message>
    <message encoding="UTF-8">
        <source>±</source>
        <translation>±</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶</source>
        <translation>¶</translation>
    </message>
    <message encoding="UTF-8">
        <source>×</source>
        <translation>×</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷</source>
        <translation>÷</translation>
    </message>
</context>
<context>
    <name>QG_DimensionLabelEditor</name>
    <message>
        <source>Dimension Label Editor</source>
        <translation>Bemassungs Text Editor</translation>
    </message>
    <message>
        <source>Dimension Label:</source>
        <translation>Bemassungs Text:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Insert:</source>
        <translation>Einfügen:</translation>
    </message>
    <message encoding="UTF-8">
        <source>ø (Diameter)</source>
        <translation>ø (Durchmesser)</translation>
    </message>
    <message encoding="UTF-8">
        <source>° (Degree)</source>
        <translation>° (Grad)</translation>
    </message>
    <message encoding="UTF-8">
        <source>± (Plus / Minus)</source>
        <translation>± (Plus / Minus)</translation>
    </message>
    <message encoding="UTF-8">
        <source>¶ (Pi)</source>
        <translation>¶ (Pi)</translation>
    </message>
    <message encoding="UTF-8">
        <source>× (Times)</source>
        <translation>× (Mal)</translation>
    </message>
    <message encoding="UTF-8">
        <source>÷ (Division)</source>
        <translation>÷ (Division)</translation>
    </message>
</context>
<context>
    <name>QG_DlgArc</name>
    <message>
        <source>Arc</source>
        <translation>Kreisbogen</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radius:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Zentrum (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Zentrum (x):</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Startwinkel:</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Endwinkel:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Uhrzeigersinn</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgAttributes</name>
    <message>
        <source>Attributes</source>
        <translation>Attribute</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgCircle</name>
    <message>
        <source>Circle</source>
        <translation>Kreis</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radius:</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Zentrum (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Zentrum (x):</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgDimLinear</name>
    <message>
        <source>Linear Dimension</source>
        <translation>Lineare Bemassung</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgDimension</name>
    <message>
        <source>Aligned Dimension</source>
        <translation type="obsolete">Ausgerichtete Bemassung</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Dimension</source>
        <translation>Bemassung</translation>
    </message>
</context>
<context>
    <name>QG_DlgEllipse</name>
    <message>
        <source>Ellipse</source>
        <translation>Ellipse</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Center (y):</source>
        <translation>Zentrum (y):</translation>
    </message>
    <message>
        <source>Center (x):</source>
        <translation>Zentrum (x):</translation>
    </message>
    <message>
        <source>End Angle:</source>
        <translation>Endwinkel:</translation>
    </message>
    <message>
        <source>Start Angle:</source>
        <translation>Startwinkel:</translation>
    </message>
    <message>
        <source>Rotation:</source>
        <translation>Rotation:</translation>
    </message>
    <message>
        <source>Minor:</source>
        <translation>Minor:</translation>
    </message>
    <message>
        <source>Major:</source>
        <translation>Major:</translation>
    </message>
    <message>
        <source>Reversed</source>
        <translation>Uhrzeigersinn</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgHatch</name>
    <message>
        <source>Choose Hatch Attributes</source>
        <translation>Schraffurattribute wählen</translation>
    </message>
    <message>
        <source>Pattern</source>
        <translation>Muster</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Solid Fill</source>
        <translation>Solide Füllung</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <source>Enable Preview</source>
        <translation>Vorschau aktivieren</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>QG_DlgInitial</name>
    <message>
        <source>Welcome</source>
        <translation>Willkommen</translation>
    </message>
    <message>
        <source>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Welcome to QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Please choose the unit you want to use for new drawings and your preferred language.&lt;br&gt;
You can changes these settings later in the Options Dialog of QCad.</source>
        <translation>&lt;font size=&quot;+1&quot;&gt;&lt;b&gt;Willkommen in QCad&lt;/b&gt;
&lt;/font&gt;
&lt;br&gt;
Bitte wählen Sie die Masseinheit, die Sie für neue Zeichnungen verwenden wollen und Ihre bevorzugte Sprache.&lt;br&gt;
Sie können diese Einstellungen auch später im Optionen Dialog von QCad ändern.</translation>
    </message>
    <message>
        <source>Default Unit:</source>
        <translation>Standard Einheit:</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation>GUI Sprache:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation>Kommando Sprache:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="obsolete">&amp;OK</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgInsert</name>
    <message>
        <source>Insert</source>
        <translation>Einfügung</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Insertion point (x):</source>
        <translation>Einfügepunkt (x):</translation>
    </message>
    <message>
        <source>Insertion point (y):</source>
        <translation>Einfügepunkt (y):</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Reihen:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Spalten:</translation>
    </message>
    <message>
        <source>Row Spacing:</source>
        <translation>Reihenabstand:</translation>
    </message>
    <message>
        <source>Column Spacing:</source>
        <translation>Spaltenabstand:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgLine</name>
    <message>
        <source>Line</source>
        <translation>Linie</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>End point (x):</source>
        <translation>Endpunkt (x):</translation>
    </message>
    <message>
        <source>End point (y):</source>
        <translation>Endpunkt (y):</translation>
    </message>
    <message>
        <source>Start point (y):</source>
        <translation>Startpunkt (y):</translation>
    </message>
    <message>
        <source>Start point (x):</source>
        <translation>Startpunkt (x):</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgMirror</name>
    <message>
        <source>Mirroring Options</source>
        <translation>Optionen für Spiegeln</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgMove</name>
    <message>
        <source>Moving Options</source>
        <translation>Objekte verschieben</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Multiple Copies</source>
        <translation type="obsolete">Mehrfache Kopien</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Mehrere Kopien</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgMoveRotate</name>
    <message>
        <source>Move/Rotate Options</source>
        <translation>Optionen für Verschieben / Rotieren</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Angle (a):</source>
        <translation type="obsolete">Winkel (a):</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Multiple Copies</source>
        <translation type="obsolete">Mehrfache Kopien</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Winkel (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Mehrere Kopien</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsDrawing</name>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Einstellungen</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="obsolete">Querformat</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation type="obsolete">Hochformat</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="obsolete">Einheiten</translation>
    </message>
    <message>
        <source>Main Unit</source>
        <translation>Haupt Einheit</translation>
    </message>
    <message>
        <source>Main drawing unit:</source>
        <translation type="obsolete">Haupt Masseinheit:</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Dezimal</translation>
    </message>
    <message>
        <source>Scientific</source>
        <translation>Wissenschaftlich</translation>
    </message>
    <message>
        <source>Engineering</source>
        <translation>Technisch</translation>
    </message>
    <message>
        <source>Architectural</source>
        <translation>Architektur</translation>
    </message>
    <message>
        <source>Fractional</source>
        <translation>Bruchdarstellung</translation>
    </message>
    <message>
        <source>Precision:</source>
        <translation type="obsolete">Präzision:</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>Decimal Degrees</source>
        <translation>Dezimal Grad</translation>
    </message>
    <message>
        <source>Radians</source>
        <translation>Radiant</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <source>linear</source>
        <translation>linear</translation>
    </message>
    <message>
        <source>angular</source>
        <translation>winkel</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Raster</translation>
    </message>
    <message>
        <source>Dimensions</source>
        <translation type="obsolete">Bemassungen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation type="obsolete">Papier</translation>
    </message>
    <message>
        <source>Paper Format</source>
        <translation>Papier Format</translation>
    </message>
    <message>
        <source>Paper Height:</source>
        <translation type="obsolete">Papier Höhe:</translation>
    </message>
    <message>
        <source>Paper Width:</source>
        <translation type="obsolete">Papier Breite:</translation>
    </message>
    <message>
        <source>Format:</source>
        <translation type="obsolete">Format:</translation>
    </message>
    <message>
        <source>Text Height:</source>
        <translation>Text Höhe:</translation>
    </message>
    <message>
        <source>units</source>
        <translation>einheiten</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>Deg/min/sec</source>
        <translation>Grad/Min/sec</translation>
    </message>
    <message>
        <source>Gradians</source>
        <translation>Gradianten</translation>
    </message>
    <message>
        <source>Surveyor&apos;s units</source>
        <translation>Vermessung</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <source>For the length formats &apos;Engineering&apos; and &apos;Architectural&apos;, the unit must be set to Inch.</source>
        <translation>Für die Formatierungen &apos;Technisch&apos; und &apos;Architektur&apos; muss die Masseinheit auf Inch gesetzt sein.</translation>
    </message>
    <message>
        <source>Extension line extension:</source>
        <translation>Verlängerung der Bemassungslinie:</translation>
    </message>
    <message>
        <source>Arrow size:</source>
        <translation>Pfeil Grösse:</translation>
    </message>
    <message>
        <source>Extension line gap:</source>
        <translation type="obsolete">Bemassungslinien Abstand:</translation>
    </message>
    <message>
        <source>Extension line offset:</source>
        <translation>Bemasungslinien Offset:</translation>
    </message>
    <message>
        <source>Dimension line gap:</source>
        <translation>Bemassungslinien Abstand:</translation>
    </message>
    <message>
        <source>Drawing Preferences</source>
        <translation>Zeichnungs Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Paper</source>
        <translation>&amp;Papier</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>&amp;Quer</translation>
    </message>
    <message>
        <source>P&amp;ortrait</source>
        <translation>&amp;Hoch</translation>
    </message>
    <message>
        <source>Paper &amp;Height:</source>
        <translation>Papier &amp;Höhe:</translation>
    </message>
    <message>
        <source>Paper &amp;Width:</source>
        <translation>Papier &amp;Breite:</translation>
    </message>
    <message>
        <source>&amp;Units</source>
        <translation>&amp;Einheiten</translation>
    </message>
    <message>
        <source>&amp;Main drawing unit:</source>
        <translation>&amp;Haupteinheit:</translation>
    </message>
    <message>
        <source>&amp;Format:</source>
        <translation>&amp;Format:</translation>
    </message>
    <message>
        <source>P&amp;recision:</source>
        <translation>&amp;Genauigkeit:</translation>
    </message>
    <message>
        <source>F&amp;ormat:</source>
        <translation>F&amp;ormat:</translation>
    </message>
    <message>
        <source>Pre&amp;cision:</source>
        <translation>&amp;Genauigkeit:</translation>
    </message>
    <message>
        <source>&amp;Dimensions</source>
        <translation>&amp;Bemassungen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Grid Settings</source>
        <translation>Raster Einstellungen</translation>
    </message>
    <message>
        <source>Show Grid</source>
        <translation>Raster anzeigen</translation>
    </message>
    <message>
        <source>X Spacing:</source>
        <translation>X Abstand:</translation>
    </message>
    <message>
        <source>Y Spacing:</source>
        <translation>Y Abstand:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>&amp;Grid</source>
        <translation>&amp;Raster</translation>
    </message>
    <message>
        <source>Splines</source>
        <translation>Splines</translation>
    </message>
    <message>
        <source>Number of line segments per spline patch:</source>
        <translation>Anzahl Linien-Segmente pro Spline Abschnitt:</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>16</source>
        <translation>16</translation>
    </message>
    <message>
        <source>32</source>
        <translation>32</translation>
    </message>
    <message>
        <source>64</source>
        <translation>64</translation>
    </message>
    <message>
        <source>0.01</source>
        <translation>0.01</translation>
    </message>
    <message>
        <source>0.1</source>
        <translation>0.1</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
</context>
<context>
    <name>QG_DlgOptionsGeneral</name>
    <message>
        <source>Preferences</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Erscheinung</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="obsolete">Pfade</translation>
    </message>
    <message>
        <source>Translations:</source>
        <translation>Übersetzungen:</translation>
    </message>
    <message>
        <source>Hatch Patterns:</source>
        <translation>Schraffur Muster:</translation>
    </message>
    <message>
        <source>Fonts:</source>
        <translation>Schriften:</translation>
    </message>
    <message>
        <source>Scripts:</source>
        <translation>Scripts:</translation>
    </message>
    <message>
        <source>Part Libraries:</source>
        <translation>Teile Bibliotheken:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>GUI Language:</source>
        <translation type="obsolete">GUI Sprache:</translation>
    </message>
    <message>
        <source>Command Language:</source>
        <translation type="obsolete">Kommando Sprache:</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Graphic View</source>
        <translation>Grafische Ansicht</translation>
    </message>
    <message>
        <source>Show large crosshairs</source>
        <translation type="obsolete">Grosses Fadenkreuz</translation>
    </message>
    <message>
        <source>Number of preview entities:</source>
        <translation type="obsolete">Anzahl Vorschau Elemente:</translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>50</source>
        <translation></translation>
    </message>
    <message>
        <source>100</source>
        <translation></translation>
    </message>
    <message>
        <source>200</source>
        <translation></translation>
    </message>
    <message>
        <source>Please restart QCad to apply all changes.</source>
        <translation type="obsolete">Bitte starten Sie QCad neu, um alle Änderungen zu aktivieren.</translation>
    </message>
    <message>
        <source>Application Preferences</source>
        <translation>Applikations Einstellungen</translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="obsolete">Standards</translation>
    </message>
    <message>
        <source>Defaults for new drawings</source>
        <translation>Standards für neue Zeichnungen</translation>
    </message>
    <message>
        <source>Unit:</source>
        <translation type="obsolete">Einheit:</translation>
    </message>
    <message>
        <source>&amp;Appearance</source>
        <translation>&amp;Erscheinung</translation>
    </message>
    <message>
        <source>&amp;GUI Language:</source>
        <translation>&amp;GUI Sprache:</translation>
    </message>
    <message>
        <source>&amp;Command Language:</source>
        <translation>&amp;Kommando Sprache:</translation>
    </message>
    <message>
        <source>&amp;Show large crosshairs</source>
        <translation>Grosses &amp;Fadenkreuz</translation>
    </message>
    <message>
        <source>Number of p&amp;review entities:</source>
        <translation>Anzahl Objekte für &amp;Vorschau:</translation>
    </message>
    <message>
        <source>&amp;Paths</source>
        <translation>&amp;Pfade</translation>
    </message>
    <message>
        <source>&amp;Defaults</source>
        <translation>&amp;Standards</translation>
    </message>
    <message>
        <source>&amp;Unit:</source>
        <translation>&amp;Einheit:</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
    <message>
        <source>Backgr&amp;ound:</source>
        <translation>&amp;Hintergrund:</translation>
    </message>
    <message>
        <source>G&amp;rid Color:</source>
        <translation>&amp;Raster Farbe:</translation>
    </message>
    <message>
        <source>&amp;Meta Grid Color:</source>
        <translation>&amp;Meta Raster Farbe:</translation>
    </message>
    <message>
        <source>#404040</source>
        <translation></translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation>Schriftgrösse</translation>
    </message>
    <message>
        <source>Statusbar:</source>
        <translation>Statuszeile:</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <source>10</source>
        <translation></translation>
    </message>
    <message>
        <source>11</source>
        <translation></translation>
    </message>
    <message>
        <source>12</source>
        <translation>12</translation>
    </message>
    <message>
        <source>14</source>
        <translation>14</translation>
    </message>
    <message>
        <source>#000000</source>
        <translation></translation>
    </message>
    <message>
        <source>#ffffff</source>
        <translation></translation>
    </message>
    <message>
        <source>#c0c0c0</source>
        <translation></translation>
    </message>
    <message>
        <source>#808080</source>
        <translation></translation>
    </message>
    <message>
        <source>A&amp;utomatically scale grid</source>
        <translation>Raster a&amp;utomatisch skalieren</translation>
    </message>
    <message>
        <source>S&amp;elected Color:</source>
        <translation>S&amp;elektierte Objekte:</translation>
    </message>
    <message>
        <source>#a54747</source>
        <translation></translation>
    </message>
    <message>
        <source>#739373</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Highlighted Color:</source>
        <translation>&amp;Hervorgehobene Farbe:</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing:</source>
        <translation type="obsolete">Minimaler Raster Abstand:</translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>15</source>
        <translation></translation>
    </message>
    <message>
        <source>20</source>
        <translation></translation>
    </message>
    <message>
        <source>Please restart the application to apply all changes.</source>
        <translation>Bitte starten Sie die Applikation neu um alle Änderungen zu übernehmen.</translation>
    </message>
    <message>
        <source>Alt+S</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <source>Minimal Grid Spacing (px):</source>
        <translation>Minimaler Rasterabstand (pix):</translation>
    </message>
</context>
<context>
    <name>QG_DlgPoint</name>
    <message>
        <source>Point</source>
        <translation>Punkt</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Position (y):</source>
        <translation>Position (y):</translation>
    </message>
    <message>
        <source>Position (x):</source>
        <translation>Position (x):</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate</name>
    <message>
        <source>Rotation Options</source>
        <translation>Optionen für Rotieren</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Multiple Copies:</source>
        <translation type="obsolete">Mehrfache Kopien:</translation>
    </message>
    <message>
        <source>Angle (a):</source>
        <translation type="obsolete">Winkel (a):</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies:</source>
        <translation>&amp;Mehrere Kopien:</translation>
    </message>
    <message>
        <source>&amp;Angle (a):</source>
        <translation>&amp;Winkel (a):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
</context>
<context>
    <name>QG_DlgRotate2</name>
    <message>
        <source>Rotate Two Options</source>
        <translation>Optionen für Rotieren Zwei</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Multiple Copies</source>
        <translation type="obsolete">Mehrfache Kopien</translation>
    </message>
    <message>
        <source>Angle (a):</source>
        <translation type="obsolete">Winkel (a):</translation>
    </message>
    <message>
        <source>Angle (b):</source>
        <translation type="obsolete">Winkel (b):</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Mehrere Kopien</translation>
    </message>
    <message>
        <source>Angle (&amp;a):</source>
        <translation>&amp;Winkel (a):</translation>
    </message>
    <message>
        <source>Angle (&amp;b):</source>
        <translation>&amp;Winkel (b):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
</context>
<context>
    <name>QG_DlgScale</name>
    <message>
        <source>Scaling Options</source>
        <translation>Optionen für Skalieren</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <source>Delete Original</source>
        <translation type="obsolete">Original löschen</translation>
    </message>
    <message>
        <source>Keep Original</source>
        <translation type="obsolete">Original behalten</translation>
    </message>
    <message>
        <source>Multiple Copies</source>
        <translation type="obsolete">Mehrfache Kopien</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Abbrechen</translation>
    </message>
    <message>
        <source>Factor (f):</source>
        <translation type="obsolete">Faktor (f):</translation>
    </message>
    <message>
        <source>Use current attributes</source>
        <translation type="obsolete">Aktuelle Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current layer</source>
        <translation type="obsolete">Aktuellen Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Factor (f):</source>
        <translation>&amp;Faktor (f):</translation>
    </message>
    <message>
        <source>Use current &amp;attributes</source>
        <translation>Aktuelle &amp;Attribute verwenden</translation>
    </message>
    <message>
        <source>Use current &amp;layer</source>
        <translation>Aktuellen &amp;Layer verwenden</translation>
    </message>
    <message>
        <source>&amp;Delete Original</source>
        <translation>Original &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Keep Original</source>
        <translation>Original &amp;beibehalten</translation>
    </message>
    <message>
        <source>&amp;Multiple Copies</source>
        <translation>&amp;Mehrere Kopien</translation>
    </message>
</context>
<context>
    <name>QG_DlgSpline</name>
    <message>
        <source>Spline</source>
        <translation>Spline Kurve</translation>
    </message>
    <message>
        <source>Layer:</source>
        <translation>Layer:</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometrie</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>Grad:</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>Geschlossen</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>QG_DlgText</name>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Clear Text</source>
        <translation>Text löschen</translation>
    </message>
    <message>
        <source>Load Text From File</source>
        <translation>Text von Datei laden</translation>
    </message>
    <message>
        <source>Save Text To File</source>
        <translation>Text in Datei ablegen</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Schrift</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="obsolete">Höhe:</translation>
    </message>
    <message>
        <source>Line spacing:</source>
        <translation type="obsolete">Linienabstand:</translation>
    </message>
    <message>
        <source>Default line spacing</source>
        <translation type="obsolete">Standard Linienabstand</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Ausrichtung</translation>
    </message>
    <message>
        <source>Top Right</source>
        <translation>Oben rechts</translation>
    </message>
    <message>
        <source>Top Left</source>
        <translation>Open links</translation>
    </message>
    <message>
        <source>Middle Left</source>
        <translation>Mitte links</translation>
    </message>
    <message>
        <source>Middle Center</source>
        <translation>Mitte zentriert</translation>
    </message>
    <message>
        <source>Middle Right</source>
        <translation>Mitte rechts</translation>
    </message>
    <message>
        <source>Bottom Left</source>
        <translation>Unten links</translation>
    </message>
    <message>
        <source>Bottom Right</source>
        <translation>Unten rechts</translation>
    </message>
    <message>
        <source>Bottom Center</source>
        <translation>Unten zentriert</translation>
    </message>
    <message>
        <source>Top Center</source>
        <translation>Oben zentriert</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation>Symbol einfügen</translation>
    </message>
    <message encoding="UTF-8">
        <source>Diameter (ø)</source>
        <translation>Durchmesser (ø)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Degree (°)</source>
        <translation>Grad (°)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Plus / Minus (±)</source>
        <translation>Plus / Minus (±)</translation>
    </message>
    <message>
        <source>At (@)</source>
        <translation>At (@)</translation>
    </message>
    <message>
        <source>Hash (#)</source>
        <translation>Hash (#)</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dollar ($)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (©)</source>
        <translation>Copyright (©)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Registered (®)</source>
        <translation>Registriert (®)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Paragraph (§)</source>
        <translation>Paragraph (§)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi (¶)</source>
        <translation>Pi (¶)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Pound (£)</source>
        <translation>Pfund (£)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Yen (¥)</source>
        <translation>Yen (¥)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Times (×)</source>
        <translation>Mal (×)</translation>
    </message>
    <message encoding="UTF-8">
        <source>Division (÷)</source>
        <translation>Division (÷)</translation>
    </message>
    <message>
        <source>Insert Unicode</source>
        <translation>Unicode einfügen</translation>
    </message>
    <message>
        <source>Page:</source>
        <translation>Seite:</translation>
    </message>
    <message>
        <source>Char:</source>
        <translation>Zeichen:</translation>
    </message>
    <message>
        <source>[0000-007F] Basic Latin</source>
        <translation></translation>
    </message>
    <message>
        <source>[0080-00FF] Latin-1 Supplementary</source>
        <translation></translation>
    </message>
    <message>
        <source>[0100-017F] Latin Extended-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[0180-024F] Latin Extended-B</source>
        <translation></translation>
    </message>
    <message>
        <source>[0250-02AF] IPA Extensions</source>
        <translation></translation>
    </message>
    <message>
        <source>[02B0-02FF] Spacing Modifier Letters</source>
        <translation></translation>
    </message>
    <message>
        <source>[0300-036F] Combining Diacritical Marks</source>
        <translation></translation>
    </message>
    <message>
        <source>[0370-03FF] Greek and Coptic</source>
        <translation></translation>
    </message>
    <message>
        <source>[0400-04FF] Cyrillic</source>
        <translation></translation>
    </message>
    <message>
        <source>[0500-052F] Cyrillic Supplementary</source>
        <translation></translation>
    </message>
    <message>
        <source>[0530-058F] Armenian</source>
        <translation></translation>
    </message>
    <message>
        <source>[0590-05FF] Hebrew</source>
        <translation></translation>
    </message>
    <message>
        <source>[0600-06FF] Arabic</source>
        <translation></translation>
    </message>
    <message>
        <source>[0700-074F] Syriac</source>
        <translation></translation>
    </message>
    <message>
        <source>[0780-07BF] Thaana</source>
        <translation></translation>
    </message>
    <message>
        <source>[0900-097F] Devanagari</source>
        <translation></translation>
    </message>
    <message>
        <source>[0980-09FF] Bengali</source>
        <translation></translation>
    </message>
    <message>
        <source>[0A00-0A7F] Gurmukhi</source>
        <translation></translation>
    </message>
    <message>
        <source>[0A80-0AFF] Gujarati</source>
        <translation></translation>
    </message>
    <message>
        <source>[0B00-0B7F] Oriya</source>
        <translation></translation>
    </message>
    <message>
        <source>[0B80-0BFF] Tamil</source>
        <translation></translation>
    </message>
    <message>
        <source>[0C00-0C7F] Telugu</source>
        <translation></translation>
    </message>
    <message>
        <source>[0C80-0CFF] Kannada</source>
        <translation></translation>
    </message>
    <message>
        <source>[0D00-0D7F] Malayalam</source>
        <translation></translation>
    </message>
    <message>
        <source>[0D80-0DFF] Sinhala</source>
        <translation></translation>
    </message>
    <message>
        <source>[0E00-0E7F] Thai</source>
        <translation></translation>
    </message>
    <message>
        <source>[0E80-0EFF] Lao</source>
        <translation></translation>
    </message>
    <message>
        <source>[0F00-0FFF] Tibetan</source>
        <translation></translation>
    </message>
    <message>
        <source>[1000-109F] Myanmar</source>
        <translation></translation>
    </message>
    <message>
        <source>[10A0-10FF] Georgian</source>
        <translation></translation>
    </message>
    <message>
        <source>[1100-11FF] Hangul Jamo</source>
        <translation></translation>
    </message>
    <message>
        <source>[1200-137F] Ethiopic</source>
        <translation></translation>
    </message>
    <message>
        <source>[13A0-13FF] Cherokee</source>
        <translation></translation>
    </message>
    <message>
        <source>[1400-167F] Unified Canadian Aboriginal Syllabic</source>
        <translation></translation>
    </message>
    <message>
        <source>[1680-169F] Ogham</source>
        <translation></translation>
    </message>
    <message>
        <source>[16A0-16FF] Runic</source>
        <translation></translation>
    </message>
    <message>
        <source>[1700-171F] Tagalog</source>
        <translation></translation>
    </message>
    <message>
        <source>[1720-173F] Hanunoo</source>
        <translation></translation>
    </message>
    <message>
        <source>[1740-175F] Buhid</source>
        <translation></translation>
    </message>
    <message>
        <source>[1760-177F] Tagbanwa</source>
        <translation></translation>
    </message>
    <message>
        <source>[1780-17FF] Khmer</source>
        <translation></translation>
    </message>
    <message>
        <source>[1800-18AF] Mongolian</source>
        <translation></translation>
    </message>
    <message>
        <source>[1E00-1EFF] Latin Extended Additional</source>
        <translation></translation>
    </message>
    <message>
        <source>[1F00-1FFF] Greek Extended</source>
        <translation></translation>
    </message>
    <message>
        <source>[2000-206F] General Punctuation</source>
        <translation></translation>
    </message>
    <message>
        <source>[2070-209F] Superscripts and Subscripts</source>
        <translation></translation>
    </message>
    <message>
        <source>[20A0-20CF] Currency Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[20D0-20FF] Combining Marks for Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[2100-214F] Letterlike Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[2150-218F] Number Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[2190-21FF] Arrows</source>
        <translation></translation>
    </message>
    <message>
        <source>[2200-22FF] Mathematical Operators</source>
        <translation></translation>
    </message>
    <message>
        <source>[2300-23FF] Miscellaneous Technical</source>
        <translation></translation>
    </message>
    <message>
        <source>[2400-243F] Control Pictures</source>
        <translation></translation>
    </message>
    <message>
        <source>[2440-245F] Optical Character Recognition</source>
        <translation></translation>
    </message>
    <message>
        <source>[2460-24FF] Enclosed Alphanumerics</source>
        <translation></translation>
    </message>
    <message>
        <source>[2500-257F] Box Drawing</source>
        <translation></translation>
    </message>
    <message>
        <source>[2580-259F] Block Elements</source>
        <translation></translation>
    </message>
    <message>
        <source>[25A0-25FF] Geometric Shapes</source>
        <translation></translation>
    </message>
    <message>
        <source>[2600-26FF] Miscellaneous Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[2700-27BF] Dingbats</source>
        <translation></translation>
    </message>
    <message>
        <source>[27C0-27EF] Miscellaneous Mathematical Symbols-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[27F0-27FF] Supplemental Arrows-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[2800-28FF] Braille Patterns</source>
        <translation></translation>
    </message>
    <message>
        <source>[2900-297F] Supplemental Arrows-B</source>
        <translation></translation>
    </message>
    <message>
        <source>[2980-29FF] Miscellaneous Mathematical Symbols-B</source>
        <translation></translation>
    </message>
    <message>
        <source>[2A00-2AFF] Supplemental Mathematical Operators</source>
        <translation></translation>
    </message>
    <message>
        <source>[2E80-2EFF] CJK Radicals Supplement</source>
        <translation></translation>
    </message>
    <message>
        <source>[2F00-2FDF] Kangxi Radicals</source>
        <translation></translation>
    </message>
    <message>
        <source>[2FF0-2FFF] Ideographic Description Characters</source>
        <translation></translation>
    </message>
    <message>
        <source>[3000-303F] CJK Symbols and Punctuation</source>
        <translation></translation>
    </message>
    <message>
        <source>[3040-309F] Hiragana</source>
        <translation></translation>
    </message>
    <message>
        <source>[30A0-30FF] Katakana</source>
        <translation></translation>
    </message>
    <message>
        <source>[3100-312F] Bopomofo</source>
        <translation></translation>
    </message>
    <message>
        <source>[3130-318F] Hangul Compatibility Jamo</source>
        <translation></translation>
    </message>
    <message>
        <source>[3190-319F] Kanbun</source>
        <translation></translation>
    </message>
    <message>
        <source>[31A0-31BF] Bopomofo Extended</source>
        <translation></translation>
    </message>
    <message>
        <source>[3200-32FF] Enclosed CJK Letters and Months</source>
        <translation></translation>
    </message>
    <message>
        <source>[3300-33FF] CJK Compatibility</source>
        <translation></translation>
    </message>
    <message>
        <source>[3400-4DBF] CJK Unified Ideographs Extension A</source>
        <translation></translation>
    </message>
    <message>
        <source>[4E00-9FAF] CJK Unified Ideographs</source>
        <translation></translation>
    </message>
    <message>
        <source>[A000-A48F] Yi Syllables</source>
        <translation></translation>
    </message>
    <message>
        <source>[A490-A4CF] Yi Radicals</source>
        <translation></translation>
    </message>
    <message>
        <source>[AC00-D7AF] Hangul Syllables</source>
        <translation></translation>
    </message>
    <message>
        <source>[D800-DBFF] High Surrogates</source>
        <translation></translation>
    </message>
    <message>
        <source>[DC00-DFFF] Low Surrogate Area</source>
        <translation></translation>
    </message>
    <message>
        <source>[E000-F8FF] Private Use Area</source>
        <translation></translation>
    </message>
    <message>
        <source>[F900-FAFF] CJK Compatibility Ideographs</source>
        <translation></translation>
    </message>
    <message>
        <source>[FB00-FB4F] Alphabetic Presentation Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[FB50-FDFF] Arabic Presentation Forms-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE00-FE0F] Variation Selectors</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE20-FE2F] Combining Half Marks</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE30-FE4F] CJK Compatibility Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE50-FE6F] Small Form Variants</source>
        <translation></translation>
    </message>
    <message>
        <source>[FE70-FEFF] Arabic Presentation Forms-B</source>
        <translation></translation>
    </message>
    <message>
        <source>[FF00-FFEF] Halfwidth and Fullwidth Forms</source>
        <translation></translation>
    </message>
    <message>
        <source>[FFF0-FFFF] Specials</source>
        <translation></translation>
    </message>
    <message>
        <source>[10300-1032F] Old Italic</source>
        <translation></translation>
    </message>
    <message>
        <source>[10330-1034F] Gothic</source>
        <translation></translation>
    </message>
    <message>
        <source>[10400-1044F] Deseret</source>
        <translation></translation>
    </message>
    <message>
        <source>[1D000-1D0FF] Byzantine Musical Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[1D100-1D1FF] Musical Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[1D400-1D7FF] Mathematical Alphanumeric Symbols</source>
        <translation></translation>
    </message>
    <message>
        <source>[20000-2A6DF] CJK Unified Ideographs Extension B</source>
        <translation></translation>
    </message>
    <message>
        <source>[2F800-2FA1F] CJK Compatibility Ideographs Supplement</source>
        <translation></translation>
    </message>
    <message>
        <source>[E0000-E007F] Tags</source>
        <translation></translation>
    </message>
    <message>
        <source>[F0000-FFFFD] Supplementary Private Use Area-A</source>
        <translation></translation>
    </message>
    <message>
        <source>[100000-10FFFD] Supplementary Private Use Area-B</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Height:</source>
        <translation>&amp;Höhe:</translation>
    </message>
    <message>
        <source>Line &amp;spacing:</source>
        <translation>Linien&amp;abstand:</translation>
    </message>
    <message>
        <source>&amp;Default line spacing</source>
        <translation>&amp;Standard Linienabstand</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation>Alt+D</translation>
    </message>
</context>
<context>
    <name>QG_ExitDialog</name>
    <message>
        <source>Exit Application</source>
        <translation type="obsolete">Applikation beenden</translation>
    </message>
    <message>
        <source>&amp;Discard</source>
        <translation type="obsolete">&amp;Verwerfen</translation>
    </message>
    <message>
        <source>Alt+D</source>
        <translation type="obsolete">Alt+V</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Speichern</translation>
    </message>
    <message>
        <source>Save &amp;As..</source>
        <translation>Speichern &amp;unter..</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="obsolete">Alt+A</translation>
    </message>
    <message>
        <source>No Text supplied.</source>
        <translation>Kein Text eingegeben.</translation>
    </message>
    <message>
        <source>QCad</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="obsolete">Sc&amp;hliessen</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Sc&amp;hliessen</translation>
    </message>
    <message>
        <source>Alt+L</source>
        <translation type="obsolete">Alt-H</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Insert Optionen</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Rotationswinkel</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Skalierfaktor</translation>
    </message>
</context>
<context>
    <name>QG_ImageOptionsDialog</name>
    <message>
        <source>Image Export Options</source>
        <translation>Bild Export Optionen</translation>
    </message>
    <message>
        <source>Bitmap Size</source>
        <translation>Bitmap Grösse</translation>
    </message>
    <message>
        <source>640</source>
        <translation></translation>
    </message>
    <message>
        <source>480</source>
        <translation></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Breite:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Höhe:</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Hintergrund</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Weiss</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Schwarz</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Auflösung:</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>10</source>
        <translation></translation>
    </message>
    <message>
        <source>15</source>
        <translation></translation>
    </message>
    <message>
        <source>20</source>
        <translation></translation>
    </message>
    <message>
        <source>25</source>
        <translation></translation>
    </message>
    <message>
        <source>50</source>
        <translation></translation>
    </message>
    <message>
        <source>75</source>
        <translation></translation>
    </message>
    <message>
        <source>100</source>
        <translation></translation>
    </message>
    <message>
        <source>150</source>
        <translation></translation>
    </message>
    <message>
        <source>300</source>
        <translation></translation>
    </message>
    <message>
        <source>600</source>
        <translation></translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
</context>
<context>
    <name>QG_InsertOptions</name>
    <message>
        <source>Insert Options</source>
        <translation>Insert Optionen</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Rotationswinkel</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Skalierfaktor</translation>
    </message>
    <message>
        <source>Array:</source>
        <translation>Array:</translation>
    </message>
    <message>
        <source>Number of Columns</source>
        <translation>Anzahl spalten</translation>
    </message>
    <message>
        <source>Number of Rows</source>
        <translation>Anzahl Reichen</translation>
    </message>
    <message>
        <source>Spacing:</source>
        <translation>Abstand:</translation>
    </message>
    <message>
        <source>Column Spacing</source>
        <translation>Spaltenabstand</translation>
    </message>
    <message>
        <source>Row Spacing</source>
        <translation>Reihenabstand</translation>
    </message>
</context>
<context>
    <name>QG_LayerBox</name>
    <message>
        <source>- Unchanged -</source>
        <translation>- Unverändert -</translation>
    </message>
</context>
<context>
    <name>QG_LayerDialog</name>
    <message>
        <source>Layer Settings</source>
        <translation>Layer Einstellungen</translation>
    </message>
    <message>
        <source>Layer Name:</source>
        <translation>Layer Name:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Default Pen</source>
        <translation>Standard Stift</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Alt+O</source>
        <translation></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QG_LayerWidget</name>
    <message>
        <source>Layer List</source>
        <translation type="obsolete">Layer Liste</translation>
    </message>
    <message>
        <source>Show all layers</source>
        <translation>Alle Layer anzeigen</translation>
    </message>
    <message>
        <source>Hide all layers</source>
        <translation>Alle Layer verbergen</translation>
    </message>
    <message>
        <source>Add a layer</source>
        <translation>Layer hinzufügen</translation>
    </message>
    <message>
        <source>Remove the current layer</source>
        <translation>Aktuellen Layer entfernen</translation>
    </message>
    <message>
        <source>Modify layer attributes / rename</source>
        <translation>Layer Attribute editieren / umbenennen</translation>
    </message>
    <message>
        <source>Layer Menu</source>
        <translation>Layer Menu</translation>
    </message>
    <message>
        <source>&amp;Defreeze all Layers</source>
        <translation>Alle Layer &amp;auftauen</translation>
    </message>
    <message>
        <source>&amp;Freeze all Layers</source>
        <translation>Alle Layer &amp;einfrieren</translation>
    </message>
    <message>
        <source>&amp;Add Layer</source>
        <translation>Layer &amp;hinzufügen</translation>
    </message>
    <message>
        <source>&amp;Remove Layer</source>
        <translation>Layer &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Edit Layer</source>
        <translation>Layer&amp;attribute ändern</translation>
    </message>
    <message>
        <source>&amp;Toggle Visibility</source>
        <translation>&amp;Sichtbarkeit umschalten</translation>
    </message>
</context>
<context>
    <name>QG_LibraryInsertOptions</name>
    <message>
        <source>Library Insert Options</source>
        <translation>Bibliothek Einfügeoptionen</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Rotation Angle</source>
        <translation>Rotationswinkel</translation>
    </message>
    <message>
        <source>Factor:</source>
        <translation>Faktor:</translation>
    </message>
    <message>
        <source>Scale Factor</source>
        <translation>Skalierfaktor</translation>
    </message>
</context>
<context>
    <name>QG_LibraryWidget</name>
    <message>
        <source>Library Browser</source>
        <translation>Teilebibliothek Browser</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Verzeichnisse</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="obsolete">Eintrag</translation>
    </message>
    <message>
        <source>Subitem</source>
        <translation type="obsolete">Untereintrag</translation>
    </message>
    <message>
        <source>New Item</source>
        <translation type="obsolete">Neuer Eintrag</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Einfügen</translation>
    </message>
</context>
<context>
    <name>QG_LineAngleOptions</name>
    <message>
        <source>Line Angle Options</source>
        <translation>Optionen für Linien mit Winkel</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Linienwinkel</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Länge:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Länge der Linie</translation>
    </message>
    <message>
        <source>Snap Point:</source>
        <translation>Fang Punkt:</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Mittelpunkt</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Ende</translation>
    </message>
</context>
<context>
    <name>QG_LineBisectorOptions</name>
    <message>
        <source>Line Bisector Options</source>
        <translation>Optionen für Winkelhalbierende</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Länge:</translation>
    </message>
    <message>
        <source>Length of bisector</source>
        <translation>Länge der Winkelhalbierenden</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Number of bisectors to create</source>
        <translation>Anzahl Winkelhalbierende</translation>
    </message>
</context>
<context>
    <name>QG_LineOptions</name>
    <message>
        <source>Line Options</source>
        <translation>Optionen für Linien</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Zurück</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelOptions</name>
    <message>
        <source>Line Parallel Options</source>
        <translation>Optionen für Parallelen</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Abstand:</translation>
    </message>
    <message>
        <source>Distance to original entity</source>
        <translation>Abstand zum originalen Objekt</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Anzahl Parallelen</translation>
    </message>
</context>
<context>
    <name>QG_LineParallelThroughOptions</name>
    <message>
        <source>Line Parallel Through Options</source>
        <translation>Optionen für Paralleln durch Punkte</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Number of parallels to create</source>
        <translation>Anzahl Parallelen</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygon2Options</name>
    <message>
        <source>Polygon Options</source>
        <translation>Optionen für Polygone</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Anzahl Ecken</translation>
    </message>
</context>
<context>
    <name>QG_LinePolygonOptions</name>
    <message>
        <source>Polygon Options</source>
        <translation>Optionen für Polygone</translation>
    </message>
    <message>
        <source>Number:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Number of edges</source>
        <translation>Anzahl Ecken</translation>
    </message>
</context>
<context>
    <name>QG_LineRelAngleOptions</name>
    <message>
        <source>Line Relative Angle Options</source>
        <translation>Optionen für Linien mit relativem Winkel</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
    <message>
        <source>Line angle</source>
        <translation>Linienwinkel</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Länge:</translation>
    </message>
    <message>
        <source>Length of line</source>
        <translation>Länge der Linie</translation>
    </message>
</context>
<context>
    <name>QG_LineTypeBox</name>
    <message>
        <source>By Layer</source>
        <translation>Nach Layer</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Nach Block</translation>
    </message>
    <message>
        <source>No Pen</source>
        <translation>Kein Stift</translation>
    </message>
    <message>
        <source>Continuous</source>
        <translation>Durchgehend</translation>
    </message>
    <message>
        <source>Dot</source>
        <translation>Gepunktet</translation>
    </message>
    <message>
        <source>Dot (small)</source>
        <translation>Gepunktet (klein)</translation>
    </message>
    <message>
        <source>Dot (large)</source>
        <translation>Gepunktet (gross)</translation>
    </message>
    <message>
        <source>Dash</source>
        <translation>Gestrichelt</translation>
    </message>
    <message>
        <source>Dash (small)</source>
        <translation>Gestrichelt (klein)</translation>
    </message>
    <message>
        <source>Dash (large)</source>
        <translation>Gestrichelt (gross)</translation>
    </message>
    <message>
        <source>Dash Dot</source>
        <translation>Strich Punkt</translation>
    </message>
    <message>
        <source>Dash Dot (small)</source>
        <translation>Strich Punkt (klein)</translation>
    </message>
    <message>
        <source>Dash Dot (large)</source>
        <translation>Strich Punkt (gross)</translation>
    </message>
    <message>
        <source>Divide</source>
        <translation>Trennung</translation>
    </message>
    <message>
        <source>Divide (small)</source>
        <translation>Trennung (klein)</translation>
    </message>
    <message>
        <source>Divide (large)</source>
        <translation>Trennung (gross)</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Mittellinie</translation>
    </message>
    <message>
        <source>Center (small)</source>
        <translation>Mittellinie (klein)</translation>
    </message>
    <message>
        <source>Center (large)</source>
        <translation>Mittellinie (gross)</translation>
    </message>
    <message>
        <source>Border</source>
        <translation>Rahmen</translation>
    </message>
    <message>
        <source>Border (small)</source>
        <translation>Rahmen (klein)</translation>
    </message>
    <message>
        <source>Border (large)</source>
        <translation>Rahmen (gross)</translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- Unverändert -</translation>
    </message>
</context>
<context>
    <name>QG_MouseWidget</name>
    <message>
        <source>Mouse</source>
        <translation>Maus</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Links</translation>
    </message>
</context>
<context>
    <name>QG_MoveRotateOptions</name>
    <message>
        <source>Move Rotate Options</source>
        <translation>Optionen für Verschieben / Rotieren</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
</context>
<context>
    <name>QG_PolylineOptions</name>
    <message>
        <source>Polyline Options</source>
        <translation type="obsolete">Polylinien Optionen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Schliessen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Zurück</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation type="obsolete">Kreisbogen</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation type="obsolete">Radius:</translation>
    </message>
</context>
<context>
    <name>QG_PrintPreviewOptions</name>
    <message>
        <source>Print Preview Options</source>
        <translation>Druckvorschau Optionen</translation>
    </message>
    <message>
        <source>Toggle Black / White mode</source>
        <translation>Schwarz / weiss Modus umschalten</translation>
    </message>
    <message>
        <source>Center to page</source>
        <translation>Auf Seite zentrieren</translation>
    </message>
    <message>
        <source>Fit to page</source>
        <translation>Auf Seite einpassen</translation>
    </message>
</context>
<context>
    <name>QG_RoundOptions</name>
    <message>
        <source>Round Options</source>
        <translation>Optionen für Ecken runden</translation>
    </message>
    <message>
        <source>Trim</source>
        <translation>Trimmen</translation>
    </message>
    <message>
        <source>Check to trim both edges to the rounding</source>
        <translation>Beide Objekte zur Rundung trimmen</translation>
    </message>
    <message>
        <source>Radius:</source>
        <translation>Radius:</translation>
    </message>
</context>
<context>
    <name>QG_SelectionWidget</name>
    <message>
        <source>Selection</source>
        <translation>Selektion</translation>
    </message>
    <message>
        <source>Selected Entities:</source>
        <translation>Selektierte Objekte:</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
</context>
<context>
    <name>QG_SnapDistOptions</name>
    <message>
        <source>Snap Distance Options</source>
        <translation>Optionen für Fangen mit Abstand</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Abstand:</translation>
    </message>
</context>
<context>
    <name>QG_SplineOptions</name>
    <message>
        <source>Spline Options</source>
        <translation>Spline Optionen</translation>
    </message>
    <message>
        <source>Degree:</source>
        <translation>Grad:</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation>Geschlossen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Zurück</translation>
    </message>
</context>
<context>
    <name>QG_TextOptions</name>
    <message>
        <source>Text Options</source>
        <translation>Optionen für Text</translation>
    </message>
    <message>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Winkel:</translation>
    </message>
</context>
<context>
    <name>QG_TrimAmountOptions</name>
    <message>
        <source>Trim Amount Options</source>
        <translation>Optionen für Trimmen um Betrag</translation>
    </message>
    <message>
        <source>Distance. Negative values for trimming, positive values for extending.</source>
        <translation>Abstand. Negativer Wert für Verkürzen, Positiver Wert für verlängern.</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
</context>
<context>
    <name>QG_WidgetPen</name>
    <message>
        <source>Pen</source>
        <translation>Stift</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation>Linientyp:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Breite:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Farbe:</translation>
    </message>
</context>
<context>
    <name>QG_WidthBox</name>
    <message>
        <source>By Layer</source>
        <translation>Nach Layer</translation>
    </message>
    <message>
        <source>By Block</source>
        <translation>Nach Block</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>0.00mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.05mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.09mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.13mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.15mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.18mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.20mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.25mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.30mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.35mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.40mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.50mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.53mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.60mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.70mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>0.80mm</source>
        <translation></translation>
    </message>
    <message>
        <source>0.90mm</source>
        <translation></translation>
    </message>
    <message>
        <source>1.00mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>1.06mm</source>
        <translation></translation>
    </message>
    <message>
        <source>1.20mm</source>
        <translation></translation>
    </message>
    <message>
        <source>1.40mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>1.58mm</source>
        <translation></translation>
    </message>
    <message>
        <source>2.00mm (ISO)</source>
        <translation></translation>
    </message>
    <message>
        <source>2.11mm</source>
        <translation></translation>
    </message>
    <message>
        <source>- Unchanged -</source>
        <translation>- Unverändert -</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Remove Layer</source>
        <translation>Layer löschen</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; and all entities on it will be removed.</source>
        <translation>Layer &quot;%1&quot; und alle Objekte auf diesem Layer werden gelöscht.</translation>
    </message>
    <message>
        <source>Layer &quot;%1&quot; can never be removed.</source>
        <translation>Layer &quot;%1&quot; kann nie entfernt werden.</translation>
    </message>
    <message>
        <source>Layer Dialog</source>
        <translation>Layer Dialog</translation>
    </message>
    <message>
        <source>Remove Block</source>
        <translation>Block löschen</translation>
    </message>
    <message>
        <source>Block &quot;%1&quot; and all its entities will be removed.</source>
        <translation>Block &quot;%1&quot; und alle Objekte des Blocks werden gelöscht.</translation>
    </message>
    <message>
        <source>Layer Properties</source>
        <translation>Layer Eigenschaften</translation>
    </message>
    <message>
        <source>Layer with a name &quot;%1&quot; already exists. Please specify a different name.</source>
        <translation>Ein Layer mit Name &quot;%1&quot; existiert bereits. Bitte wählen Sie einen anderen Namen.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Save Drawing As</source>
        <translation>Zeichnung speichern als</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 existiert bereits.
Wollen Sie die Datei überschreiben?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Open Drawing</source>
        <translation>Zeichnung öffnen</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Bild öffnen</translation>
    </message>
    <message>
        <source>Windows Bitmap</source>
        <translation></translation>
    </message>
    <message>
        <source>Joint Photographic Experts Group</source>
        <translation></translation>
    </message>
    <message>
        <source>Multiple-image Network Graphics</source>
        <translation></translation>
    </message>
    <message>
        <source>Portable Bit Map</source>
        <translation></translation>
    </message>
    <message>
        <source>Portable Grey Map</source>
        <translation></translation>
    </message>
    <message>
        <source>Portable Network Graphic</source>
        <translation></translation>
    </message>
    <message>
        <source>Portable Pixel Map</source>
        <translation></translation>
    </message>
    <message>
        <source>X Bitmap Format</source>
        <translation></translation>
    </message>
    <message>
        <source>X Pixel Map</source>
        <translation></translation>
    </message>
    <message>
        <source>All Image Files (%1)</source>
        <translation>Alle Bilddateien (%1)</translation>
    </message>
    <message>
        <source>Graphics Interchange Format</source>
        <translation></translation>
    </message>
    <message>
        <source>Drawing Exchange %1</source>
        <translation></translation>
    </message>
    <message>
        <source>QCad 1.x file %1</source>
        <translation></translation>
    </message>
    <message>
        <source>Font %1</source>
        <translation>Schrift %1</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Alle Dateien (*.*)</translation>
    </message>
</context>
</TS>
