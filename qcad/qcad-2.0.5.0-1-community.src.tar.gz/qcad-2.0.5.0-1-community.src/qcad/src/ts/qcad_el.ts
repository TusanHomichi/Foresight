<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Φόρτωση..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Φόρτωση διαδρομών βιβλιοθήκης..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Φόρτωση Αρχείου %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Φόρτωση..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Φόρτωση διαδρομών βιβλιοθήκης..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Φόρτωση Αρχείου %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Αρχείο</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Επεξεργασία</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Εστίαση στη γραμμή εντολών</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Ε&amp;στίαση στη γραμμή εντολών</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>Ε&amp;μφάνιση</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>Ε&amp;πιλογή</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Σημείο</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Γραμμή</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>Τό&amp;ξο</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Κύκλος</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>Έ&amp;λειψη</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Σχεδίαση</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Διάσταση</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Τροποποίηση</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>Προσκό&amp;λληση</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>Πλ&amp;η/ρίες</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>Στ&amp;ρώμα</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>Μπλό&amp;κ</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Περί</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Σχετικά...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Σχετικά με την εφαρμογή</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Scripts</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">Παρά&amp;θυρα</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Βοήθεια</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>Αποσφαλ&amp;μάτωση</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Καταρράκτης</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Πλακάκια</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Πλακάκια &amp;οριζόντια</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Δημιουργία νέου αρχείου...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Ανώνυμο εγγραφο %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Άνοιγμα πρόσφατου αρχείου...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Φορτωμένο Εγγραφο:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Απόριψη ανοίγματος</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Εκτύπωση...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Έξοδος απ&apos;την εφαρμογή...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Έκδοση:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Αρχείο</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Επεξεργασία</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>&amp;Προβολές</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>&amp;Γραμμές εργαλείων</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Εμφάνιση</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Πένα</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Επιλογές εργαλείου</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Κατάλογος στρωμάτων</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Κατάλογος μπλόκ</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Ημερομηνία: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Πίνακας Βιβλιοθήκης</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Προεπισκόπηση εκτύπωσης για το %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Το νέο σχέδιο δημιουργήθηκε.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Αποθήκευση σχεδίου...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Αποθηκευμένο Σχέδιο: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Αποθήκευση Σχεδίου με νέο όνομα...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Εξαγωγή σχεδίου...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Εξηγμένο: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Εξαγωγή...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Πέρας εξαγωγής</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Σφάλμα εξαγωγής!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Πέρας εκτύπωσης</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Γραμμή εντολών</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Μπλόκ &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Δεν μπορώ να ανοίξω το αρχείο
%1
Ελένξτε τα δικαιώματα.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Δεν μπορώ να αποθηκεύσω το αρχείο
%1
Ελένξτε τα δικαιώματα.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Εκκίνηση του online εγχειριδίου</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Εγχειρίδιο</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>Ε&amp;γχειρίδιο</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Χειρισμός Εξομοίωσης</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Κανένα</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Έκδοση: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Αρθρώματα: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Περί %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Ημερ/νία: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Αυτή είναι %1 έκδοση η οποία τερματίζει
αυτόματα κάθε 10 λεπτά. Αυτό το λογισμικό
δέν ενδείκνυται για παραγωγική χρήση. 
Παρακαλώ αγοράστε την πλήρη έκδοση από
%2.
Μπορείτε να αποθηκεύσετε την εργασία σας τώρα.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Παράθυρο</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>&amp;Καμπύλη</translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation>Εκτέλεση script &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation>Εισαγωγή μπλόκ &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation>&amp;Πολυγραμμή</translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Φορτωμένο Εγγραφο:</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Θέλεις πραγματικά να κλείσεις το αρχείο
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Θέλεις πραγματικά να κλείσεις το σχέδιο?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Κλείσιμο Σχεδίου</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Προειδοποίηση</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Εξαγωγή εικόνας</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Φόρτωση..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Φόρτωση διαδρομών βιβλιοθήκης..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Φόρτωση Αρχείου %1..</translation>
    </message>
</context>
</TS>
