<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Betöltés..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Könyvtárak betöltése..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">%1 betöltése..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Betöltés..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Könyvtárak betöltése..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">%1 betöltése..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fájl</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fájl</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>S&amp;zerkesztés</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Szerkesztés</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>&amp;Nézetek</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>&amp;Eszköztárak</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Fókusz a parancssorra</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Fókusz a &amp;parancssorra</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Nézet</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Nézet</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Kijelölés</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Pont</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Vonal</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Körív</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>Kö&amp;r</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellipszis</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Rajzolás</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>Mér&amp;etezés</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Módosítás</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Igazítás</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>Inf&amp;ormációk</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>Fó&amp;lia</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blokk</translation>
    </message>
    <message>
        <source>&amp;Options</source>
        <translation type="obsolete">&amp;Beállítások</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Toll</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Eszköz beállításai</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Névjegy</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Névjegy...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>A programról</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Parancsfájlok</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Ablakok</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Súgó</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>Nyomköve&amp;tés</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Fólia lista</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Blokk lista</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Elemkönyvtár böngésző</translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="obsolete">Konzol</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Lépcsőzetes</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Mozaik</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Vízszintes &amp;felosztás</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Új fájl létrehozás...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>névtelen %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Elkészült az új rajz.</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Utóbbiak megnyitása...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Betöltve:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Nyitás megszakadt</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Rajz mentése...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Mentett: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Mentés új névvel...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Exportálás...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Exportált: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Exportálás...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Az exportálás befejelződött</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Exportálási hiba!</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Nyomtatás...</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>A nyomtatás befejeződött</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>%1 nyomtatási képe</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Kilépés...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Névjegy...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Verzió:</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Dátum: %1</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Parancssor</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blokk &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>%1
nem megnyitható. Ellenőrize a jogokat.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>%1
nem menthető. Ellenőrizze a jogokat.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Online kézikönyv</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>Kézikönyv</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Szimulációs elemek</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Egyik sem</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Verzió: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Modulok: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>%1-ról</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Dátum: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Ez a %1 verzió, amely automatikusan
leáll 10 perc után. Ez a program nem üzletszerü
használatra készült. Kérem vásárolja meg a
teljes verziót a következő űrlapon:
%2.
Most elmentheti a munkáját.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>Ablak</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>Görbék</translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Betöltve:</translation>
    </message>
    <message>
        <source>Do you really want to close the file %1?</source>
        <translation type="obsolete">Valóban be akarja zárni &quot;%1&quot;-t?</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Valóban bezárja a fájlt:
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Valóban be akarja zárni a rajzot?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Rajz bezárása</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Kép exportálás</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Betöltés..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Könyvtárak betöltése..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>%1 fájl betöltése..</translation>
    </message>
</context>
</TS>
