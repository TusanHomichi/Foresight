<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Henter..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Henter biblioteksstier..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Henter fil %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Henter..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Henter biblioteksstier..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Henter fil %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fil</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Rediger</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Vi&amp;s</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Vær&amp;ktøjslinie</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Brug komandolinie</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Brug &amp;komandolinie</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>V&amp;is</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Vælg</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Punkt</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Linie</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Bue</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Cirkel</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellipse</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Tegn</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Dimension</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Ændre</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Bind til</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Lag</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blok</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Pen</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Vælg Værktøj</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Om...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Scripts</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Vinduer</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hjælp</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>De&amp;bugging</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Liste over lag</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Liste over blokke</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Overlap</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Arranger</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Arranger &amp;Horisontalt</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Laver ny fil...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Unavngivet dokument %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Genåbner sidste fil...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Henter dokument:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Åbning mislykket</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Printer...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Lukker programmet...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Version:</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Dato: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Biblioteks Browser</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Vis print for %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Ny Tegning er lavet.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Gemmer tegnning...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Gemt tegning: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Gemmer tegning under nyt filnavn...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Eksportere tegning...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Eksporterede: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Eksportere...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Eksport fuldført</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Eksport mislykket!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Print er fuldført</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Komandolinie</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blok &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Kan ikke åbne filen
%1
Check venligst filretighederne.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Kan ikke gemme filen
%1
Check venligst filretighederne.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Hent online manualen</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Manual</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Manual</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Simulations kontrol</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Version: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Moduler: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Om %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Dato: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Dette er en %1 version som afbrydes
Automatisk efter 10min. Dette program er ikke
beregnet for arbejdsbrug. Køb venligst den
fulde version af programmet fra
%2
Du kan gemme dit arbejde nu.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Vindue</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Vil du virklig lukke denne fil
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Vil du virklig lukke denne tegning?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Lukker tegningen</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Exporter Billede</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Henter..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Henter biblioteksstier..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Henter fil %1..</translation>
    </message>
</context>
</TS>
