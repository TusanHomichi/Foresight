<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Caricamento..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Caricamento librerie..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Caricamento File %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Caricamento..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Caricamento Indirizzi delle Librerie..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Caricamento File %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Vai alla Riga di Comando</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Vai alla &amp;Riga di Comando</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Visualizza</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Seleziona</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Punto</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Linea</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Arco</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Cerchio</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellisse</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Disegna</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Quota</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Aggancia</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Layer</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blocco</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Informazioni su</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Informazioni su...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Informazioni sull&apos;applicazione</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Script</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Finestre</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>De&amp;bugging</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Sovrapponi</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>Affianca &amp;Verticalmente</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Affianca &amp;Orizzontalmente</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Crea un nuovo file...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Documento senza nome %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Apri un file recente...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Documento caricato:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Apertura fallita</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>In stampa...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Uscita dall&apos;applicazione...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Informazioni su...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Versione:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>&amp;Viste</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Barra degli &amp;Strumenti</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Penna</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Opzioni Strumento</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Lista Layer</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Lista Blocchi</translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="obsolete">Console</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Data: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Browser Librerie</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Anteprima di stampa per %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Nuovo Disegno Creato.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Salvataggio Disegno...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Disegno salvato: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Salva Disegno con Nuovo Nome...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Esportazione Disegno...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Esportato: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Esportazione...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Esportazione completata</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Esportazione fallita!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Stampa completata</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Riga di comando</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blocco &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Non è possibile aprire il file
%1
Controlla i permessi.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Non è possibile salvare il file
%1
Controlla i permessi.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Lancio del manuale in linea</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Manuale</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Manuale</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Comandi della simulazione</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Niente</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Versione: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Moduli: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Informazioni %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Data: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Questa è una  versione %1 che termina
automaticamente dopo 10 minuti. Questo
software è solo per uso dimostrativo.
Si prega di acquistare la versione completa 
dell&apos;applicazione da %2.
Puoi salvare il tuo lavoro adesso.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation>Eseguo script &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation>Inserisco blocco &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation>Polilinea</translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Documento caricato:</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Vuoi veramente chiudere il file
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Vuoi veramente chiudere il disegno?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Chiusura del Disegno</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Esporta immagine</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Caricamento..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Caricamento indirizzi delle librerie...</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Caricamento File %1..</translation>
    </message>
</context>
</TS>
