<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Nahrávam..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Nahrávam knižničné súbory..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Nahrávam súbor %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Nahrávam..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Nahrávam knižničné súbory..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Nahrávam súbor %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Súbor</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Úpravy</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Focus na príkazový riadok</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Focus na &amp;príkazový riadok </translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Zobraziť</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Voľba</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Bod</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>Či&amp;ara</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Oblúk</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Kružnica</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Elipsa</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Kresli</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Kóty</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Modifikuj</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Prichytávanie</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Informácie</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Hladina</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blok</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O programe</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;O programe...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>O aplikácii</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Skripty</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Okná</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomocník</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>&amp;Ladenie</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Do kaskády</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Pod seba</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Vedľa &amp;seba</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Vytváram nový súbor...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Bez názvu %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Otváram nedávno použitý súbor...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Nahrávam dokument:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Otváranie prerušené</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Tlačím...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Ukončujem program...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>O programe...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Verzia:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Súbor</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Úpravy</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Zo&amp;brazenie</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Nástrojové &amp;panely</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Pohľad</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Pero</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Nastavenia doplnkov</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Zoznam hladín</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Zoznam blokov</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Dátum %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Prezerač knižníc</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Tlač náhľadu pre %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Vytvorený nový výkres.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Ukladám výkres...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Výkres uložený: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Ukladám výkres pod novým menom...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Exportujem výkres...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Exportované: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Exportujem...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Export kompletný</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Exportovanie zlyhalo!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Tlač kompletná</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Príkazový riadok</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blok &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Nemôžem otvoriť súbor
%1
Prosím skontrolujte prístupové práva.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Nemôžem uložiť súbor
%1
Prosím skontrolujte prístupové práva.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Spustí online manuál</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Manuál</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Manuál</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Kontrola simulácie</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Žiadne</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Verzia: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Moduly: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;O programe %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Dátum: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Toto je %1 verzia, ktorá sa automaticky
ukončí po 10 minútach. Tento software
nie je určený pre používanie. Prosím
kúpte si plnú verziu programu zo stránky
%2
Teraz môžete uložiť svoju prácu.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Skutočne chcete uzavrieť súbor
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Skutočne chcete uzavirieť výkres?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Zatváram výkres</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Varovanie</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Exportuj obrázok</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation type="unfinished">Nahrávam..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="unfinished">Nahrávam knižničné súbory..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="unfinished">Nahrávam súbor %1..</translation>
    </message>
</context>
</TS>
