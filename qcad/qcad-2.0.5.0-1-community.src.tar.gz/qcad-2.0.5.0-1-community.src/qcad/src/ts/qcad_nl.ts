<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Bezig met laden...</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Bibliotheek paden worden geladen...</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Bezig met laden van bestand %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Bezig met laden..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Bibliotheek paden worden geladen..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Bezig met laden van bestand %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Bestand</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Be&amp;werken</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Focus op Commando Regel</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Focus op &amp;Commando Regel</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Beeld</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Selecteer</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Punt</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Lijn</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Boog</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Cirkel</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellips</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Tekenen</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Bematen</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Wijzigen</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Snappen</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Meten</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Laag</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blok</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Over ...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Over de Applicatie</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Scripts</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Vensters</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>&amp;Foutzoeken</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Achter elkaar</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Naast elkaat</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>&amp;Onder elkaar</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Nieuw Bestand wordt aangemaakt...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Naamloos Bestand %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Bezig laatst geopend Bestand te openen...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Geopend Bestand:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Het openen is afgebroken</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Er wordt afgedrukt...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Het Programma wordt afgesloten...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Versie:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Bestand</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bewerken</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Bee&amp;ld</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>&amp;Werkbalken</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Beeld</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Pen</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>LageLijst</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Blok Lijst</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Datum: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>In Bibliotheek zoeken</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Afdruk Voorbeeld voor %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Nieuwe Tekening opgestart.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Tekening wordt opgeslagen...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Opgeslagen Tekening: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Tekening wordt onder een nieuw Bestandsnaam opgeslagen...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Bezig met exporteren van de Tekening...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Geëxporteerd: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Bezig met exporteren...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Exporteren geslaagd</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Exporteren mislukt !</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Het Afdrukken is voltooid</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Comando Regel</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blok &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Kan het volgend bestand niet openen
%1
Controleer de toegangsrechten.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Kan het volgend bestand niet bewaren
%1
Controleer de toegangsrechten.</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Handleiding</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Handleiding</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Start de Online Handleiding</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Simulatie Middellen</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Geen</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Versie: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Modules: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Over %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Deze %1 versie beëindigt automatisch
na 10min. Deze sofware is niet voor
produktie bedoeld.  U kunt een
volledige versie kopen van
%2.
U kunt nu uw werk bewaren.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Geopend bestand:</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Wilt u het volgende bestand echt afsluiten
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Wilt U de Tekening echt afsluiten?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Bezig de Tekening te sluiten</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Waarschuwing</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Exporteer een Afbeelding</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="unfinished">Bezig met laden van bestand %1..</translation>
    </message>
</context>
</TS>
