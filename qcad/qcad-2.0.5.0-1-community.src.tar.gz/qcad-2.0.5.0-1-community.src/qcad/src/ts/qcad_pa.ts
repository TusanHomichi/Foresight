<!DOCTYPE TS><TS>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>ਫਾਇਲ(&amp;F)</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>ਸੋਧ(&amp;E)</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>ਕਮਾਂਡ ਰੇਖਾ ਉੱਤੇ ਫੋਕਸ</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>ਕਮਾਂਡ ਰੇਖਾ ਉੱਤੇ ਫੋਕਸ(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>ਵੇਖੋ(&amp;V)</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>ਚੁਣੋ(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>ਬਿੰਦੂ(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>ਰੇਖਾ(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>ਚਾਪ(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>ਚੱਕਰ(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>ਅੰਡਾਕਾਰ(&amp;E)</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>ਡਰਾਇੰਗ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>ਮਾਪ(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>ਸੋਧ(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>ਸਨੈਪ(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>ਜਾਣਕਾਰੀ(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>ਪਰਤ(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>ਬਲਾਕ(&amp;B)</translation>
    </message>
    <message>
        <source>About</source>
        <translation>ਇਸ ਬਾਰੇ</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>ਕਾਰਜ ਦੇ ਬਾਰੇ</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>ਸਕ੍ਰਿਪਟਾਂ(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>ਸਹਾਇਤਾ(&amp;H)</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>ਡੀਬੱਗਿੰਗ(&amp;b)</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>ਸਮਾਂਤਰ(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>ਟਾਇਲ(&amp;T)</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>ਖਿਤਿਜੀ ਟਾਇਲ(&amp;H)</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>ਨਵੀਂ ਫਾਇਲ ਬਣਾਈ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>ਬਿਨਾਂ ਨਾਂ ਦਸਤਾਵੇਜ਼ %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>ਤਾਜ਼ਾ ਫਾਇਲ ਖੋਲੀ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>ਲੋਡ ਦਸਤਾਵੇਜ਼:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>ਅਧੂਰਾ ਛੱਡਿਆ ਜਾ ਰਿਹਾ ਹੈ</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>ਛਾਪਿਆ ਜਾ ਰਿਹਾ ਹੈ...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>ਕਾਰਜ ਬੰਦ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>ਇਸ ਬਾਰੇ...</translation>
    </message>
    <message>
        <source>File</source>
        <translation>ਫਾਇਲ</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>ਸੋਧ</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>ਵੇਖੋ(&amp;w)</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>ਸੰਦ-ਪੱਟੀ(&amp;b)</translation>
    </message>
    <message>
        <source>View</source>
        <translation>ਵੇਖੋ</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>ਪੈਨ</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>ਸੰਦ ਚੋਣ</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>ਪਰਤ ਸੂਚੀ</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>ਬਲਾਕ ਪੱਟੀ</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>ਲਾਇਬ੍ਰੇਰੀ ਝਲਕਾਰਾ</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>%1 ਲਈ ਛਪਾਈ ਝਲਕ</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>ਨਵੀਂ ਡਰਾਇੰਗ ਬਣਾਈ ਗਈ ਹੈ।</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>ਡਰਾਇੰਗ ਸੰਭਾਲੀ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>ਸੰਭਾਲੀ ਜਾ ਰਹੀ ਡਰਾਇੰਗ: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>ਡਰਾਇੰਗ ਨਵੇਂ ਨਾਂ ਨਾਲ ਸੰਭਾਲੀ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>ਡਰਾਇੰਗ ਨਿਰਯਾਤ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>ਨਿਰਯਾਤ: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>ਨਿਰਯਾਤ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>ਨਿਰਯਾਤ ਮੁਕੰਮਲ</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>ਨਿਰਯਾਤ ਅਸਫਲ!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>ਛਪਾਈ ਮੁਕੰਮਲ</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>ਕਮਾਂਡ ਲਾਇਨ</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>ਬਲਾਕ &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>ਫਾਇਲ %1
ਖੋਲੀ ਨਹੀਂ ਜਾ ਸਕੀ ਹੈ
ਕਿਰਪਾ ਕਰਕੇ ਅਧਿਕਾਰਾਂ ਦੀ ਜਾਂਚ ਕਰੋ।</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>ਫਾਇਲ ਨੂੰ ਸੰਭਾਲਿਆ ਨਹੀਂ ਜਾ ਸਕਿਆ ਹੈ
%1
ਕਿਰਪਾ ਕਰਕੇ ਅਧਿਕਾਰਾਂ ਦੀ ਜਾਂਚ ਕਰੋ।</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>ਆਨਲਾਇਨ ਦਸਤਾਵੇਂਜ਼ ਵੇਖਾਓ</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>ਦਸਤਾਵੇਜ਼(&amp;M)</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>ਸਮਰੂਪ ਕੰਟਰੋਲ</translation>
    </message>
    <message>
        <source>None</source>
        <translation>ਕੋਈ ਨਹੀਂ</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>ਵਰਜਨ: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>ਮੈਡੀਊਲ: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>%1 ਬਾਰੇ(&amp;A)</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>ਮਿਤੀ: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>ਇਹ %1 ਵਰਜਨ ਹੈ, ਜੋ ਕਿ ਖੁਦ ਦੀ 10 ਮਿੰਟਾਂ ਬਾਅਦ
ਬੰਦ ਹੋ ਜਾਵੇਗਾ। ਇਹ ਸਾਫਟਵੇਅਰ ਨੂੰ ਉਤਪਾਦਨ
ਲਈ ਨਹੀਂ ਵਰਤਣਾ ਚਾਹੀਦਾ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ
ਕਾਰਜ ਦਾ ਪੂਰਾ ਵਰਜਨ %2 ਦੇ ਰੂਪ ਵਿੱਚ
ਖਰੀਦ ਸਕਦੇ ਹੋ।
ਤੁਸੀਂ ਆਪਣਾ ਕੀਤਾ ਕੰਮ ਵੀ ਸੰਭਾਲ ਸਕਦੇ ਹੋ।</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>ਝਰੋਖਾ(&amp;W)</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>ਸਪਲਾਈਨ(&amp;S)</translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation>&apos;%1&apos; ਸਕ੍ਰਿਪਟ ਚਲਾਈ ਜਾ ਰਹੀ ਹੈ</translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation>ਬਲਾਕ &apos;%1&apos; ਸ਼ਾਮਿਲ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation>ਬਹੁਭੁਜ(&amp;P)</translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>ਕੀ ਤੁਸੀਂ ਫਾਇਲ %1 ਨੂੰ ਬੰਦ ਕਰਨ ਦੀ
ਪੁਸ਼ਟੀ ਕਰਦੇ ਹੋ?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>ਕੀ ਤੁਸੀਂ ਡਰਾਇੰਗ ਬੰਦ ਕਰਨੀ ਚਾਹੁੰਦੇ ਹੋ?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>ਡਰਾਇੰਗ ਬੰਦ ਕਰੋ</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>ਚੇਤਾਵਨੀ</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>ਚਿੱਤਰ ਨਿਰਯਾਤ</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>ਲੋਡ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>ਲਾਇਬ੍ਰੇਰੀ ਮਾਰਗ ਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>ਫਾਇਲ %1 ਲੋਡ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ..</translation>
    </message>
</context>
</TS>
