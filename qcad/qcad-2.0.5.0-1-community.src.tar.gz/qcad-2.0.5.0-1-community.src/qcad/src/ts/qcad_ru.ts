<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Загрузка..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Загрузка библиотечных элементов..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Загрузка файла %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Загрузка..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Загрузка библиотечных элементов..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Загрузка файла %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Правка</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Перейти к командной строке</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Перейти к &amp;командной строке</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Вид</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>В&amp;ыбор</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Точка</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Линия</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Дуга</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Окружность</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Эллипс</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Черчение</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Размер</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>Из&amp;менение</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>Пр&amp;ивязка</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>И&amp;нфо</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>С&amp;лой</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Блок</translation>
    </message>
    <message>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;О программе...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Сведения о программе</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Скрипты</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Окно</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощь</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>От&amp;ладка</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Каскадом</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Мозаика</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Мозаика по &amp;горизонтали</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Создается новый файл...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>безымянный документ %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Открывается недавно редактированный файл...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Загруженный документ:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Открытие файла отменено</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Печать...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Выход из программы...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Версия: </translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Правка</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Ви&amp;ды</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Па&amp;нели инструментов</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Перо</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Параметры инструмента</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Список слоев</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Список блоков</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Дата: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Просмотр библиотек</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Предварительный просмотр %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Новый чертеж создан.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Сохраняется чертеж...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Сохранен чертеж: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Сохраняется чертеж под новым именем...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Выполняется экспорт чертежа...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Экспортирован: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Выполняется экспорт...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Экспорт завершен</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Экспорт не удался!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Печать завершена</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Командная строка</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Блок &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Невозможно открыть файл
%1
Проверьте, пожалуйста, права доступа.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Невозможно сохранить файл
%1
Проверьте, пожалуйста, права доступа.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Запуск он-лайн руководства</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Руководство пользователя</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Руководство пользователя</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Управление симуляцией</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Версия: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Модули: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;О программе %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Дата: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Это версия %1, которая автоматически прекращает 
работу после 10 мин. Эта программа
не предназначена для полного использования. Пожалуйста,
приобретите полную версию этой программы от
%2.
Сейчас вы можете сохранить свою работу.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Окно</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Загруженный документ: </translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Вы действительно хотите закрыть файл
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Вы действительно хотите закрыть чертеж?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Закрытие чертежа</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Экспорт изображения</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Загрузка..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Загрузка библиотечных элементов..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Загрузка файла %1..</translation>
    </message>
</context>
</TS>
