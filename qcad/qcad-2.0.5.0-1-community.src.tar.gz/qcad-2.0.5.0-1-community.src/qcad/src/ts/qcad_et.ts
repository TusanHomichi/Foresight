<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Laadimine..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Teekide asukohtade laadimine..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Faili %1 laadimine..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Laadimine..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Teekide asukohtade laadimine..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Faili %1 laadimine..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fail</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Redigeerimine</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Fookus käsureal</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Fookus &amp;käsureal</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Vaade</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>V&amp;alimine</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Punkt</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Joon</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Kaar</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Ringjoon</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellips</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Joonestamine</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>&amp;Mõõdud</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Muutmine</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Haaramine</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Kile</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Plokk</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Teave</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;Teave...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Teave rakenduse kohta</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>&amp;Skriptid</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Aknad</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;bi</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>&amp;Testimine</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Kaskaadi</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Paanidena</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>&amp;Horisontaalsete paanidena</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Uue faili loomine...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>nimetu dokument %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Hiljutise faili avamine...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Laaditud dokument:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Avamine katkestati</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Printimine...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Rakenduse sulgemine...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Teave...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Versioon:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fail</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Redigeerimine</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Vaate&amp;d</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Tööriistari&amp;bad</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vaade</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Pliiats</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Töövahendi sätted</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Kilede nimekiri</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Plokkide nimekiri</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Kuupäev: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Teekide sirvija</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Väljatrüki eelvaade %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Uus joonis loodud.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Joonise salvestamine...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Salvestatud joonis: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Joonise salvestamine uue nimega...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Joonise eksportimine...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Eksporditud: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Eksportimine...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Eksportimine lõpetatud</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Eksportimine ebaõnnestus!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Printimine lõpetatud</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Käsurida</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Plokk &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Ei ole võimalik avada faili
%1
Palun kontrolli õigusi.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Ei ole võimalik salvestada faili
%1
Palun kontrolli õigusi.</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Ava kaasasolev käsiraamat</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Käsiraamat</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Käsiraamat</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Kuupäev: %1</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Jäljendamise juhtimine</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Puudub</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Versioon: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Moodulid: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>%1 &amp;teave</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>See on %1 versioon, mis lõpetab
10 minuti pärast automaatselt töö. See
tarkvara ei ole mõeldud äriliseks kasutamiseks.
Palun osta programmi täisversioon
%2
Salvesta nüüd oma töö.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Aken</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>&amp;Kõver</translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Soovid sa tõesti faili %1 sulgeda?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Soovid sa tõesti joonist sulgeda?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Joonise sulgemine</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Hoiatus</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Pildi eksportimine</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Laadimine..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Teekide asukohtade laadimine..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Faili %1 laadimine..</translation>
    </message>
</context>
</TS>
