<!DOCTYPE TS><TS>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Command line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
