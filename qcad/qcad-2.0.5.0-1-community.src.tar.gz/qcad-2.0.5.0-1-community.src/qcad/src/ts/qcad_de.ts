<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Lade..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Lade Bibliothek Pfade..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Lade Datei %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Lade..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Lade Bibliothek Pfade..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Lade Datei %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Bearbeiten</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Fokus auf Eingabezeile</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Fokus auf &amp;Eingabezeile</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Selektion</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Punkt</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Linie</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>Kreis&amp;bogen</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Kreis</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Ellipse</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Zeichnen</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>Be&amp;massung</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>M&amp;odifizieren</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Fang</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Layer</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>Blo&amp;ck</translation>
    </message>
    <message>
        <source>&amp;Options</source>
        <translation type="obsolete">O&amp;ptionen</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">Ü&amp;ber...
</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>Über die Applikation</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>S&amp;kripte</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Fenster</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>Debu&amp;gging</translation>
    </message>
    <message>
        <source>Ready.</source>
        <translation type="obsolete">Bereit.</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Kaskadieren</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Teilen</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>&amp;Horizontal teilen</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Neue Datei erstellen...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>Unbenanntes Dokument %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Kürzlich geladene Datei laden...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Geladenes Dokument:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Öffnen abgebrochen</translation>
    </message>
    <message>
        <source>Saving file...</source>
        <translation type="obsolete">Speichere Datei...</translation>
    </message>
    <message>
        <source>Saving file under new filename...</source>
        <translation type="obsolete">Speichern unter neuem Namen...</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Drucken...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Applikation beenden...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Version:</translation>
    </message>
    <message>
        <source>
Date: </source>
        <translation type="obsolete">
Datum:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editieren</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>&amp;Ansichten</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>&amp;Funktionsleisten</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ansicht</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Stift</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Tool Optionen</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Layer Liste</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Block Liste</translation>
    </message>
    <message>
        <source>Console</source>
        <translation type="obsolete">Konsole</translation>
    </message>
    <message>
        <source>Library List</source>
        <translation type="obsolete">Bibliothek</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Datum: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Bibliothek Browser</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Druckvorschau für %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Neue Zeichnung erstellt.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Speichere Zeichnung...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Gespeicherte Zeichung: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Speichere Zeichnung unter neuem Dateinamen...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Exportiere Zeichnung...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Exportiert: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Exportiere...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Export abgeschlossen</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Export fehlgeschlagen!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Drucken abgeschlossen</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Kommandozeile</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Block &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Kann Datei
%1
nicht  öffnen. Bitte prüfen Sie die Berechtigung.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Kann Datei
%1
nicht speichern. Bitte prüfen Sie die Berechtigung.</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Hilfe</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Online Manual anzeigen</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Handbuch</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Handbuch</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Simualtion Kontrolle</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Keine</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Version: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Module: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>Ü&amp;ber %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%1.
You can save your work now.</source>
        <translation type="obsolete">Dies ist eine %1 version, die sich nach 10min
automatisch beendet. Dieses Program ist nicht
für den Produktiven Gebrauch bestimmt. Bitte
kaufen Sie eine Vollversion von
%1.
Sie können Ihre Arbeit jetzt speichern.</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Dies ist eine %1 version, die sich nach 10min
automatisch beendet. Dieses Program ist nicht
für den Produktiven Gebrauch bestimmt. Bitte
kaufen Sie eine Vollversion von
%2.
Sie können Ihre Arbeit jetzt speichern.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>Fen&amp;ster</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation>&amp;Spline</translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation>Führe Skript &apos;%1&apos; aus</translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation>Füge Block &apos;%1&apos; ein</translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation>&amp;Polylinie</translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Geladene Datei:</translation>
    </message>
    <message>
        <source>Do you really want to close the file %1?</source>
        <translation type="obsolete">Sind Sie sicher, dass Sie die Datei %1 schliessen möchten?</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Wollen Sie die Datei
%1
wirklich schliessen?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Wollen Sie die Zeichnung wirklich schliessen?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Zeichnung schliessen</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Bild exportieren</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Lade..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Lade Bibliothek Pfade..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Lade Datei %1..</translation>
    </message>
</context>
</TS>
