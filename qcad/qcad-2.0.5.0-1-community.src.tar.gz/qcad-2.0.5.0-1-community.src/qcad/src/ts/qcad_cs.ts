<!DOCTYPE TS><TS>
<context>
    <name></name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Nahrávám..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Nahrávám cesty ke knihovnám..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Nahrávám soubor %1..</translation>
    </message>
</context>
<context>
    <name>@default</name>
    <message>
        <source>Loading..</source>
        <translation type="obsolete">Nahrávám..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation type="obsolete">Nahrávám cesty ke knihovnám..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation type="obsolete">Nahrávám soubor %1..</translation>
    </message>
</context>
<context>
    <name>QC_ApplicationWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Úp&amp;ravy</translation>
    </message>
    <message>
        <source>Focus on Command Line</source>
        <translation>Přejít na příkazový řádek</translation>
    </message>
    <message>
        <source>Focus on &amp;Command Line</source>
        <translation>Přejít na pří&amp;kazový řádek</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Zobrazit</translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation>&amp;Výběr</translation>
    </message>
    <message>
        <source>&amp;Point</source>
        <translation>&amp;Bod</translation>
    </message>
    <message>
        <source>&amp;Line</source>
        <translation>&amp;Úsečka</translation>
    </message>
    <message>
        <source>&amp;Arc</source>
        <translation>&amp;Oblouk</translation>
    </message>
    <message>
        <source>&amp;Circle</source>
        <translation>&amp;Kružnice</translation>
    </message>
    <message>
        <source>&amp;Ellipse</source>
        <translation>&amp;Elipsa</translation>
    </message>
    <message>
        <source>&amp;Draw</source>
        <translation>&amp;Kreslit</translation>
    </message>
    <message>
        <source>&amp;Dimension</source>
        <translation>Kó&amp;ta</translation>
    </message>
    <message>
        <source>&amp;Modify</source>
        <translation>&amp;Modifikace</translation>
    </message>
    <message>
        <source>&amp;Snap</source>
        <translation>&amp;Uchopit</translation>
    </message>
    <message>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;Layer</source>
        <translation>&amp;Hladina</translation>
    </message>
    <message>
        <source>&amp;Block</source>
        <translation>&amp;Blok</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="obsolete">&amp;O programu...</translation>
    </message>
    <message>
        <source>About the application</source>
        <translation>O programu</translation>
    </message>
    <message>
        <source>&amp;Scripts</source>
        <translation>Skript&amp;y</translation>
    </message>
    <message>
        <source>&amp;Windows</source>
        <translation type="obsolete">&amp;Okna</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Nápověda</translation>
    </message>
    <message>
        <source>De&amp;bugging</source>
        <translation>Od&amp;ladit</translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation>&amp;Na sebe</translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation>&amp;Dlaždice</translation>
    </message>
    <message>
        <source>Tile &amp;Horizontally</source>
        <translation>Dlaždice &amp;vodorovně</translation>
    </message>
    <message>
        <source>Creating new file...</source>
        <translation>Vytvářím nový soubor...</translation>
    </message>
    <message>
        <source>unnamed document %1</source>
        <translation>nepojmenovaný dokument %1</translation>
    </message>
    <message>
        <source>Opening recent file...</source>
        <translation>Otevírám nejčastěji otevíraný soubor...</translation>
    </message>
    <message>
        <source>Loaded document: </source>
        <translation>Nahraný dokument:</translation>
    </message>
    <message>
        <source>Opening aborted</source>
        <translation>Otevírání přerušeno</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Probíhá tisk...</translation>
    </message>
    <message>
        <source>Exiting application...</source>
        <translation>Ukončuji program...</translation>
    </message>
    <message>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="obsolete">Verze:</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Úpravy</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Podok&amp;na</translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation>Nást&amp;rojové lišty</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Zobrazit</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Pero</translation>
    </message>
    <message>
        <source>Tool Options</source>
        <translation>Vlastnosti nástroje</translation>
    </message>
    <message>
        <source>Layer List</source>
        <translation>Seznam hladin</translation>
    </message>
    <message>
        <source>Block List</source>
        <translation>Seznam bloků</translation>
    </message>
    <message>
        <source>
Date: %1</source>
        <translation type="obsolete">
Datum: %1</translation>
    </message>
    <message>
        <source>Library Browser</source>
        <translation>Prohlížeč knihoven</translation>
    </message>
    <message>
        <source>Print preview for %1</source>
        <translation>Náhled před tiskem pro %1</translation>
    </message>
    <message>
        <source>New Drawing created.</source>
        <translation>Nový výkres vytvořen.</translation>
    </message>
    <message>
        <source>Saving drawing...</source>
        <translation>Ukládám výkres...</translation>
    </message>
    <message>
        <source>Saved drawing: %1</source>
        <translation>Uložený výkres: %1</translation>
    </message>
    <message>
        <source>Saving drawing under new filename...</source>
        <translation>Ukládám výkres pod novým jménem...</translation>
    </message>
    <message>
        <source>Exporting drawing...</source>
        <translation>Exportuji výkres...</translation>
    </message>
    <message>
        <source>Exported: %1</source>
        <translation>Exporotvaný: %1</translation>
    </message>
    <message>
        <source>Exporting...</source>
        <translation>Exportuji...</translation>
    </message>
    <message>
        <source>Export complete</source>
        <translation>Exportování dokončeno</translation>
    </message>
    <message>
        <source>Export failed!</source>
        <translation>Export neúspěšný!</translation>
    </message>
    <message>
        <source>Printing complete</source>
        <translation>Tisk dokončen</translation>
    </message>
    <message>
        <source>Command line</source>
        <translation>Příkazový řádek</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">Manuál</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Manuál</translation>
    </message>
    <message>
        <source>Launch the online manual</source>
        <translation>Spustí on-line manuál</translation>
    </message>
    <message>
        <source>Block &apos;%1&apos;</source>
        <translation>Blok &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Cannot open the file
%1
Please check the permissions.</source>
        <translation>Nelze otevřít soubor
%1
Zkontrolujte prosím přístupová práva.</translation>
    </message>
    <message>
        <source>Cannot save the file
%1
Please check the permissions.</source>
        <translation>Nelze uložit soubor
%1
Zkontrolujte prosím přístupová práva.</translation>
    </message>
    <message>
        <source>&amp;CAM</source>
        <translation>&amp;CAM</translation>
    </message>
    <message>
        <source>Simulation Controls</source>
        <translation>Ovládání simulace</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nic</translation>
    </message>
    <message>
        <source>Version: %1 %2</source>
        <translation>Verze: %1 %2</translation>
    </message>
    <message>
        <source>Modules: %1</source>
        <translation>Moduly: %1</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;O programu %1</translation>
    </message>
    <message>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
    <message>
        <source>This is a %1 version which terminates
automatically after 10min. This software is
not intended for production use. Please buy
a full version of the application from
%2.
You can save your work now.</source>
        <translation>Toto je %1 verze, která bude
automaticky po 10-ti minutách ukončena. Tento program
není určen k ostrému nasazení. Zakupte si prosím
plnou verzi programu z
%2.
Nyní můžete uložit svou práci.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Okno</translation>
    </message>
    <message>
        <source>&amp;Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running script &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting block &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Polyline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QC_MDIWindow</name>
    <message>
        <source>Loaded document: </source>
        <translation type="obsolete">Nahraný dokument:</translation>
    </message>
    <message>
        <source>Do you really want to close the file
%1?</source>
        <translation>Skutečně si přejete uzavřít soubor
%1?</translation>
    </message>
    <message>
        <source>Do you really want to close the drawing?</source>
        <translation>Skutečně si přejete uzavřít výkres?</translation>
    </message>
    <message>
        <source>Closing Drawing</source>
        <translation>Zavírám výkres</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Warning</source>
        <translation>Upozornění</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Export Image</source>
        <translation>Exportovat obrázek</translation>
    </message>
    <message>
        <source>Loading..</source>
        <translation>Nahrávám..</translation>
    </message>
    <message>
        <source>Loading Library Paths..</source>
        <translation>Nahrávám cesty ke knihovnám..</translation>
    </message>
    <message>
        <source>Loading File %1..</source>
        <translation>Nahrávám soubor %1..</translation>
    </message>
</context>
</TS>
