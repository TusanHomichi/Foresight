Dir['*_spec.rb'].each do |test|
	require test
end
