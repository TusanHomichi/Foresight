from setuptools import setup

setup(name='jsonrpclib',
      version='0.0.1',
      description='Python client code for accessing JSON-RPC',
      author='Matt Harrison',
      author_email='mharrison@spikesource.com',
      py_modules=['jsonrpclib'],
      install_requires = ["simplejson"]
     )
