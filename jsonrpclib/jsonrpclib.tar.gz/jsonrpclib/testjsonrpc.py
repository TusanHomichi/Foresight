import unittest
import jsonrpclib


class TestJsolait(unittest.TestCase):
    def test_echo(self):
        s = jsonrpclib.ServerProxy("http://jsolait.net/services/test.jsonrpc", verbose=0)
        reply = s.echo("foo bar")
        print reply
        self.assert_(reply["result"] == "foo bar")

        #test no parameters
        reply = s.echo()
        self.assert_(reply["result"] == None)
        self.assert_(reply["error"] == "InvalidMethodParameters")

        #test too many parameters
        reply = s.echo("foo", "bar")
        self.assert_(reply["result"] == None)
        self.assert_(reply["error"] == "InvalidMethodParameters")

        #test integer
        reply = s.echo(120)
        self.assert_(reply["result"] == 120)
        
        #test float
        reply = s.echo(120.0)
        self.assert_(reply["result"] == 120.0)

        #test list
        reply = s.echo([2,3])
        self.assert_(reply["result"] == [2,3])

        #test dict
        reply = s.echo({"foo":"bar"})
        self.assert_(reply["result"] == {"foo":"bar"})

    def test_args2String(self):
        s = jsonrpclib.ServerProxy("http://jsolait.net/services/test.jsonrpc", verbose=0)
        
        reply = s.args2String('hello', {'a':1234, 'b':'five'}, [6, 7, 8, 9])
        result = reply["result"]
        self.assert_(result == "(u'hello', {u'a': 1234, u'b': u'five'}, [6, 7, 8, 9])")

    def test_args2Array(self):
        s = jsonrpclib.ServerProxy("http://jsolait.net/services/test.jsonrpc", verbose=0)
        
        reply = s.args2Array('hello', {'a':1234, 'b':'five'}, [6, 7, 8, 9])
        result = reply["result"]
        self.assert_(result == [u'hello', {u'a': 1234, u'b': u'five'}, [6, 7, 8, 9]])

    def test_badMethod(self):
        s = jsonrpclib.ServerProxy("http://jsolait.net/services/test.jsonrpc", verbose=0)
        
        reply = s.foobar()
        result = reply["result"]
        self.assert_(result == None)
        self.assert_(reply['error'] == "MethodNotFound")


class TestMetaparadigm(unittest.TestCase):
    def test_listmethods(self):
        #from http://oss.metaparadigm.com/jsonrpc-cvs/test.jsp
        #doesn't work...
        s = jsonrpclib.ServerProxy("http://oss.metaparadigm.com/jsonrpc-cvs/JSON-RPC", verbose=0)
        #c = s.system.listMethods()

        d = s.test.echo("hello")
        print d
        self.assert_(d['result'] == "hello")



if __name__=="__main__":
    unittest.main()
