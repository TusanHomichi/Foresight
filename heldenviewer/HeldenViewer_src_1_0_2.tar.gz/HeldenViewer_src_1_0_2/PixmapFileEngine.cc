/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "PixmapFileEngine.hh"
#include <QMap>
#include <QDebug>

class MyStaticMap
{
  MyStaticMap(){}
  MyStaticMap(const MyStaticMap &rhv){}
  MyStaticMap &operator=(const MyStaticMap &rhv){return *this;}
  
  QMap<QString, QByteArray*> map_;
public:
  static MyStaticMap &instance(){static MyStaticMap instance;return instance;}
  QMap<QString, QByteArray*> &map(){return map_;}
  ~MyStaticMap()
  {
    for(QMap<QString, QByteArray*>::iterator it = map_.begin(); it != map_.end(); ++it)
      delete it.value();
  }
};

QAbstractFileEngine * PixmapFileEngineHandler::create(const QString &fileName) const
{
  if (fileName.startsWith("HELDENVIEWER_OWN_TYPES_"))
    return new PixmapFileEngine(fileName);
  else
    return 0;
}


PixmapFileEngine::PixmapFileEngine(const QString& fileName)
: QAbstractFileEngine(), m_fileName(fileName), m_filePos(0)

{
  QMap<QString, QByteArray*> &map = MyStaticMap::instance().map();
//   qDebug("%s: contained:%d", fileName.toLatin1().data(), map.contains(m_fileName));
  if (map.contains(m_fileName))
  {
    m_bytes = map.value(m_fileName);
  }
  else
  {
    m_bytes = new QByteArray;
    map[m_fileName] = m_bytes;
  }
}

qint64 PixmapFileEngine::write ( const char * data, qint64 len )
{
//   qDebug("WRITING:filename:%s, filepos: %d, len: %d", m_fileName.toLatin1().data(),m_filePos, len);
  if (m_filePos + len > m_bytes->size()) m_bytes->resize(m_filePos + len);

//   m_bytes->append(data,len);
  qCopy(data, data + len, m_bytes->data() + m_filePos);

  m_filePos += len;
  

  return len;
//   return -1;
}

qint64 PixmapFileEngine::read ( char * data, qint64 maxlen )
{
//   qDebug("Read");
  qint64 readBytes;

  if (m_filePos + maxlen > m_bytes->size())
    readBytes = m_bytes->size() - m_filePos;
  else
    readBytes = maxlen;

  qCopy(m_bytes->constData() + m_filePos,
  m_bytes->constData() + m_filePos + readBytes, data);

  m_filePos += readBytes;

  return readBytes;
}