/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeLoader.hh"
#include "QualityMap.hh"
#include "SettingsManager.hh"

#include <QApplication>
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QStringList>
#include <QDebug>

YoutubeLoader::YoutubeLoader()
  : userData_(0), sendEventsTo_(0), manager_(0), startByte_(0), desiredQuality_(0)
{
  QObject::moveToThread(this);
}

YoutubeLoader::~YoutubeLoader()
{
}

void YoutubeLoader::setReceiverObject(QObject* sendEventsTo)
{
  sendEventsTo_ = sendEventsTo;
}

void YoutubeLoader::setUserdata(QVariant userdata)
{
  userData_ = userdata;
}

void YoutubeLoader::setUrl(const QString & url)
{
  url_ = url;
}

void YoutubeLoader::run()
{
  manager_ = new QNetworkAccessManager(this);
  connect(manager_, SIGNAL(finished(QNetworkReply*)),
  this, SLOT(replyFinished(QNetworkReply*)));
  
  load(url_);
  
  delete manager_;
}

void YoutubeLoader::load(const QString & url)
{
	
	QString videoUrl = url;
	videoUrl.replace("watch?v=", "get_video_info?video_id=");
	flashDataReply_ =  manager_->get(QNetworkRequest(QUrl(videoUrl)));
  //flashDataReply_ =  manager_->get(QNetworkRequest(QUrl(url)));
	//qDebug() << videoUrl << endl;
  exec();
}

void YoutubeLoader::sendMessage(Message message, int param, QByteArray buf)
{
  QApplication::postEvent(sendEventsTo_, new YoutubeLoaderEvent(message, param, buf, userData_));
}

void YoutubeLoader::getURLForDifferentQualities(const QString& data, QualityMap &qualities)
{
	//Need to do some more magic since the last update of youtube
	//qDebug() << data;
	
	//qDebug() << line << endl;
  QString string = data;
	int pos1 = string.indexOf("url_encoded_fmt_stream_map=");
  int pos2 = string.indexOf("&", pos1);
  string = string.mid(pos1, pos2-pos1);
	
	QStringList commaSplitList = string.split("%2C");
  for(int i = 0; i < commaSplitList.size(); ++i)
  {
		QStringList ampersandSplitList = commaSplitList[i].split("%26");
		if(ampersandSplitList.size() < 2)
		{
			qDebug() << tr("Wrong size of fmt_stream_map structure: %1").arg( ampersandSplitList.size());
			continue;
		}
		
		QString url = ampersandSplitList[0];
		if(i==0)
			url.replace("url_encoded_fmt_stream_map=","");
		
		url = QUrl::fromPercentEncoding(url.toLatin1());
		url.replace("url=","");
		
		for(int j = 0; j < ampersandSplitList.size(); ++j)
		{
				if(ampersandSplitList[j].left(4) == "itag"){
					QRegExp regEx("itag%3D(\\d+)*");
					int pos = regEx.indexIn(ampersandSplitList[j]);
					if(pos == -1) continue;
					
					int fmt = regEx.cap(1).toInt();
					url = QUrl::fromPercentEncoding(url.toLatin1()).toLatin1();
					
					qualities.addItem(fmt, url);
					break;
				}
		}
  }
}


void YoutubeLoader::replyFinished(QNetworkReply* reply)
{
//   qDebug("Reply finished");
  if(reply == flashDataReply_)
  {
    if (reply->error() != QNetworkReply::NoError)
    {
//       qDebug("FlashDataReply. An error occured, trying to access the url to get the flash data, error: %d", reply->error());
      sendMessage(LOADER_NETWORK_ERROR, 0, tr("An error occured, trying to access the url to get the flash data.\n Error string: %1").arg(reply->errorString()).toLatin1());
      return;
    }
		
    QByteArray bytes = reply->readAll();  // bytes
    
    QString string(bytes); // string
    QualityMap qualities;
    qualities.setDesiredQuality(desiredQuality_);
    getURLForDifferentQualities(string, qualities);
    sendMessage(START_DOWNLOAD, 0, 0);
    getUrl_ = qualities.getCorrectURL();
    sendMessage(DOWNLOADING_QUALITY, qualities.getAvailableQualityNearestToDesired(),0);
    videoDataReplyHeader_ =  manager_->head(QNetworkRequest(QUrl::fromPercentEncoding(getUrl_.toLatin1())));
    exec();
  }
  if(reply == videoDataReply_)
  {
    if (reply->error() != QNetworkReply::NoError)
    {
//       qDebug("VideoDataReply. An error occured, trying to access the url. Error no: %d", reply->error());
      sendMessage(LOADER_NETWORK_ERROR, 0, tr("An error occured, trying to access the video url.\n Error string: %1").arg(reply->errorString()).toLatin1());
      return;
    }
    QByteArray data = videoDataReply_->readAll();
    if(data.size())
      sendMessage(DOWNLOAD_STATUS, data.size(), data);
    sendMessage(COMPLETE, 0,0);
  }
  
  if(reply == videoDataReplyHeader_)
  {
    if (reply->error() != QNetworkReply::NoError)
    {
      sendMessage(LOADER_NETWORK_ERROR, 0, tr("An error occured, trying to access the header of the video url.\n Error string: %1").arg(reply->errorString()).toLatin1());
      return;
    }

    QVariant redirectURL = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);
    if(!redirectURL.isNull() && redirectURL.toString() != getUrl_)
    {
      //qDebug("REDIRECTION: %s", redirectURL.toString().toLatin1().data());
      QVariant location = reply->header(QNetworkRequest::LocationHeader);
      //qDebug("locatioN. %s", location.toString().toLatin1().data());
      getUrl_ = redirectURL.toString();
      videoDataReplyHeader_->deleteLater();
      //qDebug("Getting head: %s", redirectURL.toString().toLatin1().data());
      videoDataReplyHeader_ =  manager_->head(QNetworkRequest(QUrl::fromPercentEncoding(redirectURL.toString().toLatin1())));
      
      exec();
      return;
    }
    //qDebug("No redirection.");
    QVariant sizeBytes = reply->header(QNetworkRequest::ContentLengthHeader);
    QVariant location = reply->header(QNetworkRequest::LocationHeader);
    //qDebug("locatioN. %s", location.toString().toLatin1().data());
    if(!sizeBytes.isNull())
    {
      if(!location.isNull())
      {
        //qDebug("Location is present, redirecting.");
        getUrl_ = location.toString();
      }
      sendMessage(VIDEOSIZE, sizeBytes.toInt(), 0);
      QNetworkRequest request(QUrl::fromPercentEncoding(getUrl_.toLatin1()));
      if(startByte_ >= sizeBytes.toInt())
      {
        qDebug() << tr("Requesting to start at byte %1, but only %2 are available").arg(startByte_).arg(sizeBytes.toInt());
        
        //It is relatively safe to assume that this video has been downloaded correctly if the file size matches exactly
        if(startByte_ == sizeBytes.toInt())
          sendMessage(COMPLETE, 0, 0);
        //Otherwise it most likely has been downloaded with a different quality
        else
          sendMessage(LOADER_BYTE_MISMATCH_ERROR, 0, tr("The file already exists and has most likely been downloaded in a lower quality. Please delete the file ").toLatin1());
        return;
      }
      request.setRawHeader("Range", QString("bytes=%1-").arg(startByte_).toAscii());
      videoDataReply_ =  manager_->get(request);
      connect(videoDataReply_, SIGNAL(readyRead()), this, SLOT(newDataReady()));
      exec();
    }
    else
    {
      sendMessage(LOADER_NETWORK_ERROR, 0, tr("The video size could not be retrieved and so the video cannot be retrieved either, url was \"%1\"").arg(getUrl_).toLatin1());
    }
    
  }
    
    
  reply->deleteLater();
}

void YoutubeLoader::newDataReady()
{
  if(videoDataReply_->bytesAvailable() > 1024*1024)
  {
    QByteArray data = videoDataReply_->readAll();
    sendMessage(DOWNLOAD_STATUS, data.size(), data);
    
  }
//   qDebug("New data available: %d", videoDataReply_->bytesAvailable());
}

void YoutubeLoader::startAtByte(int byte)
{
  startByte_ = byte;
}

void YoutubeLoader::setDesiredQuality(int quality)
{
  desiredQuality_ = quality;
}
