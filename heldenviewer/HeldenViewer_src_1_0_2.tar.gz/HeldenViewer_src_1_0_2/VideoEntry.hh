/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef VIDEOENTRY_HH
#define VIDEOENTRY_HH

#include <QString>
#include "SettingsManager.hh"

/**
  * This struct saves all relevant data for a video. Given the video id
  * all data can be reconstructed by querying the youtube platform.
  * Note that the URL can be reconstructed from the video id as well and
  * therefore is no longer saved in the structure.
*/

struct VideoEntry
{
private: 
//   QString url_;
  QString videoId_;
public:
  QString author;
  QString title;
  QString seconds;
  QString thumbnailUrl;
  QString viewCount;
  QString published, updated;
  //Video size in bytes
  qint64 videoSize;
  qint64 bytesDownloaded;
  qint8 downloadQuality;
  
  qint32 numRaters;
  qreal ratingAverage;
  qint32 commentCount;
  
  QString getFormattedTime() const;
  void setDefaultDownloadQuality(){downloadQuality = SettingsManager::instance().defaultQuality();}
  VideoEntry(): videoSize(0), bytesDownloaded(0){setDefaultDownloadQuality();}
  VideoEntry(const QString &author, const QString &title, const QString &seconds) : author(author), title(title), seconds(seconds), videoSize(0), bytesDownloaded(0){setDefaultDownloadQuality();}
  
  void setUrl(const QString &url);
  void setVideoId(const QString &id);
  bool update(const VideoEntry &entry);
  void copyFields(const VideoEntry &entry);
  
  QString url() const;
  QString videoId() const;
  
  void save(QDataStream &out, bool shortFormat);
};

bool operator<(const VideoEntry &_lhv, const VideoEntry &_rhv);
bool operator==(const VideoEntry &_lhv, const VideoEntry &_rhv);

// QDataStream& operator<<(QDataStream& out, const VideoEntry& videoEntry);
QDataStream& operator>>(QDataStream& in, VideoEntry& videoEntry);


#include <QMetaType>
Q_DECLARE_METATYPE(VideoEntry);

#endif // VIDEOENTRY_HH
