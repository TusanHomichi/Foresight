/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "CheckNewVideos.hh"
#include "FavoriteDataModel.hh"
#include "YoutubeItemManager.hh"
#include <QDebug>
#include <QProgressBar>

CheckNewVideos::CheckNewVideos()
{
  working_ = false;
  connect(&youtubeQuery_, SIGNAL(recentVideos(const std::vector<VideoEntry> &, int)), this, SLOT(recentVideos(const std::vector<VideoEntry> &, int)));
}
CheckNewVideos::CheckNewVideos(const CheckNewVideos& rhv)
{

}

CheckNewVideos& CheckNewVideos::operator=(const CheckNewVideos& rhv)
{
  return *this;
}

CheckNewVideos& CheckNewVideos::instance()
{
  static CheckNewVideos instance;
  return instance;
}

void CheckNewVideos::check(FavoriteDataModel* favorites, YoutubeItemManager* youtubeItemManager, QProgressBar *progress)
{
  if(working_) return;
  working_ = true;
  
  favoriteResultVector_.clear();
  currentIndex_ = 0;
  progress_ = progress;
  progress->setMaximum(favorites->rowCount());
  progress->setValue(0);
  
  youtubeItemManager_ = youtubeItemManager;
//   qDebug("RowCount: %d", favorites->rowCount());
  for(int i = 0; i < favorites->rowCount(); ++i)
    favoriteResultVector_.append(QPair<QString,int>(favorites->getName(i),0));
  youtubeQuery_.extractRecentVideos(YoutubeQuery::GeneralYoutubeQuery(YoutubeQuery::AUTHOR_VIDEOS, favoriteResultVector_[0].first,1, 25));
}

void CheckNewVideos::recentVideos(const std::vector< VideoEntry >& videoEntries, int videosCount)
{
  int countNew = 0;
  for(unsigned int i = 0; i < videoEntries.size(); ++i)
    if(!youtubeItemManager_->exists(videoEntries[i]))
      countNew++;
  favoriteResultVector_[currentIndex_++].second = countNew;
//   qDebug() << QString("Name: %1, new: %2").arg(favoriteResultVector_[currentIndex_-1].first).arg(countNew);
  progress_->setValue(currentIndex_);
  if(currentIndex_ < favoriteResultVector_.size())
  {
    youtubeQuery_.extractRecentVideos(YoutubeQuery::GeneralYoutubeQuery(YoutubeQuery::AUTHOR_VIDEOS, favoriteResultVector_[currentIndex_].first, 1, 25));
    
  }
  else
  {
    emit finishedCheckNewVideos(favoriteResultVector_);
    working_ = false;
  }
}
