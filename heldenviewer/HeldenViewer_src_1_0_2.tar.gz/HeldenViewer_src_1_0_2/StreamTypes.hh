/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef STREAMTYPES_HH
#define STREAMTYPES_HH

/**
  * Unique magic numbers for the 5 files which are written, they
  * are always written in the header of the file to make an integrity check
  * possible.
  */

const quint32 MAGIC_FAVORITES = 0x0000000A;
const quint32 MAGIC_YOUTUBEITEMMANAGER = 0x0000000B;
const quint32 MAGIC_YOUTUBEITEMMODEL = 0x0000000C;
const quint32 MAGIC_VIDEOENTRY_SHORT = 0x0000000D;
const quint32 MAGIC_VIDEOENTRY_LONG = 0x0000000E;


#endif