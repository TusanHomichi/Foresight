/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef VIDEOITEMWIDGET_HH
#define VIDEOITEMWIDGET_HH

#include <QWidget>
#include <QScrollArea>
#include <QBoxLayout>
#include <QMap>
#include "VideoEntry.hh"

class YoutubeItem;

/**
  * The VideoItemWidget is able to display the VideoItems in a list-like
  * fashion. It saves the relation between video entry and YoutubeItem in
  * a map.
  * The Mainwindow shows three instances of this class.
*/
class VideoItemWidget : public QWidget
{
public:
  enum WhichTab{SearchTab, DownloadingTab, DownloadedTab};
private:
  QScrollArea *scrollArea_;
  QWidget *containingWidget_;
  QVBoxLayout *boxLayout_;

  
  QMap<VideoEntry, YoutubeItem *> entryToItemMap_;
  int height_;
  WhichTab whichTab_;
  
  //! As the YoutubeItems carry no layout, the size has to be calculated manually
  //! this is rather tedious and definitely not the best choice - but it works.
  void setSizeCorrectly();
public:
  VideoItemWidget(QWidget* parent = 0, Qt::WindowFlags f = 0);
  //! Add a new YoutubeItem to the bottom of the list
  void addYoutubeItem(YoutubeItem *item);
  //! Delete all items
  void deleteAll();
  //! Get an item corresponding to the entry, if it does not exist, returns 0
  YoutubeItem *item(const VideoEntry &entry) const;
  //! Removes the item if it exists
  void removeItem(const VideoEntry &entry);
  //! Returns the number of YoutubeItems in the list
  int size();
  //! Specifies the three instances in the main window, is currently not used
  void setWhichTab(WhichTab whichTab);
  
  //! Provide access to the items
  QMap<VideoEntry, YoutubeItem *>::iterator begin();
  //! Provide access to the items
  QMap<VideoEntry, YoutubeItem *>::iterator end();
};

#endif // VIDEOITEMWIDGET_HH
