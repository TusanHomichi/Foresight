/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBEITEMCOLORS_HH
#define YOUTUBEITEMCOLORS_HH

#include <QString>
#include <QColor>
#include <QIcon>

class QComboBox;
class YoutubeItemModel;

/**
  * In order to give a visual feedback of the status of a video,
  * the YoutubeItems have different colors, the states are:
  * UNSEEN: Video has been downloaded, but has not been watched
  * SEEN: Video has been watched (this state occurs whenever the user clicks view
  * NEW: It is the first time the use sees this video in the search list
  * DOWNLOADING: A special color for videos which are currently downloaded
  * DEFAULT: This video is not new, but none of the other cases occur
*/

class YoutubeItemColors
{
public:
  enum ColorIndex{COLOR_UNSEEN=0, COLOR_SEEN, COLOR_NEW, COLOR_DOWNLOADING, COLOR_DEFAULT, COLOR_COUNT};
private:
  YoutubeItemColors();
  YoutubeItemColors(const YoutubeItemColors &rhv);
  YoutubeItemColors &operator=(const YoutubeItemColors &rhv);
  
  
  
  QColor colorVector_[COLOR_COUNT];
  QIcon colorIcons_[COLOR_COUNT];
  QString colorStrings_[COLOR_COUNT];
  
  QColor calcColor(YoutubeItemModel *model);
public:
  static YoutubeItemColors &instance();

  void saveColors();
  
  ColorIndex calcColorIndex(YoutubeItemModel *model);
  QString getColor(YoutubeItemModel *model);
  QString getColorFromIndex(ColorIndex index);
  
  void addComboboxItems(QComboBox *comboBox);
  void setComboboxItems(YoutubeItemModel *model, QComboBox *comboBox);
  void setViewState(YoutubeItemModel *model, int selected);
  
  QString getLabelText(YoutubeItemModel *model);
};

#endif // YOUTUBEITEMCOLORS_HH
