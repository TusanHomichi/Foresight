/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef FAVORITEDATAMODEL_HH
#define FAVORITEDATAMODEL_HH

#include <QAbstractListModel>
#include <QVector>

// class CustomType {
// public:
//   virtual ~CustomType() {}
//   virtual QVariant toVariant() const { return QVariant(); }
// };
// 
/**
  * Each row contains a FavoriteEntry, which holds the name of an author
  * and the number of new videos.
*/
struct FavoriteEntry /*: public CustomType*/
{
  QString name;
  int newEntries;
  
  FavoriteEntry():name("Name"),newEntries(0){}
  FavoriteEntry(const QString &name, int newEntries = 0) : name(name), newEntries(newEntries){}
/*  QString toString() const{return name + QString::number(newEntries);} 
  QVariant toVariant()  const
  {
    return QVariant(toString());
//     return QVariant::fromValue<FavoriteEntry>(*this);
  }*/
};


Q_DECLARE_METATYPE(FavoriteEntry);

class QMimeData;
//#include <QMimeData>

/**
  * Provides the model for the QListView class.
  * All necessary operations of QAbstractListModel are implemented, as well
  * as some custom functions to provide better usability.
*/

class FavoriteDataModel : public QAbstractListModel
{
  Q_OBJECT
  
  //! Each row is simply an entry of FavoriteEntry, providing name and
  //! the number of new videos of an author
  QVector<FavoriteEntry> entries_;
public:
  FavoriteDataModel(QObject* parent = 0);
  virtual int rowCount(const QModelIndex &parent = QModelIndex()) const;
  virtual int columnCount(const QModelIndex &parent = QModelIndex()) const;
  virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
  virtual bool setData ( const QModelIndex & index, const QVariant & value, int role = Qt::EditRole );
  virtual bool insertRows(int position, int rows, const QModelIndex &index = QModelIndex());
  virtual bool removeRows(int position, int rows, const QModelIndex &parent);
  virtual bool removeRow(int row, const QModelIndex &parent = QModelIndex());


  //! These functions are necessary to support moving of individual entries
  virtual Qt::DropActions supportedDropActions() const;
  virtual Qt::ItemFlags flags(const QModelIndex &index) const;
  virtual QMimeData *mimeData(const QModelIndexList &indexes) const;
  virtual QStringList mimeTypes() const;
  virtual bool dropMimeData(const QMimeData *data,
     Qt::DropAction action, int row, int column, const QModelIndex &parent);

//   QVariant headerData(int section, Qt::Orientation orientation, int role) const;
  
  void insert(const FavoriteEntry &entry);
  QString getName(int row);
  void setNewVideos(int row, int newVideos);
  bool contains(const QString &author);

  //! Stores the favorites in 
  //! SettingsManager::instance().dataDirectory() + "HeldenViewerFavorites.dat";
  void save();
  //! Loads the favorites from the above mentioned file
  void load();
};

#endif // FAVORITEDATAMODEL_HH
