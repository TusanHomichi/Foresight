<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:italic;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;;&quot;&gt;Copyright 2011&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt; Benjamin Held (&lt;/span&gt;&lt;a href=&quot;mailto:admin@heldenviewer.com&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;admin@heldenviewer.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:italic;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;;&quot;&gt;Copyright 2011&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt; Benjamin Held (&lt;/span&gt;&lt;a href=&quot;mailto:admin@heldenviewer.de&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;admin@heldenviewer.de&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer uses Qt 4.7 with dynamic linkage. Qt is licensed under the LGPL.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer is licensed under the GNU GPL version 3, see the file COPYING or &lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer benutzt Qt 4.7 (dynamisch gelinkt). Qt ist lizensiert unter der LGPL.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer ist lizensiert unter der GNU GPL Version 3, siehe die Datei COPYING oder &lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>HeldenViewer Version 1.0.2</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ConfigurationWizard</name>
    <message>
        <source>HeldenViewer - first start</source>
        <translation>HeldenViewer - Erster Start</translation>
    </message>
    <message>
        <source>HeldenViewer</source>
        <translation></translation>
    </message>
    <message>
        <source>Setup the video player</source>
        <translation>Wahl des Videoplayers</translation>
    </message>
    <message>
        <source>Welcome to HeldenViewer!</source>
        <translation>Herzlich Willkommen beim HeldenViewer!</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;In order to view the downloaded videos, you have to provide a path to a video player which is capable of playing .flv video files. HeldenViewer has been tested with the free VideoLAN Client. It can be downloaded at &lt;/span&gt;&lt;a href=&quot;http://www.videolan.org/vlc/&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.videolan.org/vlc/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Um die heruntergeladenen Videos anschauen zu können, müssen Sie den Pfad zu einem externen Videoplayer angeben, welcher in der Lage ist .flv Dateien abzuspielen. HeldenViewer wurde mit dem freien Videoplayer VideoLAN Client getestet. Die Software kann unter &lt;/span&gt;&lt;a href=&quot;http://www.videolan.org/vlc/&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.videolan.org/vlc/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; heruntergeladen werden.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Choose video player:</source>
        <translation>Wählen Sie einen Videoplayer:</translation>
    </message>
    <message>
        <source>..</source>
        <translation></translation>
    </message>
    <message>
        <source>Choose video save path:</source>
        <translation>Wählen Sie den Downloadpfad für die Videos:</translation>
    </message>
    <message>
        <source>You can change these values later on in the settings.</source>
        <translation>Sie können die Einstellungen später in den Optionen noch ändern.</translation>
    </message>
    <message>
        <source>Select Video player</source>
        <translation>Wählen Sie den Videoplayer</translation>
    </message>
    <message>
        <source>Select save path</source>
        <translation>Wählen Sie den Speicherort</translation>
    </message>
    <message>
        <source>No permission</source>
        <translation>Keine Berechtigung</translation>
    </message>
    <message>
        <source>Can not write to this directory. Please select another directory.</source>
        <translation>Für das Verzeichnis existieren keine Schreibrechte, bitte wählen Sie ein anderes Verzeichnis.</translation>
    </message>
    <message>
        <source>No permission for directory &quot;%1&quot;</source>
        <translation>Keine Schreibberechtigung für das Verzeichnis &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>FavoriteDataModel</name>
    <message>
        <source>FavoriteDataModel: Row index is out range, should not happen.</source>
        <translation>FavoriteDataModel: Zeilenindex ist ausserhalb des gültigen Bereichs. Fehler sollte nicht auftreten.</translation>
    </message>
    <message>
        <source>Could not open &quot;%1&quot; for reading.</source>
        <translation>Konnte die Datei &quot;%1&quot; nicht zum Lesen öffnen.</translation>
    </message>
    <message>
        <source>Header or version of favorites file is damaged.</source>
        <translation>Header oder Version der Favoritendatei ist fehlerhaft.</translation>
    </message>
    <message>
        <source>Could not open &quot;%1&quot; for writing</source>
        <translation>Konnte die Datei &quot;%1&quot; nicht zum Schreiben öffnen</translation>
    </message>
    <message>
        <source>%1 (new: %2)</source>
        <translation>%1 (neu: %2)</translation>
    </message>
    <message>
        <source>getName: index is not valid. Should not happen. Row: %1</source>
        <translation>getName: Index ist nicht gültig. Fehler sollte nicht auftreten. Zeile: %1</translation>
    </message>
</context>
<context>
    <name>FilesMissingDialog</name>
    <message>
        <source>Do you really want to delete the following files:
</source>
        <translation>Wollen Sie wirklich die folgenden Dateien löschen:
</translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation>Sind Sie sicher?</translation>
    </message>
    <message>
        <source>Error while deleting</source>
        <translation>Fehler beim löschen</translation>
    </message>
    <message>
        <source>HeldenViewer: Files are missing</source>
        <translation>HeldenViewer: Dateien fehlen</translation>
    </message>
    <message>
        <source>Some files have been changed on the hard drive and cannot be found or have different sizes since the last start of HeldenViewer. You have now the chance to move the files back and press the retry button. Otherwise HeldenViewer will delete the entries with missing video files. The following files are affected:</source>
        <translation>Ein paar Dateien wurden auf der Festplatte geändert und können entweder nicht gefunden werden oder besitzen eine andere Größe als beim letzten Start von HeldenViewer. Sie haben nun die Chance die Dateien wieder zurück zu verschieben und den &quot;Wiederholen&quot; Knopf zu betätigen. Anderenfalls wird HeldenViewer die Einträge löschen. Die folgenden Dateien sind betroffen:</translation>
    </message>
    <message>
        <source>Delete files with wrong size</source>
        <translation>Lösche Dateien mit falscher Größe</translation>
    </message>
    <message>
        <source>File does not exist:&quot;%1&quot;.</source>
        <translation>Datei existiert nicht: &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>File has the wrong size, the download cannot be resumed:&quot;%1&quot;.</source>
        <translation>Datei hat die falsche Größe, der Download kann nicht fortgesetzt werden: &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>Sorry</source>
        <translation></translation>
    </message>
    <message>
        <source>The videos could still not be found.</source>
        <translation>Die Videos wurden immer noch nicht gefunden.</translation>
    </message>
    <message>
        <source>Could not remove the file &quot;%1&quot;.</source>
        <translation>Die Datei &quot;%1&quot; konnte nicht gelöscht werden.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>HeldenViewer</source>
        <translation></translation>
    </message>
    <message>
        <source>Search results</source>
        <translation>Suchergebnisse</translation>
    </message>
    <message>
        <source>Videos</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Zeige</translation>
    </message>
    <message>
        <source>Show next videos</source>
        <translation>Zeige die nächsten Videos</translation>
    </message>
    <message>
        <source>Active downloads</source>
        <translation>Aktive Downloads</translation>
    </message>
    <message>
        <source>Completed downloads</source>
        <translation>Abgeschlossene Downloads</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <source>Video search</source>
        <translation>Videosuche</translation>
    </message>
    <message>
        <source>Search for video with keyword</source>
        <translation>Suche mit Schlüsselwort nach Video</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favoriten</translation>
    </message>
    <message>
        <source>&amp;Neues Spiel</source>
        <translation></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>B&amp;eenden</translation>
    </message>
    <message>
        <source>About HeldenViewer</source>
        <translation>Über HeldenViewer</translation>
    </message>
    <message>
        <source>Favorite actions</source>
        <translation></translation>
    </message>
    <message>
        <source>Add favorite</source>
        <translation>Füge Favorit hinzu</translation>
    </message>
    <message>
        <source>Delete item</source>
        <translation>Lösche Eintrag</translation>
    </message>
    <message>
        <source>Check for new favorites&apos; videos</source>
        <translation>Prüfe auf neue Favoriten Videos</translation>
    </message>
    <message>
        <source>New videos</source>
        <translation>Neue Videos</translation>
    </message>
    <message>
        <source>There are %1 new video(s).</source>
        <translation>Es gibt %1 neue Video(s).</translation>
    </message>
    <message>
        <source>No new videos</source>
        <translation>Keine neuen Videos</translation>
    </message>
    <message>
        <source>There are no new videos.</source>
        <translation>Es gibt keine neuen Videos.</translation>
    </message>
    <message>
        <source>Video number</source>
        <translation>Videonummer</translation>
    </message>
    <message>
        <source>Only 50 entries can be shown at once.</source>
        <translation>Es können nur 50 Einträge gleichzeitig gezeigt werden.</translation>
    </message>
    <message>
        <source>Searches the metadata of all videos containing the keyword. The metadata consists of title, author, tags, ...</source>
        <translation>Durchsucht die Metadaten aller Videos nach dem Keyword. Die Metadaten beinhalten Titel, Autor, Tags, ...</translation>
    </message>
    <message>
        <source>Author&apos;s videos</source>
        <translation>Videos eines bestimmten Autors</translation>
    </message>
    <message>
        <source>Show videos of author</source>
        <translation>Zeige Videos des Autors</translation>
    </message>
    <message>
        <source>You have to provide the exact name of the author.</source>
        <translation>Sie müssen den exakten Namen des Autors kennen.</translation>
    </message>
    <message>
        <source>Press the right mouse button to add new favorites or delete a favorit.</source>
        <translation>Drücken Sie die rechte Maustaste, um neue Favoriten hinzuzufügen oder existierende zu löschen.</translation>
    </message>
    <message>
        <source>Depending on the number of favorites, this can take a while.</source>
        <translation>Je nach Favoritenanzahl kann der Vorgang einen Moment dauern.</translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation>Sind Sie sicher?</translation>
    </message>
    <message>
        <source>Video could not be deleted.</source>
        <translation>Video konnte nicht gelöscht werden.</translation>
    </message>
    <message>
        <source>The video %1 - %2 could not be deleted.</source>
        <translation>Das Video %1 - %2 konnte nicht gelöscht werden.</translation>
    </message>
    <message>
        <source>Delete all completed videos</source>
        <translation>Lösche alle heruntergeladenen Videos</translation>
    </message>
    <message numerus="yes">
        <source>%n of those videos are unseen.</source>
        <translation>
            <numerusform> Ein Video wurde davon noch nicht gesehen.</numerusform>
            <numerusform>%n der Videos wurden noch nicht gesehen.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to delete all %n completed videos?</source>
        <translation>
            <numerusform>Wollen Sie wirklich das eine heruntergeladene Video löschen?</numerusform>
            <numerusform>Wollen Sie wirklich die %n heruntergeladenen Videos löschen?</numerusform>
        </translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <source>Sorry, author is already a favorite</source>
        <translation>Sorry, der Autor ist bereits in der Favoritenliste</translation>
    </message>
    <message>
        <source>The author &quot;%1&quot; is already added to your favorite list</source>
        <translation>Der Autor &quot;%1&quot; is bereits in Ihrer Favoriteliste</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation>Suche nach Update</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <source>Getting help</source>
        <translation>Wo findet man Hilfe?</translation>
    </message>
    <message>
        <source>Please visit &lt;a href=&apos;www.heldenviewer.com&apos;&gt;www.heldenviewer.com&lt;/a&gt; and check out the FAQ. If this does not answer your question, send a message to admin@heldenviewer.com</source>
        <translation>Bitte besuchen Sie &lt;a href=&apos;www.heldenviewer.de&apos;&gt;www.heldenviewer.de&lt;/a&gt; und schauen, ob ihre Frage bereits in der FAQ beantwortet wurde, ansonsten schicken Sie eine Nachricht an admin@heldenviewer.de</translation>
    </message>
    <message>
        <source>Clear active downloads</source>
        <translation>Lösche alle aktiven Downloads</translation>
    </message>
    <message>
        <source>Do you really want to delete all active downloads?</source>
        <translation>Wollen Sie wirklich alle aktiven Downloads löschen?</translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>Move files to new location</source>
        <translation>Verschiebe Dateien an neuen Ort</translation>
    </message>
    <message>
        <source>If you wish to change the output directory, then all %1 files which have been (partially) downloaded, will be copied to the new location and then removed from the old location. %2MB free space are required for this operation. Continue?</source>
        <translation>Wenn Sie das Outputverzeichnis verändern möchten, dann werden alle %1 Dateien, die bereits (teilweise) heruntergeladen wurden, in das neue Verzeichnis kopiert und aus dem alten Verzeichnis gelöscht. Für die Operation werden %2MB freier Speicher benötigt. Wollen Sie fortfahren?</translation>
    </message>
    <message>
        <source>File exists, overwrite?</source>
        <translation>Datei existiert bereits, überschreiben?</translation>
    </message>
    <message>
        <source>The file %1 exists. Overwrite the existing file?</source>
        <translation>Die Datei %1 existiert bereits. Datei überschreiben?</translation>
    </message>
    <message>
        <source>Error while copying file</source>
        <translation>Fehler beim Kopieren der Datei</translation>
    </message>
    <message>
        <source>Sorry, but an error occurred while copying the file %1 to %2. Now all files which have already been copied will be removed.</source>
        <translation>Ein Fehler trat beim kopieren der Datei %1 nach %2 auf. Es werden jetzt alle Dateien gelöscht die bereits kopiert wurden.</translation>
    </message>
    <message>
        <source>HeldenViewer - Options</source>
        <translation>HeldenViewer - Optionen</translation>
    </message>
    <message>
        <source>Download quality</source>
        <translation>Download Qualität</translation>
    </message>
    <message>
        <source>Select default quality:</source>
        <translation>Wähle standardmäßige Qualität</translation>
    </message>
    <message>
        <source>1080p</source>
        <translation></translation>
    </message>
    <message>
        <source>720p</source>
        <translation></translation>
    </message>
    <message>
        <source>480p</source>
        <translation></translation>
    </message>
    <message>
        <source>320p</source>
        <translation></translation>
    </message>
    <message>
        <source>240p</source>
        <translation></translation>
    </message>
    <message>
        <source>If default is not available, use</source>
        <translation>Wenn die standardmäßige Qualität nicht verfügbar ist, benutze</translation>
    </message>
    <message>
        <source>Higher quality</source>
        <translation>Höhere Qualität</translation>
    </message>
    <message>
        <source>Lower quality</source>
        <translation>Niedrigere Qualität</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Pfade</translation>
    </message>
    <message>
        <source>..</source>
        <translation></translation>
    </message>
    <message>
        <source>Select Video player</source>
        <translation>Wähle Videoplayer</translation>
    </message>
    <message>
        <source>Select save path</source>
        <translation>Wähle Speicherort</translation>
    </message>
    <message>
        <source>No permission</source>
        <translation>Keine Berechtigung</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>Choose language:</source>
        <translation>Sprache wählen:</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Englisch</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <source>Save videos to:</source>
        <translation>Speichere Videos nach</translation>
    </message>
    <message>
        <source>Logfile</source>
        <translation>Logdatei</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Anschauen</translation>
    </message>
    <message>
        <source>Select video player (must be able to play .flv files):</source>
        <translation>Wählen Sie einen Videoplayer, der .flv Dateien abspielen kann</translation>
    </message>
    <message>
        <source>Can not write to this directory. Please select another directory.</source>
        <translation>Für das Verzeichnis existieren keine Schreibrechte, bitte wählen Sie ein anderes Verzeichnis.</translation>
    </message>
    <message>
        <source>No permission for directory &quot;%1&quot;</source>
        <translation>Keine Schreibberechtigung für das Verzeichnis &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation></translation>
    </message>
    <message>
        <source>Host (leave empty for no proxy)</source>
        <translation>Host (leer lassen damit kein Proxy benutzt wird)</translation>
    </message>
    <message>
        <source>Username (optional)</source>
        <translation>Benutzername (optional)</translation>
    </message>
    <message>
        <source>Password (optional)</source>
        <translation>Passwort (optional)</translation>
    </message>
    <message>
        <source>Port (optional)</source>
        <translation>Port (optional)</translation>
    </message>
    <message>
        <source>General settings</source>
        <translation>Generelle Einstellungen</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>The application HeldenViewer is already running, only one instance can run at the same time.</source>
        <translation>Die Anwendung HeldenViewer läuft bereits, es kann nur eine Instanz gleichzeitig laufen.</translation>
    </message>
    <message>
        <source>Sorry, HeldenViewer is already running.</source>
        <translation>Sorry, HeldenViewer läuft bereits.</translation>
    </message>
    <message>
        <source>ERROR: No quality in map</source>
        <translation>Fehler: Keine Downloadqualität existiert in der Map</translation>
    </message>
    <message>
        <source>Could not find Quality.</source>
        <translation>Konnte keine passende Downloadqualität finden.</translation>
    </message>
    <message>
        <source>Could not create path &quot;%1&quot;</source>
        <translation>Konnte den Pfad &quot;%1&quot; nicht erzeugen</translation>
    </message>
    <message>
        <source> minutes</source>
        <translation> Minuten</translation>
    </message>
    <message>
        <source>Not reading a VideoEntry or the version is incorrect. magic: %1, version: %2</source>
        <translation>Konnte keinen VideoEntry lesen oder die Version ist falsch. Magic: %1, version: %2</translation>
    </message>
    <message>
        <source>Not reading a VideoEntry or the version is incorrect.</source>
        <translation>Konnte keinen VideoEntry lesen oder die Version ist falsch.</translation>
    </message>
    <message>
        <source>Could not set video id, this should not happen.</source>
        <translation>Konnte die VideoId nicht setzen, das sollte nicht passieren.</translation>
    </message>
    <message>
        <source>Could not open %1</source>
        <translation>Konnte die Datei %1 nicht öffnen</translation>
    </message>
    <message>
        <source>Could not read %1</source>
        <translation>Konnte die Datei %1 nicht zum Lesen öffnen</translation>
    </message>
    <message>
        <source>Reading data file: Version is unknown: %1</source>
        <translation>Lese Datendatei: Version ist unbekannt: %1</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Fehler: %1</translation>
    </message>
    <message>
        <source> hours</source>
        <translation> Stunden</translation>
    </message>
    <message>
        <source>Unseen</source>
        <translation>Ungesehen</translation>
    </message>
    <message>
        <source>Seen</source>
        <translation>Gesehen</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation>Downloading</translation>
    </message>
    <message>
        <source>Known</source>
        <translation>Bekannt</translation>
    </message>
</context>
<context>
    <name>UpdateChecker</name>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Could not check for updates.
 Error string: %1</source>
        <translation>Konnte nicht nach Updates suchen, Fehler: %1</translation>
    </message>
    <message>
        <source>Could not retrieve the current version of HeldenViewer.</source>
        <translation>Konnte die aktuelle Version von HeldenViewer nicht herausfinden, versuchen Sie es bitte später nochmal.</translation>
    </message>
    <message>
        <source>New version available</source>
        <translation>Neu Version ist verfügbar</translation>
    </message>
    <message>
        <source>Version %1 of HeldenViewer is available, you can download it at &lt;a href=&apos;www.heldenviewer.com&apos;&gt;www.heldenviewer.com&lt;/a&gt;. </source>
        <translation>Version %1 des HeldenViewers ist verfügbar. Sie können die Version auf &lt;a href=&apos;www.heldenviewer.de&apos;&gt;www.heldenviewer.de&lt;/a&gt; downloaden.</translation>
    </message>
    <message>
        <source>No new version available</source>
        <translation>Keine neue Version verfügbar</translation>
    </message>
    <message>
        <source>HeldenViewer is up to date.</source>
        <translation>HeldenViewer ist auf dem neusten Stand.</translation>
    </message>
    <message>
        <source>HeldenViewer is up to date. </source>
        <translation>HeldenViewer ist auf dem neusten Stand. </translation>
    </message>
</context>
<context>
    <name>YoutubeItem</name>
    <message>
        <source>Resume download</source>
        <translation>Download fortsetzen</translation>
    </message>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation>Vorschaubild</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <source>Views</source>
        <translation>Betrachtungen</translation>
    </message>
    <message>
        <source>Duration</source>
        <translation>Dauer</translation>
    </message>
    <message>
        <source>Start Download</source>
        <translation>Starte Download</translation>
    </message>
    <message>
        <source>Published</source>
        <translation>Hochgeladen</translation>
    </message>
    <message>
        <source>0MB / 1MB</source>
        <translation></translation>
    </message>
    <message>
        <source>View</source>
        <translation>Anschauen</translation>
    </message>
    <message>
        <source>Delete Video</source>
        <translation>Lösche Video</translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation>Qualität:</translation>
    </message>
    <message>
        <source>1080p</source>
        <translation></translation>
    </message>
    <message>
        <source>720p</source>
        <translation></translation>
    </message>
    <message>
        <source>480p</source>
        <translation></translation>
    </message>
    <message>
        <source>320p</source>
        <translation></translation>
    </message>
    <message>
        <source>240p</source>
        <translation></translation>
    </message>
    <message>
        <source>Error while starting external player</source>
        <translation>Fehler beim Starten des Videoplayers</translation>
    </message>
    <message>
        <source>Please navigate to File/Edit Options and check the path to the external video player, it could not be started.</source>
        <translation>Der externe Videoplayer konnte nicht ordnungsgemäß gestartet werden. Bitte gehen Sie ins Menü und überprüfen den Pfad zum Videoplayer.</translation>
    </message>
    <message>
        <source> viewers</source>
        <translation> Betrachter</translation>
    </message>
    <message>
        <source>Start download</source>
        <translation>Starte Download</translation>
    </message>
    <message>
        <source>Stop download</source>
        <translation>Stoppe Download</translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation>Sind Sie sicher?</translation>
    </message>
    <message>
        <source>Do you really want to delete this video from your hard drive?</source>
        <translation>Wollen Sie das Video wirklich von der Festplatte löschen?</translation>
    </message>
    <message>
        <source>Add author &quot;%1&quot; as favorite</source>
        <translation>Füge den Autor &quot;%1&quot; als Favorit hinzu</translation>
    </message>
</context>
<context>
    <name>YoutubeItemModel</name>
    <message>
        <source>Not reading a YoutubeItemModel or the version is incorrect. magic: [%1], version: [%2]</source>
        <translation>Konnte kein YoutubeItemModel lesen oder die Version ist falsch. Magic: [%1], version: [%2]</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Fehler: %1</translation>
    </message>
    <message>
        <source>Could not open file for writing</source>
        <translation>Konnte die Datei nicht zum schreiben öffnen</translation>
    </message>
    <message>
        <source>writeRawData returned an error.</source>
        <translation>writeRawData hat einen Fehler verursacht.</translation>
    </message>
    <message>
        <source>An error occured</source>
        <translation>Ein Fehler trat auf</translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation>Die Datei %1 existiert nicht.</translation>
    </message>
    <message>
        <source>Could not delete video file: %1.</source>
        <translation>Konnte die Videodatei %1 nicht löschen.</translation>
    </message>
</context>
<context>
    <name>YoutubeLoader</name>
    <message>
        <source>Wrong size of fmt_stream_map structure: %1</source>
        <translation>Fehlerhafte Größe in fmt_stream_map: %1</translation>
    </message>
    <message>
        <source>An error occured, trying to access the url to get the flash data.
 Error string: %1</source>
        <translation>Ein Fehler trat auf beim Öffnen der Flash URL.
Fehler: %1</translation>
    </message>
    <message>
        <source>An error occured, trying to access the video url.
 Error string: %1</source>
        <translation>Ein Fehler trat auf beim Öffnen der Video URL.
Fehler: %1</translation>
    </message>
    <message>
        <source>An error occured, trying to access the header of the video url.
 Error string: %1</source>
        <translation>Ein Fehler trat auf beim Öffnen der Video Header URL.
Fehler: %1</translation>
    </message>
    <message>
        <source>Requesting to start at byte %1, but only %2 are available</source>
        <translation>Das Video sollte ab Byte %1 heruntergeladen werden, aber es hat nur eine Größe von %2</translation>
    </message>
    <message>
        <source>The file already exists and has most likely been downloaded in a lower quality. Please delete the file </source>
        <translation>Die Datei existiert bereits und wurde womöglich in einer niedrigeren Qualität heruntergeladen. Bitte löschen Sie die Videodatei</translation>
    </message>
    <message>
        <source>The video size could not be retrieved and so the video cannot be retrieved either, url was &quot;%1&quot;</source>
        <translation>Die Videogrößte konnte nicht empfangen werden. Die Url ist &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>YoutubeQuery</name>
    <message>
        <source>Coult not retrieve the number of videos of the author</source>
        <translation>Konnte die Anzahl der Videos des Autors nicht abfragen</translation>
    </message>
    <message>
        <source>Serious Error: Could not find network reply in map.</source>
        <translation>Schwerer Fehler: Das Network reply konnte nicht gefunden werden.</translation>
    </message>
    <message>
        <source>No data could be retrieved for the author.
 Error string: %1</source>
        <translation>Es konnten keine Daten für den Author empfangen werden
Fehler: %1</translation>
    </message>
    <message>
        <source>Author could not be extracted</source>
        <translation>Der Author konnte nicht extrahiert werden</translation>
    </message>
    <message>
        <source>No data could be retrieved for the author, most likely the author does not exist. Please try to use the video search and get the exact name of the author.</source>
        <translation>Es konnten keine Daten für den Author abgefragt werden, wahrscheinlich existiert der Autor nicht. Bitte versuchen Sie über die Keyword Videosuche den genauen Namen des Autors herauszufinden.</translation>
    </message>
    <message>
        <source>No videos with the provided keywords were found.</source>
        <translation>Es konnten keine Videos mit den Keywords gefunden werden.</translation>
    </message>
    <message>
        <source>Sorry</source>
        <translation></translation>
    </message>
    <message>
        <source>Could not download thumbnail.
 Error string: %1</source>
        <translation>Konnte das Vorschaubild nicht herunterladen. Fehler: %1</translation>
    </message>
    <message>
        <source>No bytes are available, request type: %1</source>
        <translation>Es sind keine Bytes verfügbar, Request type: %1</translation>
    </message>
    <message>
        <source>Could not load image from data</source>
        <translation>Konnte das Bild nicht laden</translation>
    </message>
</context>
</TS>
