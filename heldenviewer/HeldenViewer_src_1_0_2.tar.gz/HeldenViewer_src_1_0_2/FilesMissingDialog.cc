/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "FilesMissingDialog.hh"
#include "YoutubeItemManager.hh"
#include <QFileInfo>
#include <QMessageBox>
#include <QDir>

FilesMissingDialog::FilesMissingDialog(YoutubeItemManager *youtubeItemManager, QVector<VideoEntry> &entries, QVector<FileInfo> &fileInfo,QWidget* parent, Qt::WindowFlags f)
: QDialog(parent, f), youtubeItemManager_(youtubeItemManager), entries_(entries), fileInfo_(fileInfo)
{
  setupUi(this);
  
//   QString message = "Some video files have been changed on the file system, the files will be listed below. All entries concerning these files will be removed, if you cannot ensure the integrity.<br><br>";
  setTextEditMessage();
  connect(bb_buttons, SIGNAL(clicked ( QAbstractButton * )), this, SLOT(buttonClicked ( QAbstractButton * )));
  pb_deleteFiles->hide();
  connect(pb_deleteFiles, SIGNAL(clicked()), this, SLOT(deleteFiles()));
  
  for(int i = 0; i < fileInfo.size(); ++i)
    if(fileInfo[i].fileError == FileInfo::BYTE_MISMATCH) pb_deleteFiles->show();
}


bool FilesMissingDialog::videosMissing(const QVector< VideoEntry >& entries, QVector<FileInfo> &fileInfo)
{
  for(int i = 0; i < entries.size(); ++i)
  {
    if(entries[i].bytesDownloaded == 0) continue;
    QString filename = SettingsManager::instance().filePath(entries[i]);
    if(!QFileInfo(filename).exists())
      fileInfo.append(FileInfo(i, tr("File does not exist:\"%1\".").arg(filename), FileInfo::FILE_DOES_NOT_EXIST));
    else if(QFileInfo(filename).size() != entries[i].bytesDownloaded)
      fileInfo.append(FileInfo(i, tr("File has the wrong size, the download cannot be resumed:\"%1\".").arg(filename), FileInfo::BYTE_MISMATCH));
  }
  
  return fileInfo.size() != 0;
}


void FilesMissingDialog::setTextEditMessage()
{
  QString message;
  for(int i = 0; i < fileInfo_.size(); ++i)
  {
    message += fileInfo_[i].message + "<br><br>";
  }
  te_files->setText(message);

}


void FilesMissingDialog::buttonClicked(QAbstractButton* button)
{
  QVector<FileInfo> oldList = fileInfo_;
  fileInfo_.clear();
  videosMissing(entries_, fileInfo_);
  if(button == (QAbstractButton *)bb_buttons->button(QDialogButtonBox::Retry))
  {
    if(oldList == fileInfo_)
    {
      QMessageBox::information(this, tr("Sorry"), tr("The videos could still not be found."));
    }
    else
      setTextEditMessage();
    
  }
  else if(button == (QAbstractButton *)bb_buttons->button(QDialogButtonBox::Ok))
  {

    close();
  }
}

void FilesMissingDialog::accept()
{
//   QDialog::accept();
  
}

bool operator==(const FileInfo& lhv, const FileInfo& rhv)
{
  return lhv.fileError == rhv.fileError && lhv.index == rhv.index && lhv.message == rhv.message;
}

void FilesMissingDialog::deleteFiles()
{
  QString message = tr("Do you really want to delete the following files:\n");
  for(int i = 0; i < fileInfo_.size(); ++i)
    if(fileInfo_[i].fileError == FileInfo::BYTE_MISMATCH)
    {
      QString filename = SettingsManager::instance().filePath(entries_[fileInfo_[i].index]);

      message += filename + "\n";
    }
  if(QMessageBox::question(this, tr("Are you sure?"), message, QMessageBox::Yes|QMessageBox::No) == QMessageBox::Yes)
  {
//     qDebug("HERE");
    QDir dir;
    for(int i = 0; i < fileInfo_.size(); ++i)
      if(fileInfo_[i].fileError == FileInfo::BYTE_MISMATCH)
      {
        QString filename = SettingsManager::instance().filePath(entries_[fileInfo_[i].index]);
        if(!dir.remove(filename))
          QMessageBox::warning(this, tr("Error while deleting"), tr("Could not remove the file \"%1\".").arg(filename));
        else
        {
          entries_[fileInfo_[i].index].bytesDownloaded = 0;
          youtubeItemManager_->videoFileDeleted(entries_[fileInfo_[i].index]);
//           entries_[fileInfo_[i].index].bytesDownloaded = 0;
        }
      }
      
    fileInfo_.clear();
    videosMissing(entries_, fileInfo_);
    setTextEditMessage();
  }
}

void FilesMissingDialog::closeEvent(QCloseEvent* event)
{
  for(int i = 0; i < fileInfo_.size(); ++i)
  {
    entries_[fileInfo_[i].index].bytesDownloaded = 0;
    youtubeItemManager_->videoFileDeleted(entries_[fileInfo_[i].index]);
  }
    
  QDialog::closeEvent(event);
}
