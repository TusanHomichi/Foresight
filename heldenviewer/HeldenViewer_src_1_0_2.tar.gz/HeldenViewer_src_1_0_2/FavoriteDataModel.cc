/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "FavoriteDataModel.hh"
#include "SettingsManager.hh"
#include "StreamTypes.hh"
#include <QMimeData>
#include <QStringList>
#include <QFile>
#include <QDebug>
#include <QLabel>

FavoriteDataModel::FavoriteDataModel(QObject* parent): QAbstractListModel(parent)
{
}


int FavoriteDataModel::columnCount(const QModelIndex& parent) const
{
  return 2;
}
int FavoriteDataModel::rowCount(const QModelIndex& parent) const
{
  return entries_.size();
}
QVariant FavoriteDataModel::data(const QModelIndex& index, int role) const
{
  if (!index.isValid())
    return QVariant();

  if(index.row() >= entries_.size())
  {
    qDebug() << tr("FavoriteDataModel: Row index is out range, should not happen.");
    return QVariant();
  }
  if (role == Qt::DisplayRole) 
  {

    if(index.column() == 0)
    {
      if(entries_[index.row()].newEntries)
      {
        return tr("%1 (new: %2)").arg(entries_[index.row()].name).arg(entries_[index.row()].newEntries);
//         return entries_[index.row()].name + tr(" (new: ") + QString::number(entries_[index.row()].newEntries) + ")";
      }
      else
        return entries_[index.row()].name;
    }
  }
  else if(role == Qt::EditRole)
  {
    return entries_[index.row()].name;
  }
  
//   qDebug("FavoriteDataModel: Column index is out range, should not happen.");
  return QVariant();
}

void FavoriteDataModel::insert(const FavoriteEntry& entry)
{
  beginInsertRows(QModelIndex(), entries_.size(), entries_.size());

  entries_.append(entry);
  
  endInsertRows();
}

bool FavoriteDataModel::setData(const QModelIndex& index, const QVariant& value, int role)
{
  /*qDebug("HIER");*/
  if(!index.isValid()) return false;
  if(role == Qt::DisplayRole)
  {
//     qDebug("row: %d, column: %d", index.row(), index.column());
    if(index.column() == 0)
    {
      entries_[index.row()] = value.value<FavoriteEntry>();
      emit dataChanged(index,index);
      return true;
    }
  }
  else if(role == Qt::EditRole)
  {
    if(index.column() == 0)
    {
      entries_[index.row()].name = value.toString();
      emit dataChanged(index,index);
      return true;
    }
//       qDebug("EDIT: %s", value.toString().toLatin1().data());
  }
  return false;
}

bool FavoriteDataModel::insertRows(int position, int rows, const QModelIndex& index)
{
  beginInsertRows(QModelIndex(), position, position+rows-1);

//   qDebug("Insert rows");
  for (int row = 0; row < rows; ++row) 
  {
      entries_.insert(position, FavoriteEntry());
  }

  endInsertRows();
  return true;
}

bool FavoriteDataModel::removeRow(int row, const QModelIndex &parent)
{
  return removeRows(row, 1, parent);
}

bool FavoriteDataModel::removeRows(int position, int rows, const QModelIndex &parent)
{
  beginRemoveRows(QModelIndex(), position, position+rows-1);

  entries_.erase(entries_.begin()+position, entries_.begin()+position+rows);

  endRemoveRows();
  return true;
}

Qt::DropActions FavoriteDataModel::supportedDropActions() const
{
  return Qt::MoveAction;
}

Qt::ItemFlags FavoriteDataModel::flags(const QModelIndex &index) const
{
  Qt::ItemFlags defaultFlags = QAbstractItemModel::flags(index);

  if (index.isValid())
    return Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled | Qt::ItemIsEditable | defaultFlags;
  else
    return Qt::ItemIsDropEnabled | defaultFlags;
}

QDataStream &operator<<(QDataStream &out, const FavoriteEntry &entry)
{
  out << entry.name;
  out << entry.newEntries;
  return out;
}

QDataStream &operator>>(QDataStream &in, FavoriteEntry &entry)
{
  in >> entry.name;
  in >> entry.newEntries;
  return in;
}


QMimeData *FavoriteDataModel::mimeData(const QModelIndexList &indexes) const
{
  QMimeData *mimeData = new QMimeData();
  QByteArray encodedData;

  QDataStream stream(&encodedData, QIODevice::WriteOnly);

  foreach (const QModelIndex &index, indexes) 
  {
    if (index.isValid()) 
    {
      stream << entries_[index.row()];
      stream << index.row();
    }
  }

  mimeData->setData("application/heldenviewer.favorites.list", encodedData);
  
  return mimeData;
}

QStringList FavoriteDataModel::mimeTypes() const
{
  QStringList types;
  types << "application/heldenviewer.favorites.list";
  return types;
}

bool FavoriteDataModel::dropMimeData(const QMimeData *data,
     Qt::DropAction action, int row, int column, const QModelIndex &parent)
{
//     qDebug("row: %d, col: %d, parent.row: %d", row, column, parent.row());
  if (action == Qt::IgnoreAction)
    return true;
  if (!data->hasFormat("application/heldenviewer.favorites.list"))
    return false;

  if (column > 0)
    return false;
  
  int beginRow;

  if (row != -1)
    beginRow = row;  
  else if (parent.isValid())
    beginRow = parent.row();
  else
    beginRow = rowCount(QModelIndex());
  
  QByteArray encodedData = data->data("application/heldenviewer.favorites.list");
  QDataStream stream(&encodedData, QIODevice::ReadOnly);
  QVector<FavoriteEntry> newItems;
  QVector<int> rows;
  while (!stream.atEnd()) 
  {
    FavoriteEntry entry;
    stream >> entry;
    int rowIndex;
    stream >> rowIndex;
    rows.append(rowIndex);
    newItems.append(entry);
  }
  
  //Remove all indices > beginRow, this can savely be done
  if(action == Qt::MoveAction)
  {
    qSort(rows.begin(), rows.end());
    for(int i = rows.count()-1; i >= 0; --i)
      if(rows[i] > beginRow)
      {
        removeRow(rows[i]);
        rows.erase(rows.begin()+i);
      }
  }  
  if(!newItems.size()) return false;

  insertRows(beginRow, newItems.count(), QModelIndex());
  foreach (const FavoriteEntry &entry, newItems) 
  {
    QModelIndex idx = index(beginRow, 0, QModelIndex());
    setData(idx, QVariant::fromValue<FavoriteEntry>(entry),Qt::DisplayRole);
    beginRow++;
  }
  
  //Now delete all indices before beginRow
  if(action == Qt::MoveAction)
  {
    for(int i = rows.count()-1; i >= 0; --i)
      removeRow(rows[i]);
  }
  return true;
}

QString FavoriteDataModel::getName(int row)
{
  if(row < 0 || row >= entries_.size())
  {
    qDebug() << tr("getName: index is not valid. Should not happen. Row: %1").arg(row);
    return "";
  }
  return entries_[row].name;
}


void FavoriteDataModel::load()
{
  QString location = SettingsManager::instance().dataDirectory() + "HeldenViewerFavorites.dat";
  QFile file(location);
  if(!file.open(QIODevice::ReadOnly))
  {
    qDebug() << tr("Could not open \"%1\" for reading.").arg(location);
    return;
  }

  QDataStream in(&file);
  in.setVersion(QDataStream::Qt_4_6);
//   QString header, version;
  quint32 magicHeader, version;
  
  in >> magicHeader; in >> version;
  
  if(magicHeader != MAGIC_FAVORITES || version != 1)
  {
    qDebug() << tr("Header or version of favorites file is damaged.");
    return;
  }
  
  int count;
  in >> count;
  
  for(int i = 0; i < count; ++i)
  {
    QString name;
    in >> name;
    insert(FavoriteEntry(name,0));
  }
}
void FavoriteDataModel::save()
{
  QString location = SettingsManager::instance().dataDirectory() + "HeldenViewerFavorites.dat";
  QFile file(location);
  if(!file.open(QIODevice::WriteOnly))
  {
    qDebug() << tr("Could not open \"%1\" for writing").arg(location);
    return;
  }
  
  QDataStream out(&file);
  out.setVersion(QDataStream::Qt_4_6);
  
//   out << QString("HeldenViewerFavorites");
  out << MAGIC_FAVORITES;
  out << quint32(1);
  
  out << entries_.count();
  
  for(QVector<FavoriteEntry>::iterator it = entries_.begin(); it != entries_.end(); ++it)
    out << it->name;
}

void FavoriteDataModel::setNewVideos(int row, int newVideos)
{
  if(row < 0|| row >= rowCount()) return;
  entries_[row].newEntries = newVideos;
  
  emit dataChanged(index(row),index(row));
}

bool FavoriteDataModel::contains(const QString &author)
{
  for(QVector<FavoriteEntry>::iterator it = entries_.begin(); it != entries_.end(); ++it)
    if(!it->name.compare(author,Qt::CaseInsensitive))
      return true;
  return false;
  
}