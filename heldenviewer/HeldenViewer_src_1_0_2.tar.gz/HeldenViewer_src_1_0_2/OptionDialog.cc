/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "OptionDialog.hh"
#include "SettingsManager.hh"
#include "YoutubeItemManager.hh"
#include "YoutubeItemModel.hh"
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QProcess>

OptionDialog::OptionDialog(YoutubeItemManager *youtubeItemManager, QWidget* parent)
: QDialog(parent), youtubeItemManager_(youtubeItemManager)
{
  setupUi(this);
	sw_stackedOptions->setCurrentIndex(0);
  connect(pb_choosePlayer, SIGNAL(clicked()), this, SLOT(selectVideoPlayerDir()));
  connect(pb_saveVideoPath, SIGNAL(clicked()), this, SLOT(saveVideoPath()));
  connect(pb_viewLogFile, SIGNAL(clicked()), this, SLOT(viewLogFile()));
  connect(lw_categories, SIGNAL(currentRowChanged ( int )), sw_stackedOptions, SLOT(	setCurrentIndex ( int )));
	connect(bb_ok, SIGNAL(accepted()), this, SLOT(accept()));
	connect(bb_ok, SIGNAL(rejected()), this, SLOT(reject()));
	
  loadSettings();
  le_logFilePath->setText(SettingsManager::instance().logFilePath());
}

void OptionDialog::loadSettings()
{
  const QSettings &settings = SettingsManager::instance().settings();
  
  cb_defaultQuality->setCurrentIndex(settings.value("Options/defaultQuality", 0).toInt());
  if(settings.value("Options/higherQuality", false).toBool())
    rb_higherQuality->setChecked(true);
  else
    rb_lowerQuality->setChecked(true);
  le_externalPlayer->setText(settings.value("Options/externalPlayer", "").toString());
  //le_saveVideoPath->setText(settings.value("Options/saveVideoPath", QDir::currentPath()).toString());
  //if(le_saveVideoPath->text() == "") le_saveVideoPath->setText(QDir::currentPath());
  le_saveVideoPath->setText(SettingsManager::instance().savePath());
  oldSavePath = le_saveVideoPath->text();
	
  //Restore proxy settings
	le_hostname->setText(settings.value("Options/Proxy/hostname", "").toString());
	le_username->setText(settings.value("Options/Proxy/username", "").toString());
	le_password->setText(settings.value("Options/Proxy/password", "").toString());
	sb_port->setValue(settings.value("Options/Proxy/port", 0).toInt());

  cb_language->setCurrentIndex(settings.value("Options/language", QLocale::system().name().left(2) == "de" ? 1 : 0).toInt());
}

void OptionDialog::saveSettings()
{
  QSettings &settings = SettingsManager::instance().settings();
  
  settings.beginGroup("Options");
    settings.setValue("defaultQuality", cb_defaultQuality->currentIndex());
    settings.setValue("higherQuality", rb_higherQuality->isChecked());
    settings.setValue("externalPlayer", le_externalPlayer->text());
    settings.setValue("saveVideoPath", le_saveVideoPath->text());
    settings.setValue("language", cb_language->currentIndex());
		
		settings.beginGroup("Proxy");
		settings.setValue("hostname", le_hostname->text());
		settings.setValue("username", le_username->text());
		settings.setValue("password", le_password->text());
		settings.setValue("port", sb_port->value());
		settings.endGroup();
  settings.endGroup();
}


void OptionDialog::selectVideoPlayerDir()
{
  QString dir = QFileDialog::getOpenFileName(this, tr("Select Video player"),  le_externalPlayer->text());
  if(dir != "")
    le_externalPlayer->setText(QDir::toNativeSeparators(dir));
}

void OptionDialog::saveVideoPath()
{
  QString dir = QFileDialog::getExistingDirectory(this, tr("Select save path"), le_saveVideoPath->text());
  if(dir != "")
  {
    if(dir.right(1) != "/" && dir.right(1) != "\\")
    {
      dir += QDir::separator();
    }
    if(!QFileInfo(dir).isWritable())
    {
      QMessageBox::critical(this, tr("No permission"), tr("Can not write to this directory. Please select another directory."));
      qDebug() << tr("No permission for directory \"%1\"").arg(dir);
    }
    else
    {
      le_saveVideoPath->setText(QDir::toNativeSeparators(dir));
    }
  }
}

void OptionDialog::accept()
{
  QString newDirName = le_saveVideoPath->text();
  QDir dir;
  bool error = false;
  
  
  //If the video save path changed, then all videos have to be moved
  if(QFileInfo(newDirName).absoluteDir() != QFileInfo(oldSavePath).absoluteDir())
  {
    int downloadingItems = 0;
    qint64 spaceNeeded = 0;
    
    for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_->begin(); it != youtubeItemManager_->end(); ++it)
    {
      if(it.value().item->videoEntry().bytesDownloaded > 0)
      {
        downloadingItems++;
        spaceNeeded += QFileInfo(SettingsManager::instance().filePath(it.value().item->videoEntry())).size();
      }
    }
    if(downloadingItems)
    {
      if(QMessageBox::question(this, tr("Move files to new location"), tr("If you wish to change the output directory, then all %1 files which have been (partially) downloaded, will be copied to the new location and then removed from the old location. %2MB free space are required for this operation. Continue?").arg(downloadingItems).arg(spaceNeeded/1024.0/1024.0), QMessageBox::Yes | QMessageBox::No) == QMessageBox::No)
      {
        le_saveVideoPath->setText(oldSavePath);
        return;
      }
    
      //Try to copy the files to the new location, if an error occurs
      //then delete all already copied files
      for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_->begin(); it != youtubeItemManager_->end(); ++it)
      {
        if(it.value().item->videoEntry().bytesDownloaded > 0)
        {
          QString oldFile, newFile;
          oldFile = SettingsManager::instance().filePath(it.value().item->videoEntry());
          newFile = newDirName + QFileInfo(oldFile).fileName();
        
  //         qDebug("Copying %s to %s", oldFile.toLatin1().data(), newFile.toLatin1().data());
        
          if(QFileInfo(newFile).exists())
          {
            if(QMessageBox::question(this, tr("File exists, overwrite?"), tr("The file %1 exists. Overwrite the existing file?").arg(newFile), QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
              dir.remove(newFile);
          }
          if(!QFile(oldFile).copy(newFile))
          {
            QMessageBox::warning(this, tr("Error while copying file"), tr("Sorry, but an error occurred while copying the file %1 to %2. Now all files which have already been copied will be removed.").arg(oldFile).arg(newFile));
            while(it != youtubeItemManager_->begin())
            {
              oldFile = SettingsManager::instance().filePath(it.value().item->videoEntry());
              newFile = newDirName + QFileInfo(oldFile).fileName();
              dir.remove(newFile);
              --it;
            }
            error = true;
            break;
          }
        }
      }
    }
    if(!error)
    {
      //Delete all old files
      for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_->begin(); it != youtubeItemManager_->end(); ++it)
      {
        if(it.value().item->videoEntry().bytesDownloaded > 0)
        {
          QString oldFile = SettingsManager::instance().filePath(it.value().item->videoEntry());
          dir.remove(oldFile);
        }
      }
    }
  }
  if(!error)
  {
    saveSettings();
    QDialog::accept();
  }
  else
    le_saveVideoPath->setText(oldSavePath);
}

void OptionDialog::viewLogFile()
{
  QProcess *myProcess = new QProcess(0);
  // Start the QProcess instance.
  #ifdef Q_WS_WIN
	//qDebug() << "notepad \"" + le_logFilePath->text() + "\"";
    myProcess->start("notepad \"" + le_logFilePath->text() + "\"");
  #endif
  #ifdef Q_WS_MAC
	//qDebug() << "open \"" + le_logFilePath->text() + "\"";
	myProcess->start("open \"" + le_logFilePath->text() + "\"");
  #endif
  #ifdef Q_WS_X11 
	//qDebug() << "kate \"" + le_logFilePath->text() + "\"";
    myProcess->start("kate \"" + le_logFilePath->text() + "\"");
  #endif
}

void OptionDialog::reject()
{
    QDialog::reject();
}
