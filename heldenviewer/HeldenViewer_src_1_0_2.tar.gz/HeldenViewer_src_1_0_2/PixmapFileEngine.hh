/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef PIXMAPFILEENGINE_HH
#define PIXMAPFILEENGINE_HH

#include <QAbstractFileEngine>
#include <QDateTime>

/**
  * This class must be instantiated somewhere in order to make it known to QT,
  * then all filenames which begin with "HELDENVIEWER_OWN_TYPES_" are handled
  * by The PixmapFileEngine.
*/
class PixmapFileEngineHandler : public QAbstractFileEngineHandler
{
public:
  QAbstractFileEngine *create(const QString &fileName) const;
};

/**
  * This class implements an own QAbstractFileEngine,
  * which is necessary to provide the tooltips of the thumbnail images
  * with the image data - there does not seem to be another way to do this.
  * Only filenames which begin with "HELDENVIEWER_OWN_TYPES_" are handled by this
  * class.
*/

class PixmapFileEngine : public QAbstractFileEngine
{
public:
  PixmapFileEngine(const QString& fileName);
  bool caseSensitive () const {return false; }
  bool close () {/*qDebug("Size:%f", m_bytes->size()/1024.0);*/ return true; }
  QStringList entryList ( QDir::Filters filters, const QStringList & filterNames ) const { return QStringList(); }
  FileFlags fileFlags ( FileFlags type = FileInfoAll ) const
  { return QAbstractFileEngine::ReadOtherPerm | QAbstractFileEngine::ExeOtherPerm | QAbstractFileEngine::FileType | QAbstractFileEngine::WriteOtherPerm; }
  QString fileName ( FileName file = DefaultName ) const { return m_fileName; }
  QDateTime fileTime ( FileTime time ) const { return QDateTime(); }
  bool mkdir ( const QString & dirName, bool createParentDirectories ) const {return false; }
  QString owner ( FileOwner owner ) const { return QString(); }
  uint ownerId ( FileOwner owner ) const { return -2; }
  bool remove () {return false; }
  bool rename ( const QString & newName ) { return false; }
  bool rmdir ( const QString & dirName, bool recurseParentDirectories ) const {return false; }
  void setFileName ( const QString & file ) {m_fileName = file; }
  bool setPermissions ( uint perms ) { return false; }
  bool setSize ( qint64 size ) { m_bytes->resize(size); return true; }
  qint64 size () const { return m_bytes->size(); }
  bool seek ( qint64 offset ) { m_filePos = offset; return true; }
  bool open ( QIODevice::OpenMode mode ) {return true; }
  bool isRelativePath () const {return false; }
  qint64 write ( const char * data, qint64 len );
  qint64 read ( char * data, qint64 maxlen );
  virtual bool  flush () {return true;}
private:
  QByteArray* m_bytes;
  QString m_fileName;
  qint64 m_filePos;
};

#endif // PIXMAPFILEENGINE_HH
