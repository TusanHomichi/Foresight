/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef OPTIONDIALOG_HH
#define OPTIONDIALOG_HH

#include <QDialog>
#include "ui_OptionDialog.h"

class YoutubeItemManager;

/**
  * Presents an option dialog to the user, which can adjust the following settings:
  * the standard download quality of a video, 
  * the external video player,
  * the path to save the videos,
  * the language of the gui.
  * The most difficult case to handle is a change in the save path of the videos,
  * as then all videos which have been downloaded so far must be moved to the new
  * location. In order to avoid data loss, this is done by copying the videos to
  * the new location and then removing them from the old.
*/

class OptionDialog : public QDialog, private Ui::OptionDialog
{
  Q_OBJECT
  
  void loadSettings();
  void saveSettings();
  
  QString oldSavePath;
  YoutubeItemManager *youtubeItemManager_;
protected:
  void accept();
public:
  OptionDialog(YoutubeItemManager *youtubeItemManager, QWidget* parent = 0);
private slots:
	void reject();
  //! Shows an open directory dialog
  void selectVideoPlayerDir();
  //! Shows an open directory dialog
  void saveVideoPath();
  //! Opens the logfile
  void viewLogFile();
};

#endif // OPTIONDIALOG_HH
