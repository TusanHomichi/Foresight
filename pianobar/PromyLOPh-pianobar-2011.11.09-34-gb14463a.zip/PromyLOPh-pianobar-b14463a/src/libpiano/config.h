#define PACKAGE "libpiano"
