#ifndef _CONFIG_H
#define _CONFIG_H

/* package name */
#define PACKAGE "pianobar"

#define VERSION "2011.11.09-dev"

#endif /* _CONFIG_H */
