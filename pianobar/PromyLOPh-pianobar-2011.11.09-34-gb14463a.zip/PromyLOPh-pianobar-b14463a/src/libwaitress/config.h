#define PACKAGE "libwaitress"
